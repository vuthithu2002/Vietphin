# Viet Phin — Vietnamese Coffee Ordering App

A full-stack onchain café ordering app for a Vietnamese coffee shop. Customers browse the menu, customize drinks, pre-order with a pickup time, and pay with USDC on Arc (Mainnet or Testnet). Every order and every menu product is stored on-chain. Loyalty points accumulate automatically, and staff manage order status and the product catalogue through a dedicated dashboard. Product changes (add, edit, hide, feature, pause, delete) are on-chain transactions that persist permanently.

Built with [Arc Studio](https://studio.arc.io)

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18, TypeScript, Vite, Tailwind CSS v3 |
| Animations | Framer Motion |
| Onchain | wagmi v2, viem, ConnectKit |
| Smart Contracts | Solidity 0.8.28, Foundry, OpenZeppelin 5.6.1 |
| Chain | Arc Testnet (chain ID 5042002) |
| Payment | USDC (ERC-20, Arc Testnet) |
| Backend | Bun HTTP server (`server/index.ts`) on port 3001 |
| Database | PostgreSQL 18 (Docker, named volume `vietphin_pgdata`) |

---

## Features

- **Menu** — 8 categories, 25+ items with customization (size, milk, sugar level)
- **Cart** — quantity management, special instructions, pickup time picker
- **USDC Checkout** — two-step approve + `placeOrder` transaction flow
- **Order Tracking** — Received → Preparing → Ready for Pickup → Completed
- **Loyalty Points** — 1 point per USDC spent, on-chain balance, rewards catalog
- **Staff Dashboard** — view active orders, update status (requires owner wallet)

---

## Development

### Prerequisites

- [Bun](https://bun.sh) v1.1+
- [Docker](https://docs.docker.com/get-docker/) (for Postgres)
- [Foundry](https://book.getfoundry.sh/getting-started/installation) (for contract compilation)
- A wallet with Arc Testnet USDC (use the **Get test USDC** button in Arc Studio)

### Install

```bash
bun install
```

### Start the database

```bash
docker run -d --name vietphin-db --restart unless-stopped \
  -e POSTGRES_PASSWORD=vietphin -e POSTGRES_DB=vietphin \
  -v vietphin_pgdata:/var/lib/postgresql \
  -p 5433:5432 --memory=512m postgres:18-alpine
```

### Run

Start the API server (port 3001) and the Vite dev server together:

```bash
bun run start
```

Or run them separately:

```bash
bun run server   # API only
bun run dev      # Vite only
```

### Build

```bash
bunx vite build
```

### Test (contracts)

```bash
bun run contracts:test
```

### Lint + Typecheck

```bash
bun run check
```

---

## Environment Variables

| Variable | Purpose |
|---|---|
| `DATABASE_URL` | Postgres connection string (default: `postgres://postgres:vietphin@127.0.0.1:5433/vietphin`) |
| `VITE_VIETPHIN_ADDRESS` | Deployed `VietPhin` contract address on Arc Testnet (set after deploying) |
| `RPC_PROXY_BASE_URL` | RPC proxy base URL (optional outside Arc Studio) |
| `RPC_PROXY_TOKEN` | RPC proxy auth token (optional outside Arc Studio) |
| `RPC_PROXY_CHAINS` | Comma-separated proxy chain keys (optional outside Arc Studio) |

`DATABASE_URL` is read by the API server (`server/index.ts`). The default value matches the Docker command above — change it only if you run Postgres differently.

Set `VITE_VIETPHIN_ADDRESS` in `.env` after deploying the contract. Without it, the checkout flow shows a warning banner but the menu, cart, and loyalty pages still work.

---

## Smart Contract

**`contracts/VietPhin.sol`** — single non-upgradeable contract:

- `placeOrder(totalAmountUsdc, pickupTime, itemsHash)` — transfers USDC from customer, records order, awards loyalty points
- `updateOrderStatus(orderId, newStatus)` — owner only, moves order through pipeline
- `getLoyaltyPoints(customer)` — returns on-chain point balance
- `withdrawUSDC(to, amount)` — owner only treasury withdrawal

**Deploy to Arc Testnet:**

```bash
# After setting up credentials (see Arc Studio Contracts panel)
bun run deploy:self
# or use Arc Studio's one-click deploy
```

Pass constructor args: `usdcToken_ = 0x3600000000000000000000000000000000000000`, `initialOwner = <your wallet>`.

After deploy, add the address to `.env`:

```bash
echo "VITE_VIETPHIN_ADDRESS=0x..." >> .env
```

---

## Testnet Funding

Use Arc Studio's built-in **Get test USDC** button (sidebar) to fund your connected wallet with Arc Testnet USDC before placing orders.

---

## License

MIT
