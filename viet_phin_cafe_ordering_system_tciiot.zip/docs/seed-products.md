# VietPhin — seedProducts Payloads

Contract: `0x61A8D9756c710f51e76520848bfb5F7C803b5425` on Arc Mainnet  
Function: `seedProducts(tuple[] items)`  
Caller: owner wallet `0x078c32a9788cf2368ae57d2de3e180d8f81caa3e`

Call this **6 times** (one batch per category). Each batch is safe for a single transaction.  
Prices are in raw USDC units (6 decimals): $2.00 = 2000000, $2.50 = 2500000, $3.00 = 3000000, $3.50 = 3500000.

---

## How to call from Remix

1. Open Remix → load the deployed contract at the address above (use "At Address" with the ABI).
2. Expand the `seedProducts` function.
3. Paste one batch array at a time into the `items` field and click **transact**.
4. Repeat for all 6 batches. Each batch adds to the existing products — they are not reset.

The `items` parameter type is `tuple[]`. In Remix's ABI encoder paste the value as a JSON array of objects (square brackets, comma-separated).

---

## Batch 1 — Vietnamese Coffee (11 items, IDs 1–11)

```json
[
  ["Cà Phê Phin","Cà Phê Phin","Classic phin-drip coffee brewed slowly over condensed milk. Bold, aromatic, deeply Vietnamese.",2500000,"vietnamese","https://images.unsplash.com/photo-1511920183378-df99de3c2ff4?auto=format&fit=crop&w=600&q=80",true,false,false],
  ["Cà Phê Sữa Đá","Cà Phê Sữa Đá","Iced phin coffee over sweetened condensed milk and crushed ice. Rich, creamy, Vietnam in a glass.",3000000,"vietnamese","https://images.unsplash.com/photo-1514432492-f0a5ab6a1b62?auto=format&fit=crop&w=600&q=80",true,false,false],
  ["Egg Coffee","Cà Phê Trứng","A Hanoian legend — egg yolk & condensed milk foam whipped silky-smooth atop strong robusta. Velvety and indulgent.",3500000,"vietnamese","https://images.unsplash.com/photo-1572097149080-79d7e84a6c95?auto=format&fit=crop&w=600&q=80",true,false,false],
  ["Coconut Coffee","Cà Phê Cốt Dừa","Blended phin coffee with rich coconut cream and condensed milk. Tropical, smooth, and refreshing.",3500000,"vietnamese","https://images.unsplash.com/photo-1561882468-9110e03e0f8d?auto=format&fit=crop&w=600&q=80",true,false,false],
  ["Salted Coffee","Cà Phê Muối","Robusta phin coffee crowned with silky salted cream foam. Sweet, bitter, and savory in every sip.",3000000,"vietnamese","https://images.unsplash.com/photo-1510591609474-20fb42c4ee17?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Cà Phê Đen Đá","Cà Phê Đen Đá","Pure black Vietnamese iced phin coffee — no milk, no frills. Just bold robusta over ice.",2000000,"vietnamese","https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Bạc Xỉu","Bạc Xỉu","A Saigonese classic — mostly hot milk with just a wisp of phin coffee and condensed milk. Mild, sweet, and comforting.",2500000,"vietnamese","https://images.unsplash.com/photo-1504630083234-14b9e0a8e9a7?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Yogurt Coffee","Cà Phê Sữa Chua","Iced phin coffee poured over tangy homemade yogurt. Uniquely Vietnamese and refreshingly tart.",3000000,"vietnamese","https://images.unsplash.com/photo-1592978261788-c0a68cfa8d0a?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Espresso Phin","Espresso Phin","A bold double-shot espresso extracted through a Vietnamese phin for a uniquely textured, intense brew.",3000000,"vietnamese","https://images.unsplash.com/photo-1510707577719-ae7c14805e3a?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Cà Phê Sữa Tươi","Cà Phê Sữa Tươi","Phin coffee with fresh steamed milk — lighter than condensed milk, cleaner and more modern.",2500000,"vietnamese","https://images.unsplash.com/photo-1485808191679-5f86510bd9d5?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Cà Phê Chocolate","Cà Phê Sô Cô La","Dark phin coffee stirred with rich Vietnamese cacao and fresh milk. A mocha with a Vietnamese soul.",3000000,"vietnamese","https://images.unsplash.com/photo-1579888944880-d498e0b5c1e3?auto=format&fit=crop&w=600&q=80",false,false,false]
]
```

---

## Batch 2 — Milk Tea (10 items, IDs 12–21)

```json
[
  ["Trà Sữa Truyền Thống","Trà Sữa Truyền Thống","Classic black tea milk tea with fresh milk and chewy tapioca pearls. Smooth, fragrant, and perfectly balanced.",2500000,"milktea","https://images.unsplash.com/photo-1571091718767-18b5b1457add?auto=format&fit=crop&w=600&q=80",true,false,false],
  ["Trà Sữa Matcha","Trà Sữa Matcha","Japanese ceremonial matcha whisked with steamed milk, lightly sweetened. Earthy, creamy, vibrant green.",3000000,"milktea","https://images.unsplash.com/photo-1515823064-d6e0c04616a7?auto=format&fit=crop&w=600&q=80",true,false,false],
  ["Trà Sữa Thái","Trà Sữa Thái","Bright orange spiced Thai tea with condensed milk and fresh cream. Rich, exotic, and irresistibly sweet.",3000000,"milktea","https://images.unsplash.com/photo-1627308595229-7830cf07db7a?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Brown Sugar Milk Tea","Trà Sữa Đường Đen","Tiger-striped brown sugar syrup, creamy milk tea and chewy boba pearls. The drink that took over the world.",3500000,"milktea","https://images.unsplash.com/photo-1578662996442-48f60103fc96?auto=format&fit=crop&w=600&q=80",true,false,false],
  ["Taro Milk Tea","Trà Sữa Khoai Môn","Creamy purple taro blended with fresh milk and a hint of vanilla. Sweet, earthy, and beautifully lavender.",3000000,"milktea","https://images.unsplash.com/photo-1561048020-9fd19ef00aee?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Trà Sữa Oolong","Trà Sữa Oolong Sữa Tươi","High-mountain oolong steeped thick, shaken with fresh milk and cheese foam on top. Fragrant and complex.",3000000,"milktea","https://images.unsplash.com/photo-1556679343-c7306c1976bc?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Pandan Milk Tea","Trà Sữa Lá Dứa","Fragrant pandan leaf infusion blended with creamy fresh milk. Quintessentially Vietnamese and aromatic.",2500000,"milktea","https://images.unsplash.com/photo-1638176066260-9b9106e56310?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Trà Sữa Trân Châu","Trà Sữa Trân Châu Hoàng Kim","Golden honey milk tea loaded with handmade golden tapioca pearls. Chewy, sweet, and utterly satisfying.",3000000,"milktea","https://images.unsplash.com/photo-1544145945-f90425340c7e?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Hồng Trà Sữa","Hồng Trà Sữa","Premium red tea steeped strong, shaken with whole milk until frothy. Clean, bright, and deeply refreshing.",2500000,"milktea","https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Cheese Foam Milk Tea","Trà Sữa Cheese Foam","Rich black milk tea topped with a thick salted cheese foam. Sip from the side — the magic is in the contrast.",3500000,"milktea","https://images.unsplash.com/photo-1590080875851-9f7e7bdbb8d1?auto=format&fit=crop&w=600&q=80",false,false,false]
]
```

---

## Batch 3 — Tea (10 items, IDs 22–31)

```json
[
  ["Trà Đào","Trà Đào","Green tea with fresh peach slices, lychee jelly, and honey. Fruity, floral, and irresistibly refreshing.",2500000,"tea","https://images.unsplash.com/photo-1559181567-c3190100d0fb?auto=format&fit=crop&w=600&q=80",true,false,false],
  ["Trà Vải","Trà Vải","Jasmine green tea infused with fresh lychee juice and lychee jelly cubes. Floral, tropical, and delicately sweet.",2500000,"tea","https://images.unsplash.com/photo-1610641818989-c2051b5e2cfd?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Trà Chanh","Trà Chanh","Classic Vietnamese street-style lemon iced tea — black tea, fresh lime, salt, sugar. Tart, cold, and timeless.",2000000,"tea","https://images.unsplash.com/photo-1509042239860-f7cac5ef1c1e?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Trà Sen","Trà Sen","Delicate green tea scented overnight with lotus blossoms. A Vietnamese tradition of elegance — subtle and calming.",2500000,"tea","https://images.unsplash.com/photo-1582450628498-9bca6fbb4916?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Trà Oolong","Trà Oolong","High-mountain Taiwanese oolong with a roasted, honey-like finish. Complex, smooth, and deeply satisfying.",2500000,"tea","https://images.unsplash.com/photo-1584968153986-3f5fe684d739?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Trà Atiso","Trà Atisô","Artichoke herbal tea from Đà Lạt — naturally sweet, golden amber color, and wonderfully detoxifying.",2000000,"tea","https://images.unsplash.com/photo-1542990253-a7b5f14e0b42?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Trà Tắc","Trà Tắc","Black tea with fresh kumquat juice, honey, and rock salt. Tangy, sweet-sour, and uniquely Vietnamese.",2500000,"tea","https://images.unsplash.com/photo-1491795029600-b32e1e36ec8a?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Trà Đào Cam Sả","Trà Đào Cam Sả","Peach green tea with fresh orange slices and fragrant lemongrass. Bright, aromatic, and refreshingly complex.",3000000,"tea","https://images.unsplash.com/photo-1517701550927-30cf4ba1deba?auto=format&fit=crop&w=600&q=80",true,false,false],
  ["Trà Gừng Mật Ong","Trà Gừng Mật Ong","Spiced ginger tea sweetened with wildflower honey. Warming, soothing, perfect for cool rainy mornings.",2000000,"tea","https://images.unsplash.com/photo-1571934811081-6e0f7b64f9df?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Hồng Trà Đào","Hồng Trà Đào","Strong red tea poured over fresh peach purée and topped with sparkling water. Fruity, bubbly, and effervescent.",3000000,"tea","https://images.unsplash.com/photo-1563379926345-cf82a4c35a72?auto=format&fit=crop&w=600&q=80",false,false,false]
]
```

---

## Batch 4 — Pastries & Cakes (11 items, IDs 32–42)

```json
[
  ["Bánh Flan","Bánh Flan","Silky Vietnamese caramel custard flan — amber caramel pooling around a wobbly, soft custard. A classic.",2500000,"pastries","https://images.unsplash.com/photo-1565958011703-44f9829ba187?auto=format&fit=crop&w=600&q=80",true,false,false],
  ["Bánh Mì Bơ","Bánh Mì Bơ","Crispy Vietnamese baguette split and slathered with salted butter and cane sugar. Simple street-food joy.",2000000,"pastries","https://images.unsplash.com/photo-1555507036-ab6b57dddef0?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Croissant","","Flaky, golden, buttery croissant baked fresh every morning. Perfect with any phin coffee.",2500000,"pastries","https://images.unsplash.com/photo-1509722747041-616f39b57edd?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Basque Cheesecake","","Burnt Basque cheesecake with a caramelized crust and silky, creamy interior. Rich and unforgettable.",3500000,"pastries","https://images.unsplash.com/photo-1571114486747-6dc8a0e8c617?auto=format&fit=crop&w=600&q=80",true,false,false],
  ["Tiramisu","","Classic tiramisu made with Vietnamese robusta espresso, mascarpone, and a generous dusting of dark cocoa.",3500000,"pastries","https://images.unsplash.com/photo-1571877227200-a0d6a6041562?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Bánh Chuối Nướng","Bánh Chuối Nướng","Baked Vietnamese banana sticky cake with coconut cream glaze. Moist, fragrant with pandan, and deeply satisfying.",2500000,"pastries","https://images.unsplash.com/photo-1588195538326-c5b1e9f80a1b?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Bánh Su Kem","Bánh Su Kem","Choux pastry puffs filled with silky vanilla custard cream. Light, airy, and melts in the mouth.",2500000,"pastries","https://images.unsplash.com/photo-1550617931-e17a7b70dce2?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Bánh Tart Trứng","Bánh Tart Trứng","Portuguese-style egg tarts with a flaky buttery shell and silky, slightly caramelized custard filling.",2500000,"pastries","https://images.unsplash.com/photo-1558961363-fa8fdf82db35?auto=format&fit=crop&w=600&q=80",true,false,false],
  ["Bánh Bông Lan","Bánh Bông Lan","Soft, pillowy Vietnamese sponge cake with a golden crust. Light as a cloud and subtly sweet.",2000000,"pastries","https://images.unsplash.com/photo-1586788680434-f748888d9f83?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Pain au Chocolat","","Flaky French puff pastry folded around dark chocolate batons. Crisp outside, melty inside.",3000000,"pastries","https://images.unsplash.com/photo-1483695028939-5bb13f8648b0?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Bánh Da Lợn","Bánh Da Lợn","Layered steamed pandan and coconut rice cake — translucent, chewy, fragrant, and beautiful in cross-section.",2500000,"pastries","https://images.unsplash.com/photo-1563379091339-b30cb3c38a2e?auto=format&fit=crop&w=600&q=80",false,false,false]
]
```

---

## Batch 5 — Sandwiches (8 items, IDs 43–50)

```json
[
  ["Classic Bánh Mì","Bánh Mì Đặc Biệt","Crispy baguette with pork pâté, Vietnamese ham, head cheese, pickled daikon & carrot, cucumber, jalapeño, and fresh herbs.",3500000,"sandwiches","https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=600&q=80",true,false,false],
  ["Veggie Bánh Mì","Bánh Mì Chay","Lemongrass tofu, avocado, pickled daikon & carrot, jalapeño, and house hoisin-sesame mayo on a crispy baguette.",3000000,"sandwiches","https://images.unsplash.com/photo-1485963631004-f2f00b1d6606?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Bánh Mì Thịt Nướng","Bánh Mì Thịt Nướng","Grilled lemongrass pork belly, caramelized onions, pickled vegetables, cucumber, and sriracha mayo.",3500000,"sandwiches","https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format&fit=crop&w=600&q=80",true,false,false],
  ["Bánh Mì Gà","Bánh Mì Gà Nướng","Chargrilled turmeric chicken with house mayo, pickled vegetables, cucumber, and fresh coriander.",3500000,"sandwiches","https://images.unsplash.com/photo-1550547660-37406909e2b4?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Bánh Mì Chả Lụa","Bánh Mì Chả Lụa","Vietnamese silken pork roll (chả lụa), butter, Maggi sauce, pickled veg, and herbs. A Saigon street-food staple.",3000000,"sandwiches","https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Bánh Mì Pate","Bánh Mì Pate Bơ","Crispy baguette with rich French pork pâté, salted butter, Maggi, and pickled vegetables. Simple perfection.",3000000,"sandwiches","https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80",true,false,false],
  ["Bánh Mì Xíu Mại","Bánh Mì Xíu Mại","Soft braised Vietnamese meatballs in a tomato-lemongrass broth, stuffed into a crusty baguette. Hot and hearty.",3500000,"sandwiches","https://images.unsplash.com/photo-1565299624596-722f3a971738?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Bánh Mì Trứng","Bánh Mì Trứng Ốp La","Fried egg, pâté, cucumber, and pickled veg in a warm crispy baguette. The perfect breakfast sandwich.",2500000,"sandwiches","https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=600&q=80",false,false,false]
]
```

---

## Batch 6 — Desserts (10 items, IDs 51–60)

```json
[
  ["Chè Ba Màu","Chè Ba Màu","Three-color sweet bean dessert — red beans, pandan jelly, mung bean paste — with coconut milk and shaved ice.",3000000,"desserts","https://images.unsplash.com/photo-1612198188060-c5e4396f898a?auto=format&fit=crop&w=600&q=80",true,false,false],
  ["Chè Đậu Đỏ","Chè Đậu Đỏ","Red bean sweet soup simmered with rock sugar and served warm or iced with coconut cream. Comforting and nourishing.",2500000,"desserts","https://images.unsplash.com/photo-1604908173716-08ae1caf9f85?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Chè Thái","Chè Thái","Tropical fruit medley in coconut milk with jackfruit, palm seeds, grass jelly, and shaved ice.",3000000,"desserts","https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Kem Dừa","Kem Dừa","Homemade coconut ice cream in a half coconut shell, topped with toasted coconut flakes and pandan jelly.",3500000,"desserts","https://images.unsplash.com/photo-1538489753-f0fc4dce17f7?auto=format&fit=crop&w=600&q=80",true,false,false],
  ["Pandan Coconut Pudding","Bánh Pudding Pandan Dừa","Double-layer pudding: fragrant pandan custard beneath thick coconut cream. Wobbly, silky, perfection.",2500000,"desserts","https://images.unsplash.com/photo-1621929469462-fe3ab76e2b0e?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Yaourt Dẻo","Yaourt Dẻo","Vietnamese set yogurt — thicker and creamier than Greek yogurt, slightly tangy, drizzled with honey.",2500000,"desserts","https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Sinh Tố Trái Cây","Sinh Tố Trái Cây","Fresh seasonal Vietnamese fruit smoothie blended with sweetened condensed milk. Thick, creamy, and vibrant.",3000000,"desserts","https://images.unsplash.com/photo-1590301157890-4810ed352733?auto=format&fit=crop&w=600&q=80",true,false,false],
  ["Kem Chiên","Kem Chiên","Deep-fried ice cream coated in a crispy golden batter — cold inside, crunchy outside. A fun Vietnamese dessert.",3500000,"desserts","https://images.unsplash.com/photo-1560717789-0ac2ffeb9f54?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Nước Mía","Nước Mía Tắc","Freshly pressed sugarcane juice with kumquat and a pinch of salt. Vietnam's most refreshing street drink.",2500000,"desserts","https://images.unsplash.com/photo-1534030347209-467a04a07df0?auto=format&fit=crop&w=600&q=80",false,false,false],
  ["Bánh Da Xanh","Bánh Da Xanh","Chewy pandan glutinous rice balls in sweet ginger syrup, topped with toasted sesame and shredded coconut.",2500000,"desserts","https://images.unsplash.com/photo-1568901346375-9be3f37b3b7f?auto=format&fit=crop&w=600&q=80",false,false,false]
]
```

---

## Tuple field order (for reference)

Each item in the array is a tuple in this exact order:

| # | Field | Type | Notes |
|---|---|---|---|
| 0 | name | string | English name |
| 1 | nameVi | string | Vietnamese name (empty string if none) |
| 2 | description | string | |
| 3 | priceUsdc | uint256 | Raw units: $1.00 = 1000000 |
| 4 | category | string | vietnamese / milktea / tea / pastries / sandwiches / desserts |
| 5 | imageUrl | string | Full Unsplash URL |
| 6 | isFeatured | bool | Shows in "Popular" section |
| 7 | isHidden | bool | false = visible |
| 8 | isPaused | bool | false = available |

---

## After seeding

Once all 6 batches are submitted:
- `productCount()` should return **60**
- The menu page will display all items on next load
- You can verify any item with `getProduct(1)` through `getProduct(60)`
