# Deploy Viet Phin to Render (5 minutes, free)

## Step 1 — Download the code
In Arc Studio: **Code panel → Download Code** (top-right of the file tree)  
This gives you a zip of the entire project.

## Step 2 — Push to GitHub
1. Go to [github.com/new](https://github.com/new) → create a repo called `viet-phin` (public or private)
2. Unzip the downloaded code, then in that folder:
```bash
git init
git add .
git commit -m "Viet Phin cafe app"
git remote add origin https://github.com/YOUR_USERNAME/viet-phin.git
git push -u origin main
```

## Step 3 — Deploy on Render
1. Go to [render.com](https://render.com) → **New → Web Service**
2. Connect GitHub → select `viet-phin`
3. Render reads `render.yaml` automatically — click **Create Web Service**
4. Wait 3–5 minutes for Docker build

Your live URL: `https://viet-phin.onrender.com`

## Step 4 — Add a persistent disk (keeps orders after redeploy)
In Render dashboard: **your service → Disks → Add Disk**
- Mount path: `/data`
- Size: 1 GB

## Environment variables (already in render.yaml — no action needed)
| Key | Value |
|---|---|
| `NODE_ENV` | `production` |
| `PORT` | `10000` |
| `DATA_DIR` | `/data` |
| `VITE_VIETPHIN_ADDRESS` | `0xc2200431c4058be1cbed73b85222c1ac52e02c5e` |

## Notes
- Free tier spins down after 15 min idle — first request takes ~30s to wake
- Upgrade to $7/mo "Starter" plan for always-on
- Contract owner/treasury: `0x078c32a9788cf2368ae57d2de3e180d8f81caa3e`
