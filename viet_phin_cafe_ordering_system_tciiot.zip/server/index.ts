/**
 * Viet Phin API Server
 * Bun HTTP server — products + orders backed by bun:sqlite (no external DB).
 * Runs on port 3001; Vite proxies /api → http://localhost:3001
 * In production (HF Docker Space) the static Vite build is served on port 7860.
 */

import { Database } from 'bun:sqlite';
import { existsSync, mkdirSync } from 'fs';
import { join } from 'path';

// ── DB setup ─────────────────────────────────────────────────────────────────

const DATA_DIR = process.env.DATA_DIR ?? './data';
if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });

const db = new Database(`${DATA_DIR}/vietphin.db`, { create: true });
db.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL;');

const IS_PROD = process.env.NODE_ENV === 'production';
// Railway injects PORT; HF Space uses 7860; dev falls back to 3001
const PORT = Number(process.env.PORT ?? (IS_PROD ? 3000 : 3001));
const DIST_DIR = join(import.meta.dir, '..', 'dist');

// ── Schema migration (idempotent) ────────────────────────────────────────────

function migrate() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS products (
      id          TEXT PRIMARY KEY,
      data        TEXT NOT NULL,
      created_at  INTEGER DEFAULT (unixepoch()),
      updated_at  INTEGER DEFAULT (unixepoch())
    );

    CREATE TABLE IF NOT EXISTS orders (
      id          TEXT PRIMARY KEY,
      data        TEXT NOT NULL,
      created_at  INTEGER DEFAULT (unixepoch()),
      updated_at  INTEGER DEFAULT (unixepoch())
    );

    -- Daily sequence counter for human-readable order codes (VP-YYMMDD-NNNN)
    CREATE TABLE IF NOT EXISTS order_seq (
      day   TEXT PRIMARY KEY,
      seq   INTEGER NOT NULL DEFAULT 0
    );

    CREATE INDEX IF NOT EXISTS orders_created_at_idx ON orders (created_at DESC);
  `);
  console.log('[db] schema ready');
}

// ── Order code generation ─────────────────────────────────────────────────────

function nextOrderCode(): string {
  const now = new Date();
  const yy = String(now.getFullYear()).slice(2);
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const dd = String(now.getDate()).padStart(2, '0');
  const day = `${yy}${mm}${dd}`;

  // Atomic upsert + increment
  db.exec(`
    INSERT INTO order_seq (day, seq) VALUES ('${day}', 1)
    ON CONFLICT(day) DO UPDATE SET seq = seq + 1
  `);
  const row = db.query<{ seq: number }, string>(
    'SELECT seq FROM order_seq WHERE day = ?',
  ).get(day);
  const seq = row?.seq ?? 1;
  return `VP-${day}-${String(seq).padStart(4, '0')}`;
}

// ── Seed: import static menu if products table is empty ─────────────────────

async function seedIfEmpty() {
  const row = db.query<{ n: number }, []>('SELECT count(*) AS n FROM products').get([]);
  if ((row?.n ?? 0) > 0) return;

  try {
    const { MENU_ITEMS } = await import('../src/data/menuData.ts');
    const insert = db.prepare(
      'INSERT OR IGNORE INTO products (id, data) VALUES (?, ?)',
    );
    const insertAll = db.transaction((items: typeof MENU_ITEMS) => {
      for (const item of items) {
        insert.run(item.id, JSON.stringify({ ...item, hidden: false, paused: false }));
      }
    });
    insertAll(MENU_ITEMS);
    console.log(`[db] seeded ${MENU_ITEMS.length} products`);
  } catch (e) {
    console.warn('[seed] could not seed menu items:', e);
  }
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function json(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

function err(msg: string, status = 400): Response {
  return json({ error: msg }, status);
}

async function parseBody(req: Request): Promise<unknown> {
  try { return await req.json(); } catch { return null; }
}

function cors(res: Response): Response {
  res.headers.set('Access-Control-Allow-Origin', '*');
  res.headers.set('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
  res.headers.set('Access-Control-Allow-Headers', 'Content-Type');
  return res;
}

function parseRow(r: { data: string }): unknown {
  try { return JSON.parse(r.data); } catch { return null; }
}

// ── Router ───────────────────────────────────────────────────────────────────

async function serveStatic(pathname: string): Promise<Response | null> {
  if (!IS_PROD) return null;
  // Strip /api prefix — static files never live under /api
  if (pathname.startsWith('/api')) return null;

  // Try exact file first, then index.html for SPA fallback
  const candidates = [
    join(DIST_DIR, pathname),
    join(DIST_DIR, 'index.html'),
  ];
  for (const filePath of candidates) {
    const file = Bun.file(filePath);
    if (await file.exists()) {
      return new Response(file);
    }
  }
  return null;
}

async function handle(req: Request): Promise<Response> {
  const url = new URL(req.url);
  // In production the browser calls /api/products; dev Vite proxy rewrites to /products
  const rawPath = url.pathname;
  const path = IS_PROD && rawPath.startsWith('/api')
    ? rawPath.slice(4) || '/'
    : rawPath;
  const method = req.method.toUpperCase();

  if (method === 'OPTIONS') return cors(new Response(null, { status: 204 }));

  // Static file serving in production
  if (IS_PROD) {
    const staticRes = await serveStatic(rawPath);
    if (staticRes) return staticRes;
  }

  // ── Products ──────────────────────────────────────────────────────────────

  if (path === '/products' && method === 'GET') {
    const staffMode = url.searchParams.get('staff') === '1';
    let rows: { data: string }[];
    if (staffMode) {
      rows = db.query<{ data: string }, []>(
        'SELECT data FROM products ORDER BY created_at ASC',
      ).all([]);
    } else {
      // Exclude hidden; include paused (shown as Unavailable on menu)
      rows = db.query<{ data: string }, []>(
        `SELECT data FROM products ORDER BY created_at ASC`,
      ).all([]).filter((r) => {
        try {
          const d = JSON.parse(r.data) as { hidden?: boolean };
          return !d.hidden;
        } catch { return true; }
      });
    }
    return cors(json(rows.map(parseRow)));
  }

  if (path === '/products' && method === 'POST') {
    const body = await parseBody(req) as Record<string, unknown> | null;
    if (!body || !body.id || !body.name) return err('id and name required');
    db.prepare(
      `INSERT INTO products (id, data) VALUES (?, ?)
       ON CONFLICT(id) DO UPDATE SET data = excluded.data, updated_at = unixepoch()`,
    ).run(body.id, JSON.stringify(body));
    return cors(json(body, 201));
  }

  const productMatch = path.match(/^\/products\/([^/]+)$/);
  if (productMatch) {
    const id = decodeURIComponent(productMatch[1]);

    if (method === 'PUT' || method === 'PATCH') {
      const body = await parseBody(req) as Record<string, unknown> | null;
      if (!body) return err('body required');

      if (method === 'PATCH') {
        const row = db.query<{ data: string }, string>(
          'SELECT data FROM products WHERE id = ?',
        ).get(id);
        if (!row) return err('not found', 404);
        const merged = { ...JSON.parse(row.data), ...body };
        db.prepare(
          'UPDATE products SET data = ?, updated_at = unixepoch() WHERE id = ?',
        ).run(JSON.stringify(merged), id);
        return cors(json(merged));
      }

      db.prepare(
        `INSERT INTO products (id, data) VALUES (?, ?)
         ON CONFLICT(id) DO UPDATE SET data = excluded.data, updated_at = unixepoch()`,
      ).run(id, JSON.stringify({ ...body, id }));
      return cors(json({ ...body, id }));
    }

    if (method === 'DELETE') {
      db.prepare('DELETE FROM products WHERE id = ?').run(id);
      return cors(json({ ok: true }));
    }
  }

  // ── Orders ────────────────────────────────────────────────────────────────

  if (path === '/orders' && method === 'GET') {
    const customer = url.searchParams.get('customer');
    let rows: { data: string }[];
    if (customer) {
      rows = db.query<{ data: string }, string>(
        `SELECT data FROM orders WHERE json_extract(data,'$.customer') = ?
         ORDER BY created_at DESC LIMIT 200`,
      ).all(customer);
    } else {
      rows = db.query<{ data: string }, []>(
        'SELECT data FROM orders ORDER BY created_at DESC LIMIT 500',
      ).all([]);
    }
    return cors(json(rows.map(parseRow)));
  }

  if (path === '/orders' && method === 'POST') {
    const body = await parseBody(req) as Record<string, unknown> | null;
    if (!body || !body.orderId) return err('orderId required');

    const orderCode = typeof body.orderCode === 'string' && body.orderCode.startsWith('VP-')
      ? body.orderCode
      : nextOrderCode();
    const record = { ...body, orderCode };
    db.prepare(
      `INSERT INTO orders (id, data) VALUES (?, ?)
       ON CONFLICT(id) DO UPDATE SET data = excluded.data, updated_at = unixepoch()`,
    ).run(body.orderId, JSON.stringify(record));
    return cors(json(record, 201));
  }

  const orderMatch = path.match(/^\/orders\/([^/]+)$/);
  if (orderMatch && (method === 'PATCH' || method === 'PUT')) {
    const id = decodeURIComponent(orderMatch[1]);
    const body = await parseBody(req) as Record<string, unknown> | null;
    if (!body) return err('body required');
    const row = db.query<{ data: string }, string>(
      'SELECT data FROM orders WHERE id = ?',
    ).get(id);
    if (!row) return err('not found', 404);
    const merged = { ...JSON.parse(row.data), ...body };
    db.prepare(
      'UPDATE orders SET data = ?, updated_at = unixepoch() WHERE id = ?',
    ).run(JSON.stringify(merged), id);
    return cors(json(merged));
  }

  if (path === '/health' || path === '/api/health') return cors(json({ ok: true }));
  return cors(err('not found', 404));
}

// ── Boot ─────────────────────────────────────────────────────────────────────

async function start() {
  migrate();
  await seedIfEmpty();

  Bun.serve({
    port: PORT,
    fetch: async (req) => {
      try { return await handle(req); }
      catch (e) {
        console.error('[api error]', e);
        return cors(json({ error: 'internal server error' }, 500));
      }
    },
  });

  console.log(`[api] listening on http://localhost:${PORT}`);
}

start().catch((e) => {
  console.error('[fatal]', e);
  process.exit(1);
});
