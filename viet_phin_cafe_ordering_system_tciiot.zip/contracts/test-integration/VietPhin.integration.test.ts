/**
 * VietPhin Pre-Deploy Fork Verification
 * Pre-deploy dispatch: anvil fork, all senders obtained via anvil_impersonateAccount + anvil_setBalance.
 * No private keys used.
 */

import {
  createPublicClient,
  createWalletClient,
  http,
  keccak256,
  toBytes,
  type Address,
  type Hex,
} from "viem";
import { arc } from "viem/chains";

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------
const FORK_URL = "http://127.0.0.1:33611";
const CONTRACT = "0xBc2f5aB22eb7521659D7F38Fe1d591C70Fd8d0D5" as Address;
const OWNER = "0x9812791424bd7eD3D85bB53a708b2b0F25e1A06D" as Address;
const USDC = "0x3600000000000000000000000000000000000000" as Address;
const CUSTOMER = "0xDeaDBeefDeaDBeefDeaDBeefDeaDBeefDeaDBeef" as Address;
const NON_OWNER = "0x1111111111111111111111111111111111111111" as Address;

// ---------------------------------------------------------------------------
// JSON ABI (no parseAbi — use raw JSON to avoid abitype tuple limitations)
// ---------------------------------------------------------------------------
const ABI = [
  // --- views ---
  { type: "function", name: "owner", inputs: [], outputs: [{ type: "address" }], stateMutability: "view" },
  { type: "function", name: "usdcToken", inputs: [], outputs: [{ type: "address" }], stateMutability: "view" },
  { type: "function", name: "treasury", inputs: [], outputs: [{ type: "address" }], stateMutability: "view" },
  { type: "function", name: "productsInitialized", inputs: [], outputs: [{ type: "bool" }], stateMutability: "view" },
  { type: "function", name: "productCount", inputs: [], outputs: [{ type: "uint256" }], stateMutability: "view" },
  { type: "function", name: "orderCount", inputs: [], outputs: [{ type: "uint256" }], stateMutability: "view" },
  { type: "function", name: "totalEscrowed", inputs: [], outputs: [{ type: "uint256" }], stateMutability: "view" },
  {
    type: "function", name: "getProduct",
    inputs: [{ name: "id", type: "uint256" }],
    outputs: [{
      type: "tuple",
      components: [
        { name: "id", type: "uint256" }, { name: "name", type: "string" }, { name: "nameVi", type: "string" },
        { name: "description", type: "string" }, { name: "priceUsdc", type: "uint256" },
        { name: "category", type: "string" }, { name: "imageUrl", type: "string" },
        { name: "isFeatured", type: "bool" }, { name: "isHidden", type: "bool" },
        { name: "isPaused", type: "bool" }, { name: "exists", type: "bool" },
      ],
    }],
    stateMutability: "view",
  },
  {
    type: "function", name: "getProducts",
    inputs: [{ name: "offset", type: "uint256" }, { name: "limit", type: "uint256" }],
    outputs: [{
      type: "tuple[]",
      components: [
        { name: "id", type: "uint256" }, { name: "name", type: "string" }, { name: "nameVi", type: "string" },
        { name: "description", type: "string" }, { name: "priceUsdc", type: "uint256" },
        { name: "category", type: "string" }, { name: "imageUrl", type: "string" },
        { name: "isFeatured", type: "bool" }, { name: "isHidden", type: "bool" },
        { name: "isPaused", type: "bool" }, { name: "exists", type: "bool" },
      ],
    }],
    stateMutability: "view",
  },
  {
    type: "function", name: "getOrder",
    inputs: [{ name: "orderId", type: "uint256" }],
    outputs: [{
      type: "tuple",
      components: [
        { name: "orderId", type: "uint256" }, { name: "customer", type: "address" },
        { name: "totalAmountUsdc", type: "uint256" }, { name: "pickupTime", type: "uint256" },
        { name: "status", type: "uint8" }, { name: "itemsHash", type: "bytes32" },
        { name: "createdAt", type: "uint256" }, { name: "txHash", type: "bytes32" },
      ],
    }],
    stateMutability: "view",
  },
  { type: "function", name: "getLoyaltyPoints", inputs: [{ name: "customer", type: "address" }], outputs: [{ type: "uint256" }], stateMutability: "view" },
  // --- writes ---
  {
    type: "function", name: "initProducts",
    inputs: [{
      name: "items", type: "tuple[]",
      components: [
        { name: "name", type: "string" }, { name: "nameVi", type: "string" }, { name: "description", type: "string" },
        { name: "priceUsdc", type: "uint256" }, { name: "category", type: "string" }, { name: "imageUrl", type: "string" },
        { name: "isFeatured", type: "bool" }, { name: "isHidden", type: "bool" }, { name: "isPaused", type: "bool" },
      ],
    }],
    outputs: [],
    stateMutability: "nonpayable",
  },
  {
    type: "function", name: "addProduct",
    inputs: [{
      name: "item", type: "tuple",
      components: [
        { name: "name", type: "string" }, { name: "nameVi", type: "string" }, { name: "description", type: "string" },
        { name: "priceUsdc", type: "uint256" }, { name: "category", type: "string" }, { name: "imageUrl", type: "string" },
        { name: "isFeatured", type: "bool" }, { name: "isHidden", type: "bool" }, { name: "isPaused", type: "bool" },
      ],
    }],
    outputs: [{ name: "id", type: "uint256" }],
    stateMutability: "nonpayable",
  },
  {
    type: "function", name: "updateProduct",
    inputs: [
      { name: "id", type: "uint256" },
      {
        name: "item", type: "tuple",
        components: [
          { name: "name", type: "string" }, { name: "nameVi", type: "string" }, { name: "description", type: "string" },
          { name: "priceUsdc", type: "uint256" }, { name: "category", type: "string" }, { name: "imageUrl", type: "string" },
          { name: "isFeatured", type: "bool" }, { name: "isHidden", type: "bool" }, { name: "isPaused", type: "bool" },
        ],
      },
    ],
    outputs: [],
    stateMutability: "nonpayable",
  },
  { type: "function", name: "deleteProduct", inputs: [{ name: "id", type: "uint256" }], outputs: [], stateMutability: "nonpayable" },
  { type: "function", name: "setProductHidden", inputs: [{ name: "id", type: "uint256" }, { name: "hidden", type: "bool" }], outputs: [], stateMutability: "nonpayable" },
  { type: "function", name: "setProductPaused", inputs: [{ name: "id", type: "uint256" }, { name: "paused", type: "bool" }], outputs: [], stateMutability: "nonpayable" },
  { type: "function", name: "setProductFeatured", inputs: [{ name: "id", type: "uint256" }, { name: "featured", type: "bool" }], outputs: [], stateMutability: "nonpayable" },
  { type: "function", name: "renounceOwnership", inputs: [], outputs: [], stateMutability: "pure" },
  {
    type: "function", name: "placeOrder",
    inputs: [
      { name: "totalAmountUsdc", type: "uint256" },
      { name: "pickupTime", type: "uint256" },
      { name: "itemsHash", type: "bytes32" },
    ],
    outputs: [{ type: "uint256" }],
    stateMutability: "nonpayable",
  },
] as const;

// USDC ERC-20 ABI fragment
const ERC20_APPROVE_ABI = [
  { type: "function", name: "approve", inputs: [{ name: "spender", type: "address" }, { name: "amount", type: "uint256" }], outputs: [{ type: "bool" }], stateMutability: "nonpayable" },
] as const;

// ---------------------------------------------------------------------------
// Viem clients
// ---------------------------------------------------------------------------
const forkChain = { ...arc, id: 5042 };
const transport = http(FORK_URL);
const publicClient = createPublicClient({ chain: forkChain, transport });

function walletClientFor(account: Address) {
  return createWalletClient({ chain: forkChain, transport, account });
}

// ---------------------------------------------------------------------------
// Test result tracking
// ---------------------------------------------------------------------------
interface TestResult {
  testName: string;
  status: "PASS" | "FAIL" | "SKIPPED";
  detail?: string;
  expected?: string;
  actual?: string;
  durationMs: number;
}

const results: TestResult[] = [];
let failures = 0;

function log(r: TestResult) {
  results.push(r);
  if (r.status === "FAIL") failures++;
  console.log(JSON.stringify(r));
}

// ---------------------------------------------------------------------------
// Anvil helpers
// ---------------------------------------------------------------------------
async function rpc(method: string, params: unknown[]) {
  const res = await fetch(FORK_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ jsonrpc: "2.0", method, params, id: 1 }),
  });
  return res.json();
}

async function impersonate(addr: Address) {
  await rpc("anvil_impersonateAccount", [addr]);
}
async function stopImpersonate(addr: Address) {
  await rpc("anvil_stopImpersonatingAccount", [addr]);
}
async function setBalance(addr: Address) {
  await rpc("anvil_setBalance", [addr, "0x56BC75E2D63100000"]); // 100 ETH
}

// ---------------------------------------------------------------------------
// Write helpers
// ---------------------------------------------------------------------------
async function ownerWrite(fnName: string, args: unknown[]): Promise<Hex> {
  await impersonate(OWNER);
  await setBalance(OWNER);
  const wc = walletClientFor(OWNER);
  const hash = await wc.writeContract({
    address: CONTRACT,
    abi: ABI,
    functionName: fnName as any,
    args: args as any,
  });
  await stopImpersonate(OWNER);
  return hash;
}

async function waitTx(hash: Hex) {
  return publicClient.waitForTransactionReceipt({ hash });
}

async function readView(fnName: string, args: unknown[]): Promise<unknown> {
  return publicClient.readContract({
    address: CONTRACT,
    abi: ABI,
    functionName: fnName as any,
    args: args as any,
  });
}

/** Try a write from any account; return whether it reverted */
async function expectWriteReverts(account: Address, fnName: string, args: unknown[]): Promise<boolean> {
  await impersonate(account);
  await setBalance(account);
  try {
    const wc = walletClientFor(account);
    const hash = await wc.writeContract({
      address: CONTRACT,
      abi: ABI,
      functionName: fnName as any,
      args: args as any,
    });
    const receipt = await waitTx(hash);
    await stopImpersonate(account);
    return receipt.status === "reverted";
  } catch {
    await stopImpersonate(account).catch(() => {});
    return true;
  }
}

/** Try a view read; return whether it throws */
async function expectViewReverts(fnName: string, args: unknown[]): Promise<boolean> {
  try {
    await publicClient.readContract({
      address: CONTRACT,
      abi: ABI,
      functionName: fnName as any,
      args: args as any,
    });
    return false;
  } catch {
    return true;
  }
}

// ---------------------------------------------------------------------------
// Product input helper
// ---------------------------------------------------------------------------
function product(suffix: string, priceUsdc = 3_000_000n) {
  return {
    name: `Product ${suffix}`,
    nameVi: `Sản phẩm ${suffix}`,
    description: `Desc ${suffix}`,
    priceUsdc,
    category: "Drinks",
    imageUrl: `https://cdn.vietphin.test/${suffix}.jpg`,
    isFeatured: false,
    isHidden: false,
    isPaused: false,
  };
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

async function test_constructorState() {
  const t0 = Date.now();
  try {
    const [ownerAddr, usdcAddr, treasuryAddr] = await Promise.all([
      readView("owner", []),
      readView("usdcToken", []),
      readView("treasury", []),
    ]);
    const ok =
      (ownerAddr as string).toLowerCase() === OWNER.toLowerCase() &&
      (usdcAddr as string).toLowerCase() === USDC.toLowerCase() &&
      (treasuryAddr as string).toLowerCase() === OWNER.toLowerCase(); // treasury = initialOwner per constructor
    if (!ok) {
      log({ testName: "constructor: owner/usdcToken/treasury=initialOwner", status: "FAIL", expected: `owner=${OWNER} usdc=${USDC} treasury=${OWNER}`, actual: `owner=${ownerAddr} usdc=${usdcAddr} treasury=${treasuryAddr}`, durationMs: Date.now() - t0 });
    } else {
      log({ testName: "constructor: owner/usdcToken/treasury=initialOwner", status: "PASS", detail: `owner=${ownerAddr} usdc=${usdcAddr} treasury=${treasuryAddr}`, durationMs: Date.now() - t0 });
    }
  } catch (e: any) {
    log({ testName: "constructor: owner/usdcToken/treasury=initialOwner", status: "FAIL", detail: String(e?.message ?? e), durationMs: Date.now() - t0 });
  }
}

async function test_initProducts() {
  const t0 = Date.now();
  try {
    const alreadyInit = await readView("productsInitialized", []) as boolean;
    if (alreadyInit) {
      log({ testName: "initProducts", status: "SKIPPED", detail: "already initialized on this fork", durationMs: Date.now() - t0 });
      return;
    }

    const items = [product("A"), product("B"), product("C"), product("D")];
    const hash = await ownerWrite("initProducts", [items]);
    const receipt = await waitTx(hash);

    if (receipt.status !== "success") {
      log({ testName: "initProducts", status: "FAIL", detail: `reverted hash=${hash}`, durationMs: Date.now() - t0 });
      return;
    }

    const [initialized, count] = await Promise.all([
      readView("productsInitialized", []) as Promise<boolean>,
      readView("productCount", []) as Promise<bigint>,
    ]);
    const products = await readView("getProducts", [0n, 0n]) as any[];

    if (!initialized) { log({ testName: "initProducts: productsInitialized=true", status: "FAIL", detail: `hash=${hash}`, durationMs: Date.now() - t0 }); return; }
    if (count !== BigInt(items.length)) { log({ testName: "initProducts: productCount=4", status: "FAIL", expected: "4", actual: String(count), durationMs: Date.now() - t0 }); return; }
    if (products.length !== items.length) { log({ testName: "initProducts: getProducts returns all 4", status: "FAIL", expected: "4", actual: String(products.length), durationMs: Date.now() - t0 }); return; }
    // Verify first product name
    if (products[0].name !== items[0].name) { log({ testName: "initProducts: product[0] name correct", status: "FAIL", expected: items[0].name, actual: products[0].name, durationMs: Date.now() - t0 }); return; }

    log({ testName: "initProducts", status: "PASS", detail: `hash=${hash} initialized=${initialized} count=${count} returned=${products.length}`, durationMs: Date.now() - t0 });
  } catch (e: any) {
    log({ testName: "initProducts", status: "FAIL", detail: String(e?.message ?? e), durationMs: Date.now() - t0 });
  }
}

async function test_initProductsAlreadyInitialized() {
  const t0 = Date.now();
  try {
    const reverted = await expectWriteReverts(OWNER, "initProducts", [[product("X")]]);
    if (reverted) {
      log({ testName: "initProducts: AlreadyInitialized on second call", status: "PASS", detail: "reverted as expected", durationMs: Date.now() - t0 });
    } else {
      log({ testName: "initProducts: AlreadyInitialized on second call", status: "FAIL", expected: "revert AlreadyInitialized", actual: "success", durationMs: Date.now() - t0 });
    }
  } catch (e: any) {
    log({ testName: "initProducts: AlreadyInitialized on second call", status: "FAIL", detail: String(e?.message ?? e), durationMs: Date.now() - t0 });
  }
}

async function test_addProduct() {
  const t0 = Date.now();
  try {
    const beforeCount = await readView("productCount", []) as bigint;
    const hash = await ownerWrite("addProduct", [product("NewOne", 5_000_000n)]);
    const receipt = await waitTx(hash);

    if (receipt.status !== "success") {
      log({ testName: "addProduct", status: "FAIL", detail: `reverted hash=${hash}`, durationMs: Date.now() - t0 });
      return;
    }

    const afterCount = await readView("productCount", []) as bigint;
    if (afterCount !== beforeCount + 1n) {
      log({ testName: "addProduct: productCount incremented", status: "FAIL", expected: String(beforeCount + 1n), actual: String(afterCount), durationMs: Date.now() - t0 });
      return;
    }

    // New product id = _productCounter which was incremented by initProducts(4) = 4; addProduct → 5
    const newId = beforeCount + 1n; // same as afterCount if productCount tracks live entries
    // Actually after initProducts(4): productCount=4, _productCounter=4. addProduct → _productCounter=5, productCount=5
    // So newId by id = afterCount
    const prod = await readView("getProduct", [afterCount]) as any;
    if (prod.name !== "Product NewOne") {
      // Try with afterCount as id first, then beforeCount+1 (they should be same here)
      log({ testName: "addProduct: stored correctly", status: "FAIL", expected: "Product NewOne", actual: prod.name, durationMs: Date.now() - t0 });
      return;
    }
    if (prod.priceUsdc !== 5_000_000n) {
      log({ testName: "addProduct: priceUsdc stored", status: "FAIL", expected: "5000000", actual: String(prod.priceUsdc), durationMs: Date.now() - t0 });
      return;
    }

    log({ testName: "addProduct", status: "PASS", detail: `hash=${hash} id=${afterCount} count=${afterCount}`, durationMs: Date.now() - t0 });
  } catch (e: any) {
    log({ testName: "addProduct", status: "FAIL", detail: String(e?.message ?? e), durationMs: Date.now() - t0 });
  }
}

async function test_nonOwnerCannotAddProduct() {
  const t0 = Date.now();
  try {
    const reverted = await expectWriteReverts(NON_OWNER, "addProduct", [product("Hack")]);
    if (reverted) {
      log({ testName: "addProduct: non-owner reverts (OwnableUnauthorizedAccount)", status: "PASS", detail: "reverted as expected", durationMs: Date.now() - t0 });
    } else {
      log({ testName: "addProduct: non-owner reverts (OwnableUnauthorizedAccount)", status: "FAIL", expected: "revert", actual: "success", durationMs: Date.now() - t0 });
    }
  } catch (e: any) {
    log({ testName: "addProduct: non-owner reverts (OwnableUnauthorizedAccount)", status: "FAIL", detail: String(e?.message ?? e), durationMs: Date.now() - t0 });
  }
}

async function test_updateProduct() {
  const t0 = Date.now();
  try {
    const updated = {
      name: "Updated Phin",
      nameVi: "Phin Cập Nhật",
      description: "New desc",
      priceUsdc: 4_500_000n,
      category: "Coffee",
      imageUrl: "https://cdn.vietphin.test/updated.jpg",
      isFeatured: true,
      isHidden: false,
      isPaused: false,
    };

    const hash = await ownerWrite("updateProduct", [1n, updated]);
    const receipt = await waitTx(hash);

    if (receipt.status !== "success") {
      log({ testName: "updateProduct(id=1)", status: "FAIL", detail: `reverted hash=${hash}`, durationMs: Date.now() - t0 });
      return;
    }

    const prod = await readView("getProduct", [1n]) as any;
    if (prod.name !== "Updated Phin" || prod.priceUsdc !== 4_500_000n || !prod.isFeatured) {
      log({ testName: "updateProduct(id=1): fields updated", status: "FAIL", expected: `name="Updated Phin" price=4500000 isFeatured=true`, actual: `name="${prod.name}" price=${prod.priceUsdc} isFeatured=${prod.isFeatured}`, durationMs: Date.now() - t0 });
      return;
    }

    log({ testName: "updateProduct(id=1)", status: "PASS", detail: `hash=${hash} name="${prod.name}" price=${prod.priceUsdc} isFeatured=${prod.isFeatured}`, durationMs: Date.now() - t0 });
  } catch (e: any) {
    log({ testName: "updateProduct(id=1)", status: "FAIL", detail: String(e?.message ?? e), durationMs: Date.now() - t0 });
  }
}

async function test_updateProductNotFound() {
  const t0 = Date.now();
  try {
    const reverted = await expectWriteReverts(OWNER, "updateProduct", [9999n, product("Ghost")]);
    if (reverted) {
      log({ testName: "updateProduct: ProductNotFound guard", status: "PASS", detail: "reverted for non-existent id=9999", durationMs: Date.now() - t0 });
    } else {
      log({ testName: "updateProduct: ProductNotFound guard", status: "FAIL", expected: "revert ProductNotFound", actual: "success", durationMs: Date.now() - t0 });
    }
  } catch (e: any) {
    log({ testName: "updateProduct: ProductNotFound guard", status: "FAIL", detail: String(e?.message ?? e), durationMs: Date.now() - t0 });
  }
}

async function test_deleteProduct() {
  const t0 = Date.now();
  try {
    const beforeCount = await readView("productCount", []) as bigint;

    // Delete id=2 ("Product B", from initProducts)
    const hash = await ownerWrite("deleteProduct", [2n]);
    const receipt = await waitTx(hash);

    if (receipt.status !== "success") {
      log({ testName: "deleteProduct(id=2)", status: "FAIL", detail: `reverted hash=${hash}`, durationMs: Date.now() - t0 });
      return;
    }

    const afterCount = await readView("productCount", []) as bigint;
    if (afterCount !== beforeCount - 1n) {
      log({ testName: "deleteProduct: productCount decremented", status: "FAIL", expected: String(beforeCount - 1n), actual: String(afterCount), durationMs: Date.now() - t0 });
      return;
    }

    const reverted = await expectViewReverts("getProduct", [2n]);
    if (!reverted) {
      log({ testName: "deleteProduct: getProduct(2) reverts", status: "FAIL", expected: "revert ProductNotFound", actual: "returned data", durationMs: Date.now() - t0 });
      return;
    }

    log({ testName: "deleteProduct(id=2)", status: "PASS", detail: `hash=${hash} count=${afterCount} getProduct(2) reverts`, durationMs: Date.now() - t0 });
  } catch (e: any) {
    log({ testName: "deleteProduct(id=2)", status: "FAIL", detail: String(e?.message ?? e), durationMs: Date.now() - t0 });
  }
}

async function test_deleteProductAlreadyDeleted() {
  const t0 = Date.now();
  try {
    // id=2 already deleted above
    const reverted = await expectWriteReverts(OWNER, "deleteProduct", [2n]);
    if (reverted) {
      log({ testName: "deleteProduct: already-deleted reverts", status: "PASS", detail: "reverted with ProductNotFound", durationMs: Date.now() - t0 });
    } else {
      log({ testName: "deleteProduct: already-deleted reverts", status: "FAIL", expected: "revert ProductNotFound", actual: "success", durationMs: Date.now() - t0 });
    }
  } catch (e: any) {
    log({ testName: "deleteProduct: already-deleted reverts", status: "FAIL", detail: String(e?.message ?? e), durationMs: Date.now() - t0 });
  }
}

async function test_setProductHidden() {
  const t0 = Date.now();
  try {
    // Product id=3 ("Product C") — set hidden=true
    const hash = await ownerWrite("setProductHidden", [3n, true]);
    const receipt = await waitTx(hash);

    if (receipt.status !== "success") {
      log({ testName: "setProductHidden(id=3, true)", status: "FAIL", detail: `reverted hash=${hash}`, durationMs: Date.now() - t0 });
      return;
    }

    const prod = await readView("getProduct", [3n]) as any;
    if (!prod.isHidden) {
      log({ testName: "setProductHidden(id=3, true)", status: "FAIL", expected: "isHidden=true", actual: String(prod.isHidden), durationMs: Date.now() - t0 });
      return;
    }

    log({ testName: "setProductHidden(id=3, true)", status: "PASS", detail: `hash=${hash} isHidden=${prod.isHidden}`, durationMs: Date.now() - t0 });
  } catch (e: any) {
    log({ testName: "setProductHidden(id=3, true)", status: "FAIL", detail: String(e?.message ?? e), durationMs: Date.now() - t0 });
  }
}

async function test_setProductPaused() {
  const t0 = Date.now();
  try {
    const hash = await ownerWrite("setProductPaused", [3n, true]);
    const receipt = await waitTx(hash);

    if (receipt.status !== "success") {
      log({ testName: "setProductPaused(id=3, true)", status: "FAIL", detail: `reverted hash=${hash}`, durationMs: Date.now() - t0 });
      return;
    }

    const prod = await readView("getProduct", [3n]) as any;
    if (!prod.isPaused) {
      log({ testName: "setProductPaused(id=3, true)", status: "FAIL", expected: "isPaused=true", actual: String(prod.isPaused), durationMs: Date.now() - t0 });
      return;
    }

    log({ testName: "setProductPaused(id=3, true)", status: "PASS", detail: `hash=${hash} isPaused=${prod.isPaused}`, durationMs: Date.now() - t0 });
  } catch (e: any) {
    log({ testName: "setProductPaused(id=3, true)", status: "FAIL", detail: String(e?.message ?? e), durationMs: Date.now() - t0 });
  }
}

async function test_setProductFeatured() {
  const t0 = Date.now();
  try {
    const hash = await ownerWrite("setProductFeatured", [3n, true]);
    const receipt = await waitTx(hash);

    if (receipt.status !== "success") {
      log({ testName: "setProductFeatured(id=3, true)", status: "FAIL", detail: `reverted hash=${hash}`, durationMs: Date.now() - t0 });
      return;
    }

    const prod = await readView("getProduct", [3n]) as any;
    if (!prod.isFeatured) {
      log({ testName: "setProductFeatured(id=3, true)", status: "FAIL", expected: "isFeatured=true", actual: String(prod.isFeatured), durationMs: Date.now() - t0 });
      return;
    }

    log({ testName: "setProductFeatured(id=3, true)", status: "PASS", detail: `hash=${hash} isFeatured=${prod.isFeatured}`, durationMs: Date.now() - t0 });
  } catch (e: any) {
    log({ testName: "setProductFeatured(id=3, true)", status: "FAIL", detail: String(e?.message ?? e), durationMs: Date.now() - t0 });
  }
}

async function test_setProductFlagNonOwnerReverts() {
  const t0 = Date.now();
  try {
    const reverted = await expectWriteReverts(NON_OWNER, "setProductHidden", [3n, false]);
    if (reverted) {
      log({ testName: "setProductHidden: non-owner reverts", status: "PASS", detail: "OwnableUnauthorizedAccount", durationMs: Date.now() - t0 });
    } else {
      log({ testName: "setProductHidden: non-owner reverts", status: "FAIL", expected: "revert", actual: "success", durationMs: Date.now() - t0 });
    }
  } catch (e: any) {
    log({ testName: "setProductHidden: non-owner reverts", status: "FAIL", detail: String(e?.message ?? e), durationMs: Date.now() - t0 });
  }
}

async function test_getProductsPagination() {
  const t0 = Date.now();
  try {
    // State at this point: initProducts(4) + addProduct(1) - deleteProduct(1 via id=2) = 4 live products
    const totalCount = await readView("productCount", []) as bigint;

    // offset=0, limit=2 → exactly 2
    const page = await readView("getProducts", [0n, 2n]) as any[];
    if (page.length !== 2) {
      log({ testName: "getProducts: offset=0 limit=2 returns 2", status: "FAIL", expected: "2", actual: String(page.length), durationMs: Date.now() - t0 });
      return;
    }

    // offset=0, limit=0 → all (totalCount)
    const all = await readView("getProducts", [0n, 0n]) as any[];
    if (BigInt(all.length) !== totalCount) {
      log({ testName: "getProducts: limit=0 returns all", status: "FAIL", expected: String(totalCount), actual: String(all.length), durationMs: Date.now() - t0 });
      return;
    }

    // offset >= totalCount → empty
    const empty = await readView("getProducts", [totalCount, 0n]) as any[];
    if (empty.length !== 0) {
      log({ testName: "getProducts: offset>=count returns empty", status: "FAIL", expected: "0", actual: String(empty.length), durationMs: Date.now() - t0 });
      return;
    }

    log({ testName: "getProducts pagination", status: "PASS", detail: `totalCount=${totalCount} page(0,2)=${page.length} all(0,0)=${all.length} empty(${totalCount},0)=${empty.length}`, durationMs: Date.now() - t0 });
  } catch (e: any) {
    log({ testName: "getProducts pagination", status: "FAIL", detail: String(e?.message ?? e), durationMs: Date.now() - t0 });
  }
}

async function test_renounceOwnershipDisabled() {
  const t0 = Date.now();
  try {
    const reverted = await expectWriteReverts(OWNER, "renounceOwnership", []);
    if (reverted) {
      log({ testName: "renounceOwnership: RenounceOwnershipDisabled", status: "PASS", detail: "reverted as expected", durationMs: Date.now() - t0 });
    } else {
      log({ testName: "renounceOwnership: RenounceOwnershipDisabled", status: "FAIL", expected: "revert RenounceOwnershipDisabled", actual: "success", durationMs: Date.now() - t0 });
    }
  } catch (e: any) {
    log({ testName: "renounceOwnership: RenounceOwnershipDisabled", status: "FAIL", detail: String(e?.message ?? e), durationMs: Date.now() - t0 });
  }
}

async function test_placeOrderInvalidAmount() {
  const t0 = Date.now();
  try {
    const reverted = await expectWriteReverts(CUSTOMER, "placeOrder", [
      0n,
      BigInt(Math.floor(Date.now() / 1000) + 3600),
      keccak256(toBytes("zero-amount")),
    ]);
    if (reverted) {
      log({ testName: "placeOrder: InvalidAmount guard", status: "PASS", detail: "reverted as expected", durationMs: Date.now() - t0 });
    } else {
      log({ testName: "placeOrder: InvalidAmount guard", status: "FAIL", expected: "revert InvalidAmount", actual: "success", durationMs: Date.now() - t0 });
    }
  } catch (e: any) {
    log({ testName: "placeOrder: InvalidAmount guard", status: "FAIL", detail: String(e?.message ?? e), durationMs: Date.now() - t0 });
  }
}

async function test_placeOrderInvalidPickupTime() {
  const t0 = Date.now();
  try {
    const reverted = await expectWriteReverts(CUSTOMER, "placeOrder", [
      1_000_000n,
      BigInt(Math.floor(Date.now() / 1000) - 3600), // past
      keccak256(toBytes("past-pickup")),
    ]);
    if (reverted) {
      log({ testName: "placeOrder: InvalidPickupTime guard", status: "PASS", detail: "reverted as expected", durationMs: Date.now() - t0 });
    } else {
      log({ testName: "placeOrder: InvalidPickupTime guard", status: "FAIL", expected: "revert InvalidPickupTime", actual: "success", durationMs: Date.now() - t0 });
    }
  } catch (e: any) {
    log({ testName: "placeOrder: InvalidPickupTime guard", status: "FAIL", detail: String(e?.message ?? e), durationMs: Date.now() - t0 });
  }
}

async function test_placeOrder() {
  const t0 = Date.now();
  try {
    await impersonate(CUSTOMER);
    await setBalance(CUSTOMER);

    // Attempt USDC ERC-20 approve
    let approveOk = false;
    let approveHash: Hex | null = null;
    try {
      const wc = walletClientFor(CUSTOMER);
      approveHash = await wc.writeContract({
        address: USDC,
        abi: ERC20_APPROVE_ABI,
        functionName: "approve",
        args: [CONTRACT, 10_000_000n],
      });
      const r = await waitTx(approveHash);
      approveOk = r.status === "success";
    } catch {
      approveOk = false;
    }

    if (!approveOk) {
      await stopImpersonate(CUSTOMER).catch(() => {});
      log({
        testName: "placeOrder",
        status: "SKIPPED",
        detail: `Arc USDC precompile: ERC-20 approve reverted/failed (approveHash=${approveHash ?? "n/a"}) — placeOrder skipped (expected Arc caveat, safeTransferFrom would also fail)`,
        durationMs: Date.now() - t0,
      });
      return;
    }

    // Attempt placeOrder
    const pickupTime = BigInt(Math.floor(Date.now() / 1000) + 3600);
    const itemsHash = keccak256(toBytes("test-order-1"));
    const amount = 3_000_000n;

    let orderHash: Hex | null = null;
    let orderReverted = false;

    try {
      const wc = walletClientFor(CUSTOMER);
      orderHash = await wc.writeContract({
        address: CONTRACT,
        abi: ABI,
        functionName: "placeOrder",
        args: [amount, pickupTime, itemsHash],
      });
      const receipt = await waitTx(orderHash);
      orderReverted = receipt.status !== "success";
    } catch {
      orderReverted = true;
    }

    await stopImpersonate(CUSTOMER).catch(() => {});

    if (orderReverted) {
      log({
        testName: "placeOrder",
        status: "SKIPPED",
        detail: `Arc USDC precompile: safeTransferFrom reverted — expected on Arc fork (hash=${orderHash ?? "n/a"})`,
        durationMs: Date.now() - t0,
      });
      return;
    }

    // Verify state
    const orderId = await readView("orderCount", []) as bigint;
    const orderData = await readView("getOrder", [orderId]) as any;

    const errors: string[] = [];
    if ((orderData.customer as string).toLowerCase() !== CUSTOMER.toLowerCase())
      errors.push(`customer ${orderData.customer}!=${CUSTOMER}`);
    if (orderData.totalAmountUsdc !== amount)
      errors.push(`amount ${orderData.totalAmountUsdc}!=${amount}`);
    if (Number(orderData.status) !== 0)
      errors.push(`status ${orderData.status}!=0(Received)`);

    const escrowed = await readView("totalEscrowed", []) as bigint;
    if (escrowed < amount) errors.push(`escrowed ${escrowed}<${amount}`);

    const pts = await readView("getLoyaltyPoints", [CUSTOMER]) as bigint;
    const expectedPts = amount / 1_000_000n;
    if (pts !== expectedPts) errors.push(`loyaltyPoints ${pts}!=${expectedPts}`);

    if (errors.length > 0) {
      log({ testName: "placeOrder", status: "FAIL", detail: errors.join("; "), durationMs: Date.now() - t0 });
    } else {
      log({ testName: "placeOrder", status: "PASS", detail: `hash=${orderHash} orderId=${orderId} escrowed=${escrowed} loyaltyPts=${pts}`, durationMs: Date.now() - t0 });
    }
  } catch (e: any) {
    await stopImpersonate(CUSTOMER).catch(() => {});
    log({ testName: "placeOrder", status: "FAIL", detail: String(e?.message ?? e), durationMs: Date.now() - t0 });
  }
}

async function test_receiveEthReverts() {
  const t0 = Date.now();
  try {
    await impersonate(CUSTOMER);
    await setBalance(CUSTOMER);

    let reverted = false;
    try {
      const wc = walletClientFor(CUSTOMER);
      const hash = await wc.sendTransaction({ to: CONTRACT, value: 1n });
      const receipt = await waitTx(hash);
      reverted = receipt.status === "reverted";
    } catch {
      reverted = true;
    }

    await stopImpersonate(CUSTOMER).catch(() => {});

    if (reverted) {
      log({ testName: "receive(): ETH rejected", status: "PASS", detail: "reverted as expected", durationMs: Date.now() - t0 });
    } else {
      log({ testName: "receive(): ETH rejected", status: "FAIL", expected: "revert", actual: "ETH accepted", durationMs: Date.now() - t0 });
    }
  } catch (e: any) {
    await stopImpersonate(CUSTOMER).catch(() => {});
    log({ testName: "receive(): ETH rejected", status: "FAIL", detail: String(e?.message ?? e), durationMs: Date.now() - t0 });
  }
}

// ---------------------------------------------------------------------------
// Run all tests in order
// ---------------------------------------------------------------------------
async function main() {
  console.error("[VietPhin fork-verify] Starting...");

  await test_constructorState();
  await test_initProducts();
  await test_initProductsAlreadyInitialized();
  await test_addProduct();
  await test_nonOwnerCannotAddProduct();
  await test_updateProduct();
  await test_updateProductNotFound();
  await test_deleteProduct();
  await test_deleteProductAlreadyDeleted();
  await test_setProductHidden();
  await test_setProductPaused();
  await test_setProductFeatured();
  await test_setProductFlagNonOwnerReverts();
  await test_getProductsPagination();
  await test_renounceOwnershipDisabled();
  await test_placeOrderInvalidAmount();
  await test_placeOrderInvalidPickupTime();
  await test_placeOrder();
  await test_receiveEthReverts();

  const passed = results.filter((r) => r.status === "PASS").length;
  const failed = results.filter((r) => r.status === "FAIL").length;
  const skipped = results.filter((r) => r.status === "SKIPPED").length;

  console.error(`\n[VietPhin fork-verify] Done: ${passed} passed, ${failed} failed, ${skipped} skipped.`);
  process.exit(failures > 0 ? 1 : 0);
}

main().catch((e) => {
  console.error("[FATAL]", e);
  process.exit(1);
});
