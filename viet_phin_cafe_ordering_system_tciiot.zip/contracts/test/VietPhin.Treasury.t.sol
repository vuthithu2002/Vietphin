// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {VietPhinTestBase} from "./VietPhin.Base.t.sol";
import {VietPhin} from "../VietPhin.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";

contract VietPhinTreasuryTest is VietPhinTestBase {

    // ── proposeTreasury ───────────────────────────────────────────────────────

    function test_ProposeTreasury_SetsPendingTreasury() public {
        vm.prank(owner);
        viet.proposeTreasury(newTreasury);
        assertEq(viet.pendingTreasury(), newTreasury);
    }

    function test_ProposeTreasury_EmitsTreasuryUpdateProposed() public {
        vm.prank(owner);
        vm.expectEmit(true, false, false, false, address(viet));
        emit VietPhin.TreasuryUpdateProposed(newTreasury);
        viet.proposeTreasury(newTreasury);
    }

    function test_ProposeTreasury_RevertsIfNonOwner() public {
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, alice)
        );
        viet.proposeTreasury(newTreasury);
    }

    function test_ProposeTreasury_RevertsOnZeroAddress() public {
        vm.prank(owner);
        vm.expectRevert(VietPhin.ZeroAddress.selector);
        viet.proposeTreasury(address(0));
    }

    // ── acceptTreasury ────────────────────────────────────────────────────────

    function test_AcceptTreasury_UpdatesTreasury() public {
        vm.prank(owner);
        viet.proposeTreasury(newTreasury);

        vm.prank(newTreasury);
        viet.acceptTreasury();

        assertEq(viet.treasury(), newTreasury);
    }

    function test_AcceptTreasury_ClearsPendingTreasury() public {
        vm.prank(owner);
        viet.proposeTreasury(newTreasury);

        vm.prank(newTreasury);
        viet.acceptTreasury();

        assertEq(viet.pendingTreasury(), address(0));
    }

    function test_AcceptTreasury_EmitsTreasuryUpdated() public {
        vm.prank(owner);
        viet.proposeTreasury(newTreasury);

        vm.prank(newTreasury);
        vm.expectEmit(true, true, false, false, address(viet));
        emit VietPhin.TreasuryUpdated(owner, newTreasury);
        viet.acceptTreasury();
    }

    function test_AcceptTreasury_RevertsIfWrongAcceptor() public {
        vm.prank(owner);
        viet.proposeTreasury(newTreasury);

        // alice is not the pending treasury — reverts NotPendingTreasury(alice, newTreasury)
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(VietPhin.NotPendingTreasury.selector, alice, newTreasury)
        );
        viet.acceptTreasury();
    }

    function test_AcceptTreasury_RevertsIfNoPendingProposal() public {
        // pendingTreasury is address(0) initially — reverts NotPendingTreasury(alice, address(0))
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(VietPhin.NotPendingTreasury.selector, alice, address(0))
        );
        viet.acceptTreasury();
    }

    // ── two-step flow end-to-end ──────────────────────────────────────────────

    function test_TwoStepTreasury_EndToEnd() public {
        address initialTreasury = viet.treasury();
        assertEq(initialTreasury, owner);

        vm.prank(owner);
        viet.proposeTreasury(newTreasury);
        assertEq(viet.pendingTreasury(), newTreasury);
        // treasury unchanged until accepted
        assertEq(viet.treasury(), owner);

        vm.prank(newTreasury);
        viet.acceptTreasury();

        assertEq(viet.treasury(), newTreasury);
        assertEq(viet.pendingTreasury(), address(0));
    }

    // ── setTreasury must NOT exist ────────────────────────────────────────────

    function test_SetTreasury_FunctionDoesNotExist() public {
        bytes memory callData = abi.encodeWithSignature("setTreasury(address)", newTreasury);
        (bool success, ) = address(viet).call(callData);
        assertFalse(success, "setTreasury should not exist on VietPhin");
    }
}
