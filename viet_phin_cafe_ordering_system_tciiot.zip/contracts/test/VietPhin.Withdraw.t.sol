// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {VietPhinTestBase} from "./VietPhin.Base.t.sol";
import {VietPhin} from "../VietPhin.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";

contract VietPhinWithdrawUSDCTest is VietPhinTestBase {

    // ── cannot withdraw escrowed funds ────────────────────────────────────────

    function test_WithdrawUSDC_CannotWithdrawEscrowedFunds() public {
        // Place an order — those funds are escrowed, no surplus yet.
        _placeAliceOrder();

        // surplus = balance - totalEscrowed = 0
        vm.prank(owner);
        vm.expectRevert(
            abi.encodeWithSelector(VietPhin.InsufficientSurplus.selector, ORDER_AMOUNT, 0)
        );
        viet.withdrawUSDC(owner, ORDER_AMOUNT);
    }

    // ── can withdraw surplus ──────────────────────────────────────────────────

    function test_WithdrawUSDC_CanWithdrawSurplus() public {
        // Donate USDC directly to the contract (bypassing placeOrder) = pure surplus.
        uint256 surplus = 50e6;
        usdc.mint(address(viet), surplus);

        uint256 ownerBefore = usdc.balanceOf(owner);
        vm.prank(owner);
        viet.withdrawUSDC(owner, surplus);

        assertEq(usdc.balanceOf(owner), ownerBefore + surplus);
    }

    function test_WithdrawUSDC_OnlySurplusWithEscrowPresent() public {
        // Place an order (escrowed) AND donate surplus.
        _placeAliceOrder();
        uint256 surplus = 25e6;
        usdc.mint(address(viet), surplus);

        // Should be able to withdraw exactly the surplus.
        uint256 ownerBefore = usdc.balanceOf(owner);
        vm.prank(owner);
        viet.withdrawUSDC(owner, surplus);

        assertEq(usdc.balanceOf(owner), ownerBefore + surplus);
        // The escrowed amount must remain intact.
        assertEq(viet.totalEscrowed(), ORDER_AMOUNT);
    }

    function test_WithdrawUSDC_CannotWithdrawMoreThanSurplus() public {
        uint256 surplus = 20e6;
        usdc.mint(address(viet), surplus);

        uint256 overRequest = surplus + 1;
        vm.prank(owner);
        vm.expectRevert(
            abi.encodeWithSelector(VietPhin.InsufficientSurplus.selector, overRequest, surplus)
        );
        viet.withdrawUSDC(owner, overRequest);
    }

    function test_WithdrawUSDC_RevertsOnZeroAmount() public {
        vm.prank(owner);
        vm.expectRevert(VietPhin.InvalidAmount.selector);
        viet.withdrawUSDC(owner, 0);
    }

    function test_WithdrawUSDC_RevertsOnZeroToAddress() public {
        usdc.mint(address(viet), 10e6);
        vm.prank(owner);
        vm.expectRevert(VietPhin.ZeroAddress.selector);
        viet.withdrawUSDC(address(0), 10e6);
    }

    function test_WithdrawUSDC_RevertsIfNonOwner() public {
        usdc.mint(address(viet), 10e6);
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, alice)
        );
        viet.withdrawUSDC(alice, 10e6);
    }

    function test_WithdrawUSDC_PartialSurplusWithdrawal() public {
        uint256 surplus = 60e6;
        usdc.mint(address(viet), surplus);

        // Withdraw half.
        vm.prank(owner);
        viet.withdrawUSDC(owner, 30e6);

        // Remaining surplus: 30e6 — can still withdraw.
        vm.prank(owner);
        viet.withdrawUSDC(owner, 30e6);

        // Now nothing left.
        vm.prank(owner);
        vm.expectRevert(
            abi.encodeWithSelector(VietPhin.InsufficientSurplus.selector, 1, 0)
        );
        viet.withdrawUSDC(owner, 1);
    }

    // ── fuzz: surplus invariant ───────────────────────────────────────────────

    function testFuzz_WithdrawUSDC_NeverDipsIntoEscrow(uint96 surplus) public {
        surplus = uint96(bound(surplus, 1, 500e6));

        // Place an order to create escrow.
        _placeAliceOrder();
        usdc.mint(address(viet), surplus);

        // Withdraw all surplus.
        vm.prank(owner);
        viet.withdrawUSDC(owner, surplus);

        // totalEscrowed must still equal the original order amount.
        assertEq(viet.totalEscrowed(), ORDER_AMOUNT);
        // Contract balance should be exactly totalEscrowed.
        assertEq(usdc.balanceOf(address(viet)), ORDER_AMOUNT);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// withdrawAll tests
// ─────────────────────────────────────────────────────────────────────────────

contract VietPhinWithdrawAllTest is VietPhinTestBase {

    // ── helper: place two orders from alice ──────────────────────────────────

    function _placeTwoOrders() internal returns (uint256 id1, uint256 id2) {
        uint256 pickup = block.timestamp + 1 hours;
        vm.startPrank(alice);
        id1 = viet.placeOrder(ORDER_AMOUNT, pickup, ITEMS_HASH);
        id2 = viet.placeOrder(ORDER_AMOUNT, pickup, ITEMS_HASH);
        vm.stopPrank();
    }

    // ── 1. Happy path: two orders → withdrawAll drains escrow ────────────────

    function test_WithdrawAll_HappyPath_TwoOrders() public {
        _placeTwoOrders();

        uint256 expected = ORDER_AMOUNT * 2;

        // Pre-conditions
        assertEq(usdc.balanceOf(address(viet)), expected, "contract balance before");
        assertEq(viet.totalEscrowed(), expected, "totalEscrowed before");

        uint256 ownerBefore = usdc.balanceOf(owner);

        // Expect the WithdrawnAll event with correct args
        vm.expectEmit(true, false, false, true, address(viet));
        emit VietPhin.WithdrawnAll(owner, expected);

        vm.prank(owner);
        viet.withdrawAll(owner);

        // Post-conditions
        assertEq(usdc.balanceOf(owner), ownerBefore + expected, "owner received all USDC");
        assertEq(usdc.balanceOf(address(viet)), 0, "contract balance after");
        assertEq(viet.totalEscrowed(), 0, "totalEscrowed reset to 0");
    }

    // ── 2. Reverts ZeroAddress when `to` is address(0) ───────────────────────

    function test_WithdrawAll_RevertsZeroAddress() public {
        // Fund the contract so the balance check is not hit first
        usdc.mint(address(viet), 1e6);

        vm.prank(owner);
        vm.expectRevert(VietPhin.ZeroAddress.selector);
        viet.withdrawAll(address(0));
    }

    // ── 3. Reverts InvalidAmount when contract USDC balance is 0 ─────────────

    function test_WithdrawAll_RevertsInvalidAmount_WhenBalanceIsZero() public {
        // No funds at all in the contract
        assertEq(usdc.balanceOf(address(viet)), 0);

        vm.prank(owner);
        vm.expectRevert(VietPhin.InvalidAmount.selector);
        viet.withdrawAll(owner);
    }

    // ── 4. Reverts when called by non-owner ───────────────────────────────────

    function test_WithdrawAll_RevertsIfNonOwner() public {
        usdc.mint(address(viet), 10e6);

        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, alice)
        );
        viet.withdrawAll(alice);
    }

    // ── 5. Drains both escrowed AND surplus funds ─────────────────────────────

    function test_WithdrawAll_DrainsEscrowAndSurplus() public {
        // Place one order → escrow ORDER_AMOUNT
        _placeAliceOrder();

        // Donate surplus directly to the contract
        uint256 surplus = 75e6;
        usdc.mint(address(viet), surplus);

        uint256 totalExpected = ORDER_AMOUNT + surplus;

        assertEq(usdc.balanceOf(address(viet)), totalExpected, "contract balance before");
        assertEq(viet.totalEscrowed(), ORDER_AMOUNT, "escrowed before");

        address recipient = makeAddr("recipient");
        uint256 recipientBefore = usdc.balanceOf(recipient);

        vm.expectEmit(true, false, false, true, address(viet));
        emit VietPhin.WithdrawnAll(recipient, totalExpected);

        vm.prank(owner);
        viet.withdrawAll(recipient);

        // All USDC (escrow + surplus) went to recipient
        assertEq(usdc.balanceOf(recipient), recipientBefore + totalExpected, "recipient received all");
        assertEq(usdc.balanceOf(address(viet)), 0, "contract empty after");
        assertEq(viet.totalEscrowed(), 0, "totalEscrowed reset to 0");
    }
}
