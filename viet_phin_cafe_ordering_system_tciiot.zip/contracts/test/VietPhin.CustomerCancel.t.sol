// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {VietPhinTestBase} from "./VietPhin.Base.t.sol";
import {VietPhin} from "../VietPhin.sol";

contract VietPhinCustomerCancelTest is VietPhinTestBase {
    uint256 internal orderId;
    uint256 internal pickupTime;

    function setUp() public override {
        super.setUp();
        pickupTime = block.timestamp + 1 hours;
        vm.prank(alice);
        orderId = viet.placeOrder(ORDER_AMOUNT, pickupTime, ITEMS_HASH);
    }

    // ── happy path: after pickupTime + 2 h ───────────────────────────────────

    function test_CustomerCancel_StatusBecomesCancelled() public {
        vm.warp(pickupTime + 2 hours + 1);
        vm.prank(alice);
        viet.customerCancel(orderId);
        assertEq(uint8(viet.getOrder(orderId).status), uint8(VietPhin.OrderStatus.Cancelled));
    }

    function test_CustomerCancel_RefundsCustomer() public {
        uint256 aliceBefore = usdc.balanceOf(alice);
        vm.warp(pickupTime + 2 hours + 1);
        vm.prank(alice);
        viet.customerCancel(orderId);
        assertEq(usdc.balanceOf(alice), aliceBefore + ORDER_AMOUNT);
    }

    function test_CustomerCancel_DecrementsTotalEscrowed() public {
        vm.warp(pickupTime + 2 hours + 1);
        vm.prank(alice);
        viet.customerCancel(orderId);
        assertEq(viet.totalEscrowed(), 0);
    }

    function test_CustomerCancel_EmitsRefunded() public {
        vm.warp(pickupTime + 2 hours + 1);
        vm.prank(alice);
        vm.expectEmit(true, true, false, true, address(viet));
        emit VietPhin.Refunded(orderId, alice, ORDER_AMOUNT);
        viet.customerCancel(orderId);
    }

    function test_CustomerCancel_EmitsOrderStatusUpdated() public {
        vm.warp(pickupTime + 2 hours + 1);
        vm.prank(alice);
        vm.expectEmit(true, false, false, true, address(viet));
        emit VietPhin.OrderStatusUpdated(orderId, VietPhin.OrderStatus.Cancelled, alice);
        viet.customerCancel(orderId);
    }

    function test_CustomerCancel_DeductsLoyaltyPoints() public {
        uint256 pointsBefore = viet.getLoyaltyPoints(alice);
        vm.warp(pickupTime + 2 hours + 1);
        vm.prank(alice);
        viet.customerCancel(orderId);
        uint256 deducted = ORDER_AMOUNT / 1e6;
        uint256 expected = pointsBefore >= deducted ? pointsBefore - deducted : 0;
        assertEq(viet.getLoyaltyPoints(alice), expected);
    }

    // ── revert: too early ─────────────────────────────────────────────────────

    function test_CustomerCancel_RevertsTooEarly_BeforePickup() public {
        // Still before pickupTime — definitely too early
        uint256 earliest = pickupTime + 2 hours;
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(VietPhin.TooEarlyToCancel.selector, orderId, earliest)
        );
        viet.customerCancel(orderId);
    }

    function test_CustomerCancel_RevertsTooEarly_RightAtPickupTime() public {
        // Exactly at pickupTime — still too early (must be >= pickupTime + 2h)
        uint256 earliest = pickupTime + 2 hours;
        vm.warp(pickupTime);
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(VietPhin.TooEarlyToCancel.selector, orderId, earliest)
        );
        viet.customerCancel(orderId);
    }

    function test_CustomerCancel_RevertsTooEarly_JustBeforeWindow() public {
        // One second before the 2-hour window opens
        uint256 earliest = pickupTime + 2 hours;
        vm.warp(earliest - 1);
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(VietPhin.TooEarlyToCancel.selector, orderId, earliest)
        );
        viet.customerCancel(orderId);
    }

    // ── revert: wrong caller ──────────────────────────────────────────────────

    function test_CustomerCancel_RevertsIfWrongCaller() public {
        vm.warp(pickupTime + 2 hours + 1);
        vm.prank(bob);
        vm.expectRevert(
            abi.encodeWithSelector(VietPhin.NotOrderCustomer.selector, orderId, bob)
        );
        viet.customerCancel(orderId);
    }

    // ── revert: already finalized ─────────────────────────────────────────────

    function test_CustomerCancel_RevertsIfAlreadyCancelled() public {
        vm.warp(pickupTime + 2 hours + 1);
        vm.prank(alice);
        viet.customerCancel(orderId);

        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(
                VietPhin.OrderAlreadyFinalized.selector,
                orderId,
                VietPhin.OrderStatus.Cancelled
            )
        );
        viet.customerCancel(orderId);
    }

    function test_CustomerCancel_RevertsIfAlreadyCompleted() public {
        _advanceToReady(orderId);
        vm.prank(owner);
        viet.completeOrder(orderId);

        vm.warp(pickupTime + 2 hours + 1);
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(
                VietPhin.OrderAlreadyFinalized.selector,
                orderId,
                VietPhin.OrderStatus.Completed
            )
        );
        viet.customerCancel(orderId);
    }

    function test_CustomerCancel_RevertsIfAlreadyRejected() public {
        vm.prank(owner);
        viet.rejectOrder(orderId);

        vm.warp(pickupTime + 2 hours + 1);
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(
                VietPhin.OrderAlreadyFinalized.selector,
                orderId,
                VietPhin.OrderStatus.Rejected
            )
        );
        viet.customerCancel(orderId);
    }

    // ── revert: order not found ───────────────────────────────────────────────

    function test_CustomerCancel_RevertsOnOrderNotFound() public {
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(VietPhin.OrderNotFound.selector, 999));
        viet.customerCancel(999);
    }
}
