// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {Test} from "forge-std/Test.sol";
import {VietPhin} from "../VietPhin.sol";
import {MockERC20} from "../test-helpers/MockERC20.sol";

/// @dev Shared setup, actors, constants, and helpers for all VietPhin test suites.
///      This contract contains NO test/fuzz/invariant functions.
abstract contract VietPhinTestBase is Test {
    // ── actors ────────────────────────────────────────────────────────────────
    address internal owner   = makeAddr("owner");
    address internal alice   = makeAddr("alice");
    address internal bob     = makeAddr("bob");
    address internal newTreasury = makeAddr("newTreasury");

    // ── constants ─────────────────────────────────────────────────────────────
    uint256 internal constant ORDER_AMOUNT  = 10e6;   // 10 USDC (6 dec)
    uint256 internal constant ALICE_BALANCE = 1_000e6;
    uint256 internal constant BOB_BALANCE   = 1_000e6;

    bytes32 internal constant ITEMS_HASH = keccak256("pho+springrolls");

    // ── state ─────────────────────────────────────────────────────────────────
    MockERC20 internal usdc;
    VietPhin  internal viet;

    // ── setUp ─────────────────────────────────────────────────────────────────
    function setUp() public virtual {
        usdc = new MockERC20("Mock USDC", "mUSDC", 6);

        vm.prank(owner);
        viet = new VietPhin(address(usdc), owner);

        // Fund test accounts and set allowances.
        usdc.mint(alice, ALICE_BALANCE);
        usdc.mint(bob,   BOB_BALANCE);

        vm.prank(alice);
        usdc.approve(address(viet), type(uint256).max);

        vm.prank(bob);
        usdc.approve(address(viet), type(uint256).max);
    }

    // ── helpers ───────────────────────────────────────────────────────────────

    /// Place a single order from alice with default values; returns the orderId.
    function _placeAliceOrder() internal returns (uint256 orderId) {
        uint256 pickup = block.timestamp + 1 hours;
        vm.prank(alice);
        orderId = viet.placeOrder(ORDER_AMOUNT, pickup, ITEMS_HASH);
    }

    /// Advance the order through Received → Preparing → ReadyForPickup.
    function _advanceToReady(uint256 orderId) internal {
        vm.startPrank(owner);
        viet.updateOrderStatus(orderId, VietPhin.OrderStatus.Preparing);
        viet.updateOrderStatus(orderId, VietPhin.OrderStatus.ReadyForPickup);
        vm.stopPrank();
    }
}
