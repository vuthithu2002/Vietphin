// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {VietPhinTestBase} from "./VietPhin.Base.t.sol";
import {VietPhin} from "../VietPhin.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";

// ─────────────────────────────────────────────────────────────────────────────
//  rejectOrder
// ─────────────────────────────────────────────────────────────────────────────
contract VietPhinRejectOrderTest is VietPhinTestBase {
    uint256 internal orderId;

    function setUp() public override {
        super.setUp();
        orderId = _placeAliceOrder();
    }

    // ── happy path ────────────────────────────────────────────────────────────

    function test_RejectOrder_StatusBecomesRejected() public {
        vm.prank(owner);
        viet.rejectOrder(orderId);
        assertEq(uint8(viet.getOrder(orderId).status), uint8(VietPhin.OrderStatus.Rejected));
    }

    function test_RejectOrder_RefundsCustomer() public {
        uint256 aliceBefore = usdc.balanceOf(alice);
        vm.prank(owner);
        viet.rejectOrder(orderId);
        assertEq(usdc.balanceOf(alice), aliceBefore + ORDER_AMOUNT);
    }

    function test_RejectOrder_DecrementsTotalEscrowed() public {
        vm.prank(owner);
        viet.rejectOrder(orderId);
        assertEq(viet.totalEscrowed(), 0);
    }

    function test_RejectOrder_EmitsOrderRejected() public {
        vm.prank(owner);
        vm.expectEmit(true, true, false, true, address(viet));
        emit VietPhin.OrderRejected(orderId, alice, ORDER_AMOUNT);
        viet.rejectOrder(orderId);
    }

    function test_RejectOrder_EmitsRefunded() public {
        vm.prank(owner);
        vm.expectEmit(true, true, false, true, address(viet));
        emit VietPhin.Refunded(orderId, alice, ORDER_AMOUNT);
        viet.rejectOrder(orderId);
    }

    function test_RejectOrder_EmitsOrderStatusUpdated() public {
        vm.prank(owner);
        vm.expectEmit(true, false, false, true, address(viet));
        emit VietPhin.OrderStatusUpdated(orderId, VietPhin.OrderStatus.Rejected, owner);
        viet.rejectOrder(orderId);
    }

    function test_RejectOrder_DeductsLoyaltyPoints() public {
        uint256 pointsBefore = viet.getLoyaltyPoints(alice);
        vm.prank(owner);
        viet.rejectOrder(orderId);
        uint256 expected = pointsBefore >= (ORDER_AMOUNT / 1e6) ? pointsBefore - ORDER_AMOUNT / 1e6 : 0;
        assertEq(viet.getLoyaltyPoints(alice), expected);
    }

    function test_RejectOrder_WorksWhenOrderIsPreparing() public {
        vm.prank(owner);
        viet.updateOrderStatus(orderId, VietPhin.OrderStatus.Preparing);
        vm.prank(owner);
        viet.rejectOrder(orderId);
        assertEq(uint8(viet.getOrder(orderId).status), uint8(VietPhin.OrderStatus.Rejected));
    }

    function test_RejectOrder_WorksWhenOrderIsReadyForPickup() public {
        _advanceToReady(orderId);
        vm.prank(owner);
        viet.rejectOrder(orderId);
        assertEq(uint8(viet.getOrder(orderId).status), uint8(VietPhin.OrderStatus.Rejected));
    }

    // ── revert: order not refundable (already Completed) ─────────────────────

    function test_RejectOrder_RevertsIfOrderCompleted() public {
        _advanceToReady(orderId);
        vm.prank(owner);
        viet.completeOrder(orderId);

        vm.prank(owner);
        vm.expectRevert(
            abi.encodeWithSelector(
                VietPhin.OrderNotRefundable.selector,
                orderId,
                VietPhin.OrderStatus.Completed
            )
        );
        viet.rejectOrder(orderId);
    }

    function test_RejectOrder_RevertsIfOrderCancelled() public {
        VietPhin.Order memory o = viet.getOrder(orderId);
        vm.warp(o.pickupTime + 2 hours + 1);
        vm.prank(alice);
        viet.customerCancel(orderId);

        vm.prank(owner);
        vm.expectRevert(
            abi.encodeWithSelector(
                VietPhin.OrderNotRefundable.selector,
                orderId,
                VietPhin.OrderStatus.Cancelled
            )
        );
        viet.rejectOrder(orderId);
    }

    function test_RejectOrder_RevertsIfOrderAlreadyRejected() public {
        vm.prank(owner);
        viet.rejectOrder(orderId);

        vm.prank(owner);
        vm.expectRevert(
            abi.encodeWithSelector(
                VietPhin.OrderNotRefundable.selector,
                orderId,
                VietPhin.OrderStatus.Rejected
            )
        );
        viet.rejectOrder(orderId);
    }

    // ── revert: non-owner ─────────────────────────────────────────────────────

    function test_RejectOrder_RevertsIfNonOwner() public {
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, alice)
        );
        viet.rejectOrder(orderId);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  completeOrder
// ─────────────────────────────────────────────────────────────────────────────
contract VietPhinCompleteOrderTest is VietPhinTestBase {
    uint256 internal orderId;

    function setUp() public override {
        super.setUp();
        orderId = _placeAliceOrder();
        _advanceToReady(orderId);
    }

    // ── happy path ────────────────────────────────────────────────────────────

    function test_CompleteOrder_StatusBecomesCompleted() public {
        vm.prank(owner);
        viet.completeOrder(orderId);
        assertEq(uint8(viet.getOrder(orderId).status), uint8(VietPhin.OrderStatus.Completed));
    }

    function test_CompleteOrder_TransfersUsdcToTreasury() public {
        uint256 treasuryBefore = usdc.balanceOf(owner); // treasury == owner initially
        vm.prank(owner);
        viet.completeOrder(orderId);
        assertEq(usdc.balanceOf(owner), treasuryBefore + ORDER_AMOUNT);
    }

    function test_CompleteOrder_DecrementsTotalEscrowed() public {
        vm.prank(owner);
        viet.completeOrder(orderId);
        assertEq(viet.totalEscrowed(), 0);
    }

    function test_CompleteOrder_EmitsOrderCompleted() public {
        vm.prank(owner);
        vm.expectEmit(true, true, false, true, address(viet));
        emit VietPhin.OrderCompleted(orderId, owner, ORDER_AMOUNT);
        viet.completeOrder(orderId);
    }

    function test_CompleteOrder_EmitsOrderStatusUpdated() public {
        vm.prank(owner);
        vm.expectEmit(true, false, false, true, address(viet));
        emit VietPhin.OrderStatusUpdated(orderId, VietPhin.OrderStatus.Completed, owner);
        viet.completeOrder(orderId);
    }

    // ── revert: not ReadyForPickup ────────────────────────────────────────────

    function test_CompleteOrder_RevertsIfReceived() public {
        // Place a fresh order that stays in Received.
        uint256 fresh = _placeAliceOrder();
        vm.prank(owner);
        vm.expectRevert(
            abi.encodeWithSelector(
                VietPhin.OrderNotCompletable.selector,
                fresh,
                VietPhin.OrderStatus.Received
            )
        );
        viet.completeOrder(fresh);
    }

    function test_CompleteOrder_RevertsIfPreparing() public {
        uint256 fresh = _placeAliceOrder();
        vm.prank(owner);
        viet.updateOrderStatus(fresh, VietPhin.OrderStatus.Preparing);

        vm.prank(owner);
        vm.expectRevert(
            abi.encodeWithSelector(
                VietPhin.OrderNotCompletable.selector,
                fresh,
                VietPhin.OrderStatus.Preparing
            )
        );
        viet.completeOrder(fresh);
    }

    function test_CompleteOrder_RevertsIfAlreadyCompleted() public {
        vm.prank(owner);
        viet.completeOrder(orderId);

        vm.prank(owner);
        vm.expectRevert(
            abi.encodeWithSelector(
                VietPhin.OrderNotCompletable.selector,
                orderId,
                VietPhin.OrderStatus.Completed
            )
        );
        viet.completeOrder(orderId);
    }

    // ── revert: non-owner ─────────────────────────────────────────────────────

    function test_CompleteOrder_RevertsIfNonOwner() public {
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, alice)
        );
        viet.completeOrder(orderId);
    }
}
