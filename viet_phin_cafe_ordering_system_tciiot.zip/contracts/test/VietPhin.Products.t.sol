// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {VietPhinTestBase} from "./VietPhin.Base.t.sol";
import {VietPhin} from "../VietPhin.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";

// ─────────────────────────────────────────────────────────────────────────────
//  renounceOwnership override
// ─────────────────────────────────────────────────────────────────────────────
contract VietPhinRenounceOwnershipTest is VietPhinTestBase {
    function test_RenounceOwnership_RevertsWithDisabledError() public {
        vm.prank(owner);
        vm.expectRevert(VietPhin.RenounceOwnershipDisabled.selector);
        viet.renounceOwnership();
    }

    function test_RenounceOwnership_RevertsEvenForNonOwner() public {
        // The pure override always reverts before any access-control check.
        vm.prank(alice);
        vm.expectRevert(VietPhin.RenounceOwnershipDisabled.selector);
        viet.renounceOwnership();
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Shared product helpers
// ─────────────────────────────────────────────────────────────────────────────
abstract contract VietPhinProductBase is VietPhinTestBase {
    VietPhin.ProductInput internal _pA;
    VietPhin.ProductInput internal _pB;

    function setUp() public virtual override {
        super.setUp();
        _pA = VietPhin.ProductInput({
            name: "Pho Bo",
            nameVi: "Pho Bo Vi",
            description: "Beef noodle soup",
            priceUsdc: 8e6,
            category: "noodles",
            imageUrl: "ipfs://pho",
            isFeatured: true,
            isHidden: false,
            isPaused: false
        });
        _pB = VietPhin.ProductInput({
            name: "Banh Mi",
            nameVi: "Banh Mi Vi",
            description: "Vietnamese sandwich",
            priceUsdc: 5e6,
            category: "bread",
            imageUrl: "ipfs://banhmi",
            isFeatured: false,
            isHidden: false,
            isPaused: false
        });
    }

    /// Add _pA as owner, return its id.
    function _addA() internal returns (uint256) {
        vm.prank(owner);
        return viet.addProduct(_pA);
    }

    /// Add both _pA and _pB as owner; returns (idA, idB).
    function _addBoth() internal returns (uint256 idA, uint256 idB) {
        vm.startPrank(owner);
        idA = viet.addProduct(_pA);
        idB = viet.addProduct(_pB);
        vm.stopPrank();
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  seedProducts
// ─────────────────────────────────────────────────────────────────────────────
contract VietPhinSeedProductsTest is VietPhinProductBase {

    function test_SeedProducts_EmptyArrayIsNoop() public {
        VietPhin.ProductInput[] memory empty = new VietPhin.ProductInput[](0);
        vm.prank(owner);
        viet.seedProducts(empty);
        assertEq(viet.productCount(), 0);
    }

    function test_SeedProducts_SingleItem_CountAndIdCorrect() public {
        VietPhin.ProductInput[] memory items = new VietPhin.ProductInput[](1);
        items[0] = _pA;
        vm.prank(owner);
        viet.seedProducts(items);
        assertEq(viet.productCount(), 1);
        VietPhin.Product memory p = viet.getProduct(1);
        assertEq(p.id, 1);
        assertEq(p.name, _pA.name);
        assertTrue(p.exists);
    }

    function test_SeedProducts_MultipleBatches_IdsAreSequential() public {
        VietPhin.ProductInput[] memory batch1 = new VietPhin.ProductInput[](2);
        batch1[0] = _pA;
        batch1[1] = _pB;
        VietPhin.ProductInput[] memory batch2 = new VietPhin.ProductInput[](1);
        batch2[0] = _pA;

        vm.startPrank(owner);
        viet.seedProducts(batch1);
        viet.seedProducts(batch2);
        vm.stopPrank();

        assertEq(viet.productCount(), 3);
        assertEq(viet.getProduct(1).name, _pA.name);
        assertEq(viet.getProduct(2).name, _pB.name);
        assertEq(viet.getProduct(3).name, _pA.name);
    }

    function test_SeedProducts_CanBeCalledMultipleTimes() public {
        VietPhin.ProductInput[] memory batch = new VietPhin.ProductInput[](1);
        batch[0] = _pA;
        vm.startPrank(owner);
        viet.seedProducts(batch);
        viet.seedProducts(batch); // second call appends, does NOT revert
        vm.stopPrank();
        assertEq(viet.productCount(), 2);
    }

    function test_SeedProducts_EmitsProductAddedPerItem() public {
        VietPhin.ProductInput[] memory items = new VietPhin.ProductInput[](2);
        items[0] = _pA;
        items[1] = _pB;

        vm.startPrank(owner);
        vm.expectEmit(true, false, false, true, address(viet));
        emit VietPhin.ProductAdded(1, _pA.name);
        vm.expectEmit(true, false, false, true, address(viet));
        emit VietPhin.ProductAdded(2, _pB.name);
        viet.seedProducts(items);
        vm.stopPrank();
    }

    function test_SeedProducts_RevertsForNonOwner() public {
        VietPhin.ProductInput[] memory items = new VietPhin.ProductInput[](1);
        items[0] = _pA;
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, alice)
        );
        viet.seedProducts(items);
    }

    function test_SeedProducts_IsHiddenAndIsPausedDefaultToFalse() public {
        VietPhin.ProductInput[] memory items = new VietPhin.ProductInput[](1);
        // Even if caller passes isHidden/isPaused, seedProducts ignores them and forces false
        // (by design — new products start visible and available)
        items[0] = _pA; // isHidden=false, isPaused=false in _pA already
        vm.prank(owner);
        viet.seedProducts(items);
        VietPhin.Product memory p = viet.getProduct(1);
        assertFalse(p.isHidden);
        assertFalse(p.isPaused);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  addProduct
// ─────────────────────────────────────────────────────────────────────────────
contract VietPhinAddProductTest is VietPhinProductBase {

    function test_AddProduct_ReturnsIncrementingId() public {
        // Contract starts empty; first two adds get ids 1 and 2.
        uint256 id1 = _addA();
        vm.prank(owner);
        uint256 id2 = viet.addProduct(_pB);
        assertEq(id1, 1);
        assertEq(id2, 2);
    }

    function test_AddProduct_IncrementsProductCount() public {
        assertEq(viet.productCount(), 0);
        _addA();
        assertEq(viet.productCount(), 1);
        vm.prank(owner);
        viet.addProduct(_pB);
        assertEq(viet.productCount(), 2);
    }

    function test_AddProduct_StoresAllFields() public {
        uint256 id = _addA();
        VietPhin.Product memory p = viet.getProduct(id);
        assertEq(p.id,          id);
        assertEq(p.name,        _pA.name);
        assertEq(p.nameVi,      _pA.nameVi);
        assertEq(p.description, _pA.description);
        assertEq(p.priceUsdc,   _pA.priceUsdc);
        assertEq(p.category,    _pA.category);
        assertEq(p.imageUrl,    _pA.imageUrl);
        assertTrue(p.isFeatured);
        assertFalse(p.isHidden);
        assertFalse(p.isPaused);
        assertTrue(p.exists);
    }

    function test_AddProduct_EmitsProductAdded() public {
        vm.prank(owner);
        vm.expectEmit(true, false, false, true, address(viet));
        emit VietPhin.ProductAdded(1, _pA.name);
        viet.addProduct(_pA);
    }

    function test_AddProduct_RevertsForNonOwner() public {
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, alice)
        );
        viet.addProduct(_pA);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  updateProduct
// ─────────────────────────────────────────────────────────────────────────────
contract VietPhinUpdateProductTest is VietPhinProductBase {
    uint256 internal idA;

    function setUp() public override {
        super.setUp();
        idA = _addA();
    }

    function test_UpdateProduct_UpdatesAllFields() public {
        VietPhin.ProductInput memory updated = VietPhin.ProductInput({
            name: "Bun Bo Hue",
            nameVi: "Bun Bo Hue Vi",
            description: "Spicy beef noodle",
            priceUsdc: 9e6,
            category: "noodles",
            imageUrl: "ipfs://bunbo",
            isFeatured: false,
            isHidden: true,
            isPaused: true
        });
        vm.prank(owner);
        viet.updateProduct(idA, updated);

        VietPhin.Product memory p = viet.getProduct(idA);
        assertEq(p.name,        updated.name);
        assertEq(p.nameVi,      updated.nameVi);
        assertEq(p.description, updated.description);
        assertEq(p.priceUsdc,   updated.priceUsdc);
        assertEq(p.category,    updated.category);
        assertEq(p.imageUrl,    updated.imageUrl);
        assertFalse(p.isFeatured);
        assertTrue(p.isHidden);
        assertTrue(p.isPaused);
    }

    function test_UpdateProduct_EmitsProductUpdated() public {
        vm.prank(owner);
        vm.expectEmit(true, false, false, false, address(viet));
        emit VietPhin.ProductUpdated(idA);
        viet.updateProduct(idA, _pB);
    }

    function test_UpdateProduct_RevertsProductNotFound_NonexistentId() public {
        vm.prank(owner);
        vm.expectRevert(abi.encodeWithSelector(VietPhin.ProductNotFound.selector, 999));
        viet.updateProduct(999, _pB);
    }

    function test_UpdateProduct_RevertsProductNotFound_DeletedProduct() public {
        vm.prank(owner);
        viet.deleteProduct(idA);
        vm.prank(owner);
        vm.expectRevert(abi.encodeWithSelector(VietPhin.ProductNotFound.selector, idA));
        viet.updateProduct(idA, _pB);
    }

    function test_UpdateProduct_RevertsForNonOwner() public {
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, alice)
        );
        viet.updateProduct(idA, _pB);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  deleteProduct
// ─────────────────────────────────────────────────────────────────────────────
contract VietPhinDeleteProductTest is VietPhinProductBase {
    uint256 internal idA;

    function setUp() public override {
        super.setUp();
        idA = _addA();
    }

    function test_DeleteProduct_SetsExistsFalse() public {
        vm.prank(owner);
        viet.deleteProduct(idA);
        vm.expectRevert(abi.encodeWithSelector(VietPhin.ProductNotFound.selector, idA));
        viet.getProduct(idA);
    }

    function test_DeleteProduct_DecrementsProductCount() public {
        assertEq(viet.productCount(), 1);
        vm.prank(owner);
        viet.deleteProduct(idA);
        assertEq(viet.productCount(), 0);
    }

    function test_DeleteProduct_EmitsProductDeleted() public {
        vm.prank(owner);
        vm.expectEmit(true, false, false, false, address(viet));
        emit VietPhin.ProductDeleted(idA);
        viet.deleteProduct(idA);
    }

    function test_DeleteProduct_RevertsProductNotFound_NonexistentId() public {
        vm.prank(owner);
        vm.expectRevert(abi.encodeWithSelector(VietPhin.ProductNotFound.selector, 999));
        viet.deleteProduct(999);
    }

    function test_DeleteProduct_RevertsProductNotFound_AlreadyDeleted() public {
        vm.prank(owner);
        viet.deleteProduct(idA);
        vm.prank(owner);
        vm.expectRevert(abi.encodeWithSelector(VietPhin.ProductNotFound.selector, idA));
        viet.deleteProduct(idA);
    }

    function test_DeleteProduct_RevertsForNonOwner() public {
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, alice)
        );
        viet.deleteProduct(idA);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  setProductHidden / setProductPaused / setProductFeatured
// ─────────────────────────────────────────────────────────────────────────────
contract VietPhinSetProductFlagsTest is VietPhinProductBase {
    uint256 internal idA;

    function setUp() public override {
        super.setUp();
        idA = _addA(); // _pA: isFeatured=true, isHidden=false, isPaused=false
    }

    // ── setProductHidden ──────────────────────────────────────────────────────

    function test_SetProductHidden_SetsFlag() public {
        vm.prank(owner);
        viet.setProductHidden(idA, true);
        assertTrue(viet.getProduct(idA).isHidden);
    }

    function test_SetProductHidden_ClearsFlag() public {
        vm.prank(owner);
        viet.setProductHidden(idA, true);
        vm.prank(owner);
        viet.setProductHidden(idA, false);
        assertFalse(viet.getProduct(idA).isHidden);
    }

    function test_SetProductHidden_EmitsProductUpdated() public {
        vm.prank(owner);
        vm.expectEmit(true, false, false, false, address(viet));
        emit VietPhin.ProductUpdated(idA);
        viet.setProductHidden(idA, true);
    }

    function test_SetProductHidden_RevertsProductNotFound() public {
        vm.prank(owner);
        vm.expectRevert(abi.encodeWithSelector(VietPhin.ProductNotFound.selector, 999));
        viet.setProductHidden(999, true);
    }

    function test_SetProductHidden_RevertsForNonOwner() public {
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, alice)
        );
        viet.setProductHidden(idA, true);
    }

    // ── setProductPaused ──────────────────────────────────────────────────────

    function test_SetProductPaused_SetsFlag() public {
        vm.prank(owner);
        viet.setProductPaused(idA, true);
        assertTrue(viet.getProduct(idA).isPaused);
    }

    function test_SetProductPaused_ClearsFlag() public {
        vm.prank(owner);
        viet.setProductPaused(idA, true);
        vm.prank(owner);
        viet.setProductPaused(idA, false);
        assertFalse(viet.getProduct(idA).isPaused);
    }

    function test_SetProductPaused_EmitsProductUpdated() public {
        vm.prank(owner);
        vm.expectEmit(true, false, false, false, address(viet));
        emit VietPhin.ProductUpdated(idA);
        viet.setProductPaused(idA, true);
    }

    function test_SetProductPaused_RevertsProductNotFound() public {
        vm.prank(owner);
        vm.expectRevert(abi.encodeWithSelector(VietPhin.ProductNotFound.selector, 999));
        viet.setProductPaused(999, true);
    }

    function test_SetProductPaused_RevertsForNonOwner() public {
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, alice)
        );
        viet.setProductPaused(idA, true);
    }

    // ── setProductFeatured ────────────────────────────────────────────────────

    function test_SetProductFeatured_ClearsFlag() public {
        vm.prank(owner);
        viet.setProductFeatured(idA, false);
        assertFalse(viet.getProduct(idA).isFeatured);
    }

    function test_SetProductFeatured_SetsFlag() public {
        vm.prank(owner);
        viet.setProductFeatured(idA, false);
        vm.prank(owner);
        viet.setProductFeatured(idA, true);
        assertTrue(viet.getProduct(idA).isFeatured);
    }

    function test_SetProductFeatured_EmitsProductUpdated() public {
        vm.prank(owner);
        vm.expectEmit(true, false, false, false, address(viet));
        emit VietPhin.ProductUpdated(idA);
        viet.setProductFeatured(idA, false);
    }

    function test_SetProductFeatured_RevertsProductNotFound() public {
        vm.prank(owner);
        vm.expectRevert(abi.encodeWithSelector(VietPhin.ProductNotFound.selector, 999));
        viet.setProductFeatured(999, true);
    }

    function test_SetProductFeatured_RevertsForNonOwner() public {
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, alice)
        );
        viet.setProductFeatured(idA, true);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  getProduct
// ─────────────────────────────────────────────────────────────────────────────
contract VietPhinGetProductTest is VietPhinProductBase {

    function test_GetProduct_ReturnsCorrectProduct() public {
        uint256 id = _addA();
        VietPhin.Product memory p = viet.getProduct(id);
        assertEq(p.id,        id);
        assertEq(p.name,      _pA.name);
        assertEq(p.priceUsdc, _pA.priceUsdc);
        assertTrue(p.exists);
    }

    function test_GetProduct_RevertsProductNotFound_NonexistentId() public {
        vm.expectRevert(abi.encodeWithSelector(VietPhin.ProductNotFound.selector, 9999));
        viet.getProduct(9999);
    }

    function test_GetProduct_RevertsProductNotFound_DeletedId() public {
        uint256 id = _addA();
        vm.prank(owner);
        viet.deleteProduct(id);
        vm.expectRevert(abi.encodeWithSelector(VietPhin.ProductNotFound.selector, id));
        viet.getProduct(id);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  getProducts (pagination)
// ─────────────────────────────────────────────────────────────────────────────
contract VietPhinGetProductsTest is VietPhinProductBase {

    function test_GetProducts_EmptyStoreReturnsEmpty() public view {
        VietPhin.Product[] memory page = viet.getProducts(0, 0);
        assertEq(page.length, 0);
    }

    function test_GetProducts_OffsetZeroLimitOne() public {
        _addBoth(); // ids 1, 2
        VietPhin.Product[] memory page = viet.getProducts(0, 1);
        assertEq(page.length, 1);
        assertEq(page[0].id, 1);
    }

    function test_GetProducts_OffsetOneLimitOne() public {
        _addBoth(); // ids 1, 2
        VietPhin.Product[] memory page = viet.getProducts(1, 1);
        assertEq(page.length, 1);
        assertEq(page[0].id, 2);
    }

    function test_GetProducts_OffsetZeroLimitZeroReturnsAll() public {
        _addBoth(); // 2 products
        VietPhin.Product[] memory page = viet.getProducts(0, 0);
        assertEq(page.length, 2);
    }

    function test_GetProducts_LimitExceedsCountClampsToCount() public {
        _addBoth(); // 2 products
        VietPhin.Product[] memory page = viet.getProducts(0, 200);
        assertEq(page.length, 2);
    }

    function test_GetProducts_OffsetGteCountReturnsEmpty() public {
        _addBoth(); // productCount == 2, offset == 2 → empty
        VietPhin.Product[] memory page = viet.getProducts(2, 0);
        assertEq(page.length, 0);
    }

    function test_GetProducts_OffsetFarBeyondCountReturnsEmpty() public {
        _addBoth();
        VietPhin.Product[] memory page = viet.getProducts(999, 10);
        assertEq(page.length, 0);
    }

    function test_GetProducts_SkipsDeletedProducts() public {
        (uint256 idA, uint256 idB) = _addBoth(); // ids 1, 2
        vm.prank(owner);
        viet.deleteProduct(idA); // removes id 1; productCount == 1

        VietPhin.Product[] memory page = viet.getProducts(0, 10);
        assertEq(page.length, 1);
        assertEq(page[0].id, idB);
    }

    function test_GetProducts_DeletedMidListDoesNotShiftPagination() public {
        // Add 3 products, delete the middle one.
        vm.startPrank(owner);
        uint256 idA = viet.addProduct(_pA); // 1
        uint256 idB = viet.addProduct(_pB); // 2
        uint256 idC = viet.addProduct(_pA); // 3
        viet.deleteProduct(idB);            // productCount == 2: [idA, idC]
        vm.stopPrank();

        // offset=1 limit=1 should return idC
        VietPhin.Product[] memory page = viet.getProducts(1, 1);
        assertEq(page.length, 1);
        assertEq(page[0].id, idC);
    }

    function test_GetProducts_ContentsMatchExpected() public {
        _addBoth(); // id1=_pA, id2=_pB
        VietPhin.Product[] memory page = viet.getProducts(0, 2);
        assertEq(page[0].name, _pA.name);
        assertEq(page[1].name, _pB.name);
    }
}
