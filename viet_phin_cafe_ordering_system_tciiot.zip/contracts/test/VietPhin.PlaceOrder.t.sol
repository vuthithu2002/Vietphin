// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {VietPhinTestBase} from "./VietPhin.Base.t.sol";
import {VietPhin} from "../VietPhin.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";

contract VietPhinDeployTest is VietPhinTestBase {
    // ── constructor / deployment ───────────────────────────────────────────────

    function test_Deploy_SetsUsdcToken() public view {
        assertEq(viet.usdcToken(), address(usdc));
    }

    function test_Deploy_SetsTreasuryToOwner() public view {
        assertEq(viet.treasury(), owner);
    }

    function test_Deploy_OwnerIsCorrect() public view {
        assertEq(viet.owner(), owner);
    }

    function test_Deploy_ZeroUsdcReverts() public {
        vm.expectRevert(VietPhin.ZeroAddress.selector);
        new VietPhin(address(0), owner);
    }

    function test_Deploy_ZeroOwnerReverts() public {
        // OZ Ownable(address(0)) fires OwnableInvalidOwner before VietPhin's ZeroAddress check.
        vm.expectRevert(
            abi.encodeWithSelector(Ownable.OwnableInvalidOwner.selector, address(0))
        );
        new VietPhin(address(usdc), address(0));
    }

    function test_Deploy_NoSetTreasury() public {
        // setTreasury must NOT exist — calling it should revert with no matching selector.
        bytes memory callData = abi.encodeWithSignature("setTreasury(address)", newTreasury);
        (bool success, ) = address(viet).call(callData);
        assertFalse(success, "setTreasury should not exist");
    }
}

contract VietPhinPlaceOrderTest is VietPhinTestBase {
    // ── placeOrder happy path ──────────────────────────────────────────────────

    function test_PlaceOrder_TransfersUsdcToContract() public {
        uint256 aliceBefore = usdc.balanceOf(alice);
        uint256 contractBefore = usdc.balanceOf(address(viet));

        _placeAliceOrder();

        assertEq(usdc.balanceOf(alice),        aliceBefore   - ORDER_AMOUNT);
        assertEq(usdc.balanceOf(address(viet)), contractBefore + ORDER_AMOUNT);
    }

    function test_PlaceOrder_IncrementsTotalEscrowed() public {
        _placeAliceOrder();
        assertEq(viet.totalEscrowed(), ORDER_AMOUNT);
    }

    function test_PlaceOrder_CreatesOrderWithCorrectFields() public {
        uint256 pickup = block.timestamp + 1 hours;
        vm.prank(alice);
        uint256 orderId = viet.placeOrder(ORDER_AMOUNT, pickup, ITEMS_HASH);

        VietPhin.Order memory o = viet.getOrder(orderId);
        assertEq(o.orderId,          orderId);
        assertEq(o.customer,         alice);
        assertEq(o.totalAmountUsdc,  ORDER_AMOUNT);
        assertEq(o.pickupTime,       pickup);
        assertEq(uint8(o.status),    uint8(VietPhin.OrderStatus.Received));
        assertEq(o.itemsHash,        ITEMS_HASH);
        assertEq(o.createdAt,        block.timestamp);
    }

    function test_PlaceOrder_AwardsLoyaltyPoints() public {
        _placeAliceOrder();
        // 10e6 / 1e6 = 10 points
        assertEq(viet.getLoyaltyPoints(alice), 10);
    }

    function test_PlaceOrder_EmitsOrderPlaced() public {
        uint256 pickup = block.timestamp + 1 hours;
        vm.prank(alice);
        vm.expectEmit(true, true, false, true, address(viet));
        emit VietPhin.OrderPlaced(1, alice, ORDER_AMOUNT, pickup, ITEMS_HASH);
        viet.placeOrder(ORDER_AMOUNT, pickup, ITEMS_HASH);
    }

    function test_PlaceOrder_EmitsLoyaltyPointsEarned() public {
        uint256 pickup = block.timestamp + 1 hours;
        vm.prank(alice);
        // Skip the first event (OrderPlaced), just check LoyaltyPointsEarned.
        vm.expectEmit(true, false, false, true, address(viet));
        emit VietPhin.LoyaltyPointsEarned(alice, ORDER_AMOUNT / 1e6, 1);
        viet.placeOrder(ORDER_AMOUNT, pickup, ITEMS_HASH);
    }

    function test_PlaceOrder_ReturnsIncrementingOrderId() public {
        uint256 id1 = _placeAliceOrder();
        vm.prank(bob);
        uint256 id2 = viet.placeOrder(ORDER_AMOUNT, block.timestamp + 1 hours, ITEMS_HASH);
        assertEq(id1, 1);
        assertEq(id2, 2);
    }

    function test_PlaceOrder_AppendsToCustomerOrders() public {
        _placeAliceOrder();
        uint256[] memory ids = viet.getOrdersByCustomer(alice, 0, 10);
        assertEq(ids.length, 1);
        assertEq(ids[0], 1);
    }

    // ── placeOrder reverts ────────────────────────────────────────────────────

    function test_PlaceOrder_RevertsOnZeroAmount() public {
        vm.prank(alice);
        vm.expectRevert(VietPhin.InvalidAmount.selector);
        viet.placeOrder(0, block.timestamp + 1 hours, ITEMS_HASH);
    }

    function test_PlaceOrder_RevertsOnPastPickupTime() public {
        vm.prank(alice);
        vm.expectRevert(VietPhin.InvalidPickupTime.selector);
        viet.placeOrder(ORDER_AMOUNT, block.timestamp - 1, ITEMS_HASH);
    }

    function test_PlaceOrder_RevertsOnPickupTimeEqualTimestamp() public {
        // pickupTime == block.timestamp - 1: already in the past.
        // pickupTime == block.timestamp: should also revert (strictly <)
        vm.warp(1000);
        vm.prank(alice);
        vm.expectRevert(VietPhin.InvalidPickupTime.selector);
        viet.placeOrder(ORDER_AMOUNT, 999, ITEMS_HASH);
    }

    // ── fuzz: amount and pickup time ──────────────────────────────────────────

    function testFuzz_PlaceOrder_AwardsCorrectPoints(uint96 amount) public {
        amount = uint96(bound(amount, 1e6, 500e6));
        usdc.mint(alice, amount);

        vm.prank(alice);
        viet.placeOrder(amount, block.timestamp + 1 hours, ITEMS_HASH);

        uint256 expected = uint256(amount) / 1e6;
        assertEq(viet.getLoyaltyPoints(alice), expected);
    }
}
