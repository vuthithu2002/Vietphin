// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {VietPhinTestBase} from "./VietPhin.Base.t.sol";
import {VietPhin} from "../VietPhin.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";

contract VietPhinUpdateOrderStatusTest is VietPhinTestBase {
    uint256 internal orderId;

    function setUp() public override {
        super.setUp();
        orderId = _placeAliceOrder();
    }

    // ── happy path ────────────────────────────────────────────────────────────

    function test_UpdateStatus_ReceivedToPreparing() public {
        vm.prank(owner);
        viet.updateOrderStatus(orderId, VietPhin.OrderStatus.Preparing);
        assertEq(uint8(viet.getOrder(orderId).status), uint8(VietPhin.OrderStatus.Preparing));
    }

    function test_UpdateStatus_PreparingToReadyForPickup() public {
        vm.startPrank(owner);
        viet.updateOrderStatus(orderId, VietPhin.OrderStatus.Preparing);
        viet.updateOrderStatus(orderId, VietPhin.OrderStatus.ReadyForPickup);
        vm.stopPrank();
        assertEq(uint8(viet.getOrder(orderId).status), uint8(VietPhin.OrderStatus.ReadyForPickup));
    }

    function test_UpdateStatus_EmitsOrderStatusUpdated() public {
        vm.prank(owner);
        vm.expectEmit(true, false, false, true, address(viet));
        emit VietPhin.OrderStatusUpdated(orderId, VietPhin.OrderStatus.Preparing, owner);
        viet.updateOrderStatus(orderId, VietPhin.OrderStatus.Preparing);
    }

    // ── revert: terminal statuses forbidden ───────────────────────────────────

    function test_UpdateStatus_RevertsOnCompleted() public {
        vm.prank(owner);
        vm.expectRevert(
            abi.encodeWithSelector(VietPhin.TerminalStatusForbidden.selector, VietPhin.OrderStatus.Completed)
        );
        viet.updateOrderStatus(orderId, VietPhin.OrderStatus.Completed);
    }

    function test_UpdateStatus_RevertsOnRejected() public {
        vm.prank(owner);
        vm.expectRevert(
            abi.encodeWithSelector(VietPhin.TerminalStatusForbidden.selector, VietPhin.OrderStatus.Rejected)
        );
        viet.updateOrderStatus(orderId, VietPhin.OrderStatus.Rejected);
    }

    function test_UpdateStatus_RevertsOnCancelled() public {
        vm.prank(owner);
        vm.expectRevert(
            abi.encodeWithSelector(VietPhin.TerminalStatusForbidden.selector, VietPhin.OrderStatus.Cancelled)
        );
        viet.updateOrderStatus(orderId, VietPhin.OrderStatus.Cancelled);
    }

    // ── revert: already-terminal order ───────────────────────────────────────

    function test_UpdateStatus_RevertsIfOrderAlreadyCompleted() public {
        _advanceToReady(orderId);
        vm.prank(owner);
        viet.completeOrder(orderId);

        vm.prank(owner);
        vm.expectRevert(
            abi.encodeWithSelector(
                VietPhin.OrderAlreadyFinalized.selector,
                orderId,
                VietPhin.OrderStatus.Completed
            )
        );
        viet.updateOrderStatus(orderId, VietPhin.OrderStatus.Preparing);
    }

    function test_UpdateStatus_RevertsIfOrderAlreadyRejected() public {
        vm.prank(owner);
        viet.rejectOrder(orderId);

        vm.prank(owner);
        vm.expectRevert(
            abi.encodeWithSelector(
                VietPhin.OrderAlreadyFinalized.selector,
                orderId,
                VietPhin.OrderStatus.Rejected
            )
        );
        viet.updateOrderStatus(orderId, VietPhin.OrderStatus.Preparing);
    }

    function test_UpdateStatus_RevertsIfOrderAlreadyCancelled() public {
        // Warp past pickupTime + 2h so customerCancel is allowed
        VietPhin.Order memory o = viet.getOrder(orderId);
        vm.warp(o.pickupTime + 2 hours + 1);
        vm.prank(alice);
        viet.customerCancel(orderId);

        vm.prank(owner);
        vm.expectRevert(
            abi.encodeWithSelector(
                VietPhin.OrderAlreadyFinalized.selector,
                orderId,
                VietPhin.OrderStatus.Cancelled
            )
        );
        viet.updateOrderStatus(orderId, VietPhin.OrderStatus.Preparing);
    }

    // ── revert: access control ────────────────────────────────────────────────

    function test_UpdateStatus_RevertsIfNonOwner() public {
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, alice)
        );
        viet.updateOrderStatus(orderId, VietPhin.OrderStatus.Preparing);
    }

    // ── revert: order not found ───────────────────────────────────────────────

    function test_UpdateStatus_RevertsOnOrderNotFound() public {
        vm.prank(owner);
        vm.expectRevert(abi.encodeWithSelector(VietPhin.OrderNotFound.selector, 999));
        viet.updateOrderStatus(999, VietPhin.OrderStatus.Preparing);
    }
}
