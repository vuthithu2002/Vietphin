// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";

/// @title  VietPhin
/// @notice USDC-escrow café ordering contract with on-chain product catalogue.
///         Deployed with an empty product list; the owner seeds products via
///         seedProducts() after deployment (in one or more batches of any size).
contract VietPhin is Ownable {
    using SafeERC20 for IERC20;

    // -------------------------------------------------------------------------
    // Types
    // -------------------------------------------------------------------------

    enum OrderStatus {
        Received,
        Preparing,
        ReadyForPickup,
        Completed,
        Cancelled,
        Rejected
    }

    struct Order {
        uint256 orderId;
        address customer;
        uint256 totalAmountUsdc;
        uint256 pickupTime;
        OrderStatus status;
        bytes32 itemsHash;
        uint256 createdAt;
        bytes32 txHash;
    }

    struct Product {
        uint256 id;
        string name;
        string nameVi;
        string description;
        uint256 priceUsdc;
        string category;
        string imageUrl;
        bool isFeatured;
        bool isHidden;
        bool isPaused;
        bool exists;
    }

    /// @notice Input shape for addProduct / updateProduct / seedProducts.
    ///         No id or exists field — those are assigned/managed by the contract.
    struct ProductInput {
        string name;
        string nameVi;
        string description;
        uint256 priceUsdc;
        string category;
        string imageUrl;
        bool isFeatured;
        bool isHidden;
        bool isPaused;
    }

    // -------------------------------------------------------------------------
    // State
    // -------------------------------------------------------------------------

    address public immutable usdcToken;
    IERC20 private immutable _usdc;
    address public treasury;
    address public pendingTreasury;

    uint256 private _orderCounter;
    uint256 public totalEscrowed;

    mapping(uint256 orderId => Order order) private _orders;
    mapping(address customer => uint256 points) private _loyaltyPoints;
    mapping(address customer => uint256[] orderIds) private _customerOrders;

    mapping(uint256 => Product) private _products;
    uint256 private _productCounter;
    uint256 public productCount;

    // -------------------------------------------------------------------------
    // Events
    // -------------------------------------------------------------------------

    event OrderPlaced(
        uint256 indexed orderId,
        address indexed customer,
        uint256 totalAmountUsdc,
        uint256 pickupTime,
        bytes32 itemsHash
    );
    event OrderStatusUpdated(uint256 indexed orderId, OrderStatus newStatus, address updatedBy);
    event LoyaltyPointsEarned(address indexed customer, uint256 points, uint256 orderId);
    event LoyaltyPointsRedeemed(address indexed customer, uint256 points);
    event TreasuryUpdated(address indexed oldTreasury, address indexed newTreasury);
    event TreasuryUpdateProposed(address indexed proposed);
    event OrderRejected(uint256 indexed orderId, address indexed customer, uint256 refundAmount);
    event OrderCompleted(uint256 indexed orderId, address indexed treasury, uint256 amount);
    event Refunded(uint256 indexed orderId, address indexed customer, uint256 amount);
    event ProductAdded(uint256 indexed id, string name);
    event ProductUpdated(uint256 indexed id);
    event ProductDeleted(uint256 indexed id);
    event WithdrawnAll(address indexed to, uint256 amount);

    // -------------------------------------------------------------------------
    // Errors
    // -------------------------------------------------------------------------

    error ZeroAddress();
    error InvalidAmount();
    error InsufficientSurplus(uint256 requested, uint256 available);
    error InvalidPickupTime();
    error OrderNotFound(uint256 orderId);
    error InsufficientLoyaltyPoints(address customer, uint256 available, uint256 required);
    error OrderNotRefundable(uint256 orderId, OrderStatus currentStatus);
    error OrderNotCompletable(uint256 orderId, OrderStatus currentStatus);
    error TerminalStatusForbidden(OrderStatus attempted);
    error NotOrderCustomer(uint256 orderId, address caller);
    error OrderAlreadyFinalized(uint256 orderId, OrderStatus currentStatus);
    error TooEarlyToCancel(uint256 orderId, uint256 earliest);
    error NotPendingTreasury(address caller, address expected);
    error ProductNotFound(uint256 id);
    error RenounceOwnershipDisabled();

    // -------------------------------------------------------------------------
    // Constructor
    // -------------------------------------------------------------------------

    /// @param usdcToken_    Address of the USDC ERC-20 token (Arc: 0x3600...0000).
    /// @param initialOwner  Becomes both the Ownable owner and the initial treasury.
    constructor(address usdcToken_, address initialOwner) Ownable(initialOwner) {
        if (usdcToken_ == address(0)) revert ZeroAddress();
        treasury = initialOwner;
        usdcToken = usdcToken_;
        _usdc = IERC20(usdcToken_);
    }

    // -------------------------------------------------------------------------
    // Ownership
    // -------------------------------------------------------------------------

    /// @dev Ownership renouncement is permanently disabled — it would lock all
    ///      owner-gated functions (order management, product catalogue, treasury).
    function renounceOwnership() public pure override {
        revert RenounceOwnershipDisabled();
    }

    // -------------------------------------------------------------------------
    // Product catalogue
    // -------------------------------------------------------------------------

    /// @notice Seed any number of products in a single call. Call once or in
    ///         multiple smaller batches after deployment — there is no one-time
    ///         gate. Each call appends new products; it never overwrites existing
    ///         ones. Only the owner may call this.
    /// @param  items  Array of ProductInput structs. Split into batches of ~10-15
    ///                items if you hit Remix's gas estimation limit.
    function seedProducts(ProductInput[] calldata items) external onlyOwner {
        for (uint256 i = 0; i < items.length; ++i) {
            uint256 id = ++_productCounter;
            _products[id] = Product({
                id: id,
                name: items[i].name,
                nameVi: items[i].nameVi,
                description: items[i].description,
                priceUsdc: items[i].priceUsdc,
                category: items[i].category,
                imageUrl: items[i].imageUrl,
                isFeatured: items[i].isFeatured,
                isHidden: false,
                isPaused: false,
                exists: true
            });
            ++productCount;
            emit ProductAdded(id, items[i].name);
        }
    }

    /// @notice Add a single product. Returns the new product id.
    function addProduct(ProductInput calldata item) external onlyOwner returns (uint256 id) {
        id = ++_productCounter;
        _products[id] = Product({
            id: id,
            name: item.name,
            nameVi: item.nameVi,
            description: item.description,
            priceUsdc: item.priceUsdc,
            category: item.category,
            imageUrl: item.imageUrl,
            isFeatured: item.isFeatured,
            isHidden: item.isHidden,
            isPaused: item.isPaused,
            exists: true
        });
        ++productCount;
        emit ProductAdded(id, item.name);
    }

    /// @notice Replace all fields of an existing product.
    function updateProduct(uint256 id, ProductInput calldata item) external onlyOwner {
        Product storage product = _products[id];
        if (!product.exists) revert ProductNotFound(id);

        product.name = item.name;
        product.nameVi = item.nameVi;
        product.description = item.description;
        product.priceUsdc = item.priceUsdc;
        product.category = item.category;
        product.imageUrl = item.imageUrl;
        product.isFeatured = item.isFeatured;
        product.isHidden = item.isHidden;
        product.isPaused = item.isPaused;

        emit ProductUpdated(id);
    }

    /// @notice Soft-delete a product (sets exists = false, hides it from getProducts).
    function deleteProduct(uint256 id) external onlyOwner {
        Product storage product = _products[id];
        if (!product.exists) revert ProductNotFound(id);
        product.exists = false;
        --productCount;
        emit ProductDeleted(id);
    }

    /// @notice Show / hide a product from the customer menu.
    function setProductHidden(uint256 id, bool hidden) external onlyOwner {
        Product storage product = _products[id];
        if (!product.exists) revert ProductNotFound(id);
        product.isHidden = hidden;
        emit ProductUpdated(id);
    }

    /// @notice Mark a product as sold-out (paused) or available again.
    function setProductPaused(uint256 id, bool paused) external onlyOwner {
        Product storage product = _products[id];
        if (!product.exists) revert ProductNotFound(id);
        product.isPaused = paused;
        emit ProductUpdated(id);
    }

    /// @notice Toggle the featured / popular flag on a product.
    function setProductFeatured(uint256 id, bool featured) external onlyOwner {
        Product storage product = _products[id];
        if (!product.exists) revert ProductNotFound(id);
        product.isFeatured = featured;
        emit ProductUpdated(id);
    }

    /// @notice Fetch a single product by id. Reverts if not found or deleted.
    function getProduct(uint256 id) external view returns (Product memory) {
        Product storage product = _products[id];
        if (!product.exists) revert ProductNotFound(id);
        return product;
    }

    /// @notice Paginated product list over existing (non-deleted) products.
    /// @param  offset  Number of existing products to skip.
    /// @param  limit   Max products to return; pass 0 to return all from offset.
    function getProducts(uint256 offset, uint256 limit) external view returns (Product[] memory) {
        if (productCount == 0 || offset >= productCount) {
            return new Product[](0);
        }

        uint256 resultLength = productCount - offset;
        if (limit != 0 && limit < resultLength) {
            resultLength = limit;
        }

        Product[] memory products = new Product[](resultLength);
        uint256 seen = 0;
        uint256 filled = 0;

        for (uint256 id = 1; id <= _productCounter && filled < resultLength; ++id) {
            if (!_products[id].exists) continue;
            if (seen < offset) { ++seen; continue; }
            products[filled] = _products[id];
            ++filled;
            ++seen;
        }

        return products;
    }

    // -------------------------------------------------------------------------
    // Orders
    // -------------------------------------------------------------------------

    function placeOrder(uint256 totalAmountUsdc, uint256 pickupTime, bytes32 itemsHash) external returns (uint256) {
        if (totalAmountUsdc == 0) revert InvalidAmount();
        if (pickupTime < block.timestamp) revert InvalidPickupTime();

        _usdc.safeTransferFrom(msg.sender, address(this), totalAmountUsdc);
        totalEscrowed += totalAmountUsdc;

        uint256 newOrderId = ++_orderCounter;

        _orders[newOrderId] = Order({
            orderId: newOrderId,
            customer: msg.sender,
            totalAmountUsdc: totalAmountUsdc,
            pickupTime: pickupTime,
            status: OrderStatus.Received,
            itemsHash: itemsHash,
            createdAt: block.timestamp,
            txHash: bytes32(0)
        });

        _customerOrders[msg.sender].push(newOrderId);
        emit OrderPlaced(newOrderId, msg.sender, totalAmountUsdc, pickupTime, itemsHash);

        uint256 pointsEarned = totalAmountUsdc / 1e6;
        _loyaltyPoints[msg.sender] += pointsEarned;
        emit LoyaltyPointsEarned(msg.sender, pointsEarned, newOrderId);

        return newOrderId;
    }

    function updateOrderStatus(uint256 orderId, OrderStatus newStatus) external onlyOwner {
        if (orderId == 0 || orderId > _orderCounter) revert OrderNotFound(orderId);
        if (
            newStatus == OrderStatus.Completed ||
            newStatus == OrderStatus.Rejected  ||
            newStatus == OrderStatus.Cancelled
        ) {
            revert TerminalStatusForbidden(newStatus);
        }

        Order storage order = _orders[orderId];
        if (
            order.status == OrderStatus.Completed ||
            order.status == OrderStatus.Rejected  ||
            order.status == OrderStatus.Cancelled
        ) {
            revert OrderAlreadyFinalized(orderId, order.status);
        }

        order.status = newStatus;
        emit OrderStatusUpdated(orderId, newStatus, msg.sender);
    }

    function updateOrderTxHash(uint256 orderId, bytes32 txHash) external onlyOwner {
        if (orderId == 0 || orderId > _orderCounter) revert OrderNotFound(orderId);
        _orders[orderId].txHash = txHash;
    }

    function rejectOrder(uint256 orderId) external onlyOwner {
        if (orderId == 0 || orderId > _orderCounter) revert OrderNotFound(orderId);

        Order storage order = _orders[orderId];
        OrderStatus currentStatus = order.status;
        if (
            currentStatus != OrderStatus.Received      &&
            currentStatus != OrderStatus.Preparing     &&
            currentStatus != OrderStatus.ReadyForPickup
        ) {
            revert OrderNotRefundable(orderId, currentStatus);
        }

        order.status = OrderStatus.Rejected;
        emit OrderStatusUpdated(orderId, OrderStatus.Rejected, msg.sender);

        _usdc.safeTransfer(order.customer, order.totalAmountUsdc);
        totalEscrowed -= order.totalAmountUsdc;
        emit OrderRejected(orderId, order.customer, order.totalAmountUsdc);
        emit Refunded(orderId, order.customer, order.totalAmountUsdc);

        uint256 pointsEarned = order.totalAmountUsdc / 1e6;
        uint256 currentPoints = _loyaltyPoints[order.customer];
        _loyaltyPoints[order.customer] = currentPoints >= pointsEarned
            ? currentPoints - pointsEarned
            : 0;
    }

    function customerCancel(uint256 orderId) external {
        if (orderId == 0 || orderId > _orderCounter) revert OrderNotFound(orderId);

        Order storage order = _orders[orderId];
        if (msg.sender != order.customer) revert NotOrderCustomer(orderId, msg.sender);

        OrderStatus currentStatus = order.status;
        if (
            currentStatus == OrderStatus.Completed ||
            currentStatus == OrderStatus.Rejected  ||
            currentStatus == OrderStatus.Cancelled
        ) {
            revert OrderAlreadyFinalized(orderId, currentStatus);
        }

        uint256 earliest = order.pickupTime + 2 hours;
        if (block.timestamp < earliest) revert TooEarlyToCancel(orderId, earliest);

        order.status = OrderStatus.Cancelled;
        emit OrderStatusUpdated(orderId, OrderStatus.Cancelled, msg.sender);

        _usdc.safeTransfer(order.customer, order.totalAmountUsdc);
        totalEscrowed -= order.totalAmountUsdc;
        emit Refunded(orderId, order.customer, order.totalAmountUsdc);

        uint256 pointsEarned = order.totalAmountUsdc / 1e6;
        uint256 currentPoints = _loyaltyPoints[order.customer];
        _loyaltyPoints[order.customer] = currentPoints >= pointsEarned
            ? currentPoints - pointsEarned
            : 0;
    }

    function completeOrder(uint256 orderId) external onlyOwner {
        if (orderId == 0 || orderId > _orderCounter) revert OrderNotFound(orderId);

        Order storage order = _orders[orderId];
        if (order.status != OrderStatus.ReadyForPickup) {
            revert OrderNotCompletable(orderId, order.status);
        }

        order.status = OrderStatus.Completed;
        emit OrderStatusUpdated(orderId, OrderStatus.Completed, msg.sender);

        _usdc.safeTransfer(treasury, order.totalAmountUsdc);
        totalEscrowed -= order.totalAmountUsdc;
        emit OrderCompleted(orderId, treasury, order.totalAmountUsdc);
    }

    // -------------------------------------------------------------------------
    // Treasury & withdrawal
    // -------------------------------------------------------------------------

    function proposeTreasury(address newTreasury) external onlyOwner {
        if (newTreasury == address(0)) revert ZeroAddress();
        pendingTreasury = newTreasury;
        emit TreasuryUpdateProposed(newTreasury);
    }

    function acceptTreasury() external {
        if (msg.sender != pendingTreasury) revert NotPendingTreasury(msg.sender, pendingTreasury);
        address oldTreasury = treasury;
        treasury = pendingTreasury;
        pendingTreasury = address(0);
        emit TreasuryUpdated(oldTreasury, treasury);
    }

    /// @notice Withdraw only the surplus USDC (balance above escrowed orders).
    function withdrawUSDC(address to, uint256 amount) external onlyOwner {
        if (to == address(0)) revert ZeroAddress();
        uint256 contractBalance = _usdc.balanceOf(address(this));
        uint256 surplus = contractBalance > totalEscrowed ? contractBalance - totalEscrowed : 0;
        if (amount == 0) revert InvalidAmount();
        if (amount > surplus) revert InsufficientSurplus(amount, surplus);
        _usdc.safeTransfer(to, amount);
    }

    /// @notice Sweep the entire USDC balance (escrowed + surplus) to `to`.
    /// @dev    Sets totalEscrowed to zero so accounting stays consistent.
    ///         Any open orders will no longer be refundable after this call —
    ///         only call it when you are sure no refunds are pending.
    function withdrawAll(address to) external onlyOwner {
        if (to == address(0)) revert ZeroAddress();
        uint256 balance = _usdc.balanceOf(address(this));
        if (balance == 0) revert InvalidAmount();
        totalEscrowed = 0;
        _usdc.safeTransfer(to, balance);
        emit WithdrawnAll(to, balance);
    }

    // -------------------------------------------------------------------------
    // Loyalty
    // -------------------------------------------------------------------------

    function redeemLoyaltyPoints(address customer, uint256 points) external onlyOwner {
        if (customer == address(0)) revert ZeroAddress();
        if (points == 0) revert InvalidAmount();
        uint256 availablePoints = _loyaltyPoints[customer];
        if (availablePoints < points) {
            revert InsufficientLoyaltyPoints(customer, availablePoints, points);
        }
        _loyaltyPoints[customer] = availablePoints - points;
        emit LoyaltyPointsRedeemed(customer, points);
    }

    // -------------------------------------------------------------------------
    // Views
    // -------------------------------------------------------------------------

    function getOrder(uint256 orderId) external view returns (Order memory) {
        if (orderId == 0 || orderId > _orderCounter) revert OrderNotFound(orderId);
        return _orders[orderId];
    }

    function getLoyaltyPoints(address customer) external view returns (uint256) {
        return _loyaltyPoints[customer];
    }

    function getOrdersByCustomer(
        address customer,
        uint256 offset,
        uint256 limit
    ) external view returns (uint256[] memory) {
        uint256[] storage allOrders = _customerOrders[customer];
        uint256 totalOrders = allOrders.length;

        if (offset >= totalOrders || limit == 0) {
            return new uint256[](0);
        }

        uint256 endExclusive = offset + limit;
        if (endExclusive > totalOrders) endExclusive = totalOrders;

        uint256 resultLength = endExclusive - offset;
        uint256[] memory paginatedOrders = new uint256[](resultLength);
        for (uint256 i = 0; i < resultLength; ++i) {
            paginatedOrders[i] = allOrders[offset + i];
        }
        return paginatedOrders;
    }

    function orderCount() external view returns (uint256) {
        return _orderCounter;
    }

    // -------------------------------------------------------------------------
    // Reject ETH
    // -------------------------------------------------------------------------

    receive() external payable {
        revert("VietPhin: ETH not accepted, use USDC");
    }
}
