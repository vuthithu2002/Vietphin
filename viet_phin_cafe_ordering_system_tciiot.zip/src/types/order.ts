export interface CartItem {
  menuItemId: string;
  name: string;
  price: number;          // final price including size delta
  quantity: number;
  size?: string;
  milk?: string;
  sugar?: string;
  ice?: string;
  notes?: string;
}

export interface Cart {
  items: CartItem[];
  pickupTime: string;     // ISO string or HH:MM
  notes: string;
}

export type OrderStatus =
  | 'Received'
  | 'Preparing'
  | 'ReadyForPickup'
  | 'Completed'
  | 'Cancelled'
  | 'Rejected';

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
  Received: 'Order Received',
  Preparing: 'Preparing',
  ReadyForPickup: 'Ready for Pickup',
  Completed: 'Completed',
  Cancelled: 'Cancelled',
  Rejected: 'Rejected',
};

/** On-chain order status enum index (matches Solidity enum order) */
export const ORDER_STATUS_INDEX: Record<OrderStatus, number> = {
  Received: 0,
  Preparing: 1,
  ReadyForPickup: 2,
  Completed: 3,
  Cancelled: 4,
  Rejected: 5,
};

export const ORDER_STATUS_FROM_INDEX: OrderStatus[] = [
  'Received',
  'Preparing',
  'ReadyForPickup',
  'Completed',
  'Cancelled',
  'Rejected',
];

export interface PlacedOrder {
  orderId: string;
  /** Human-readable order code, e.g. VP-241024-0042. Assigned server-side. */
  orderCode: string;
  txHash: string;
  items: CartItem[];
  totalUsdc: number;
  pickupTime: string;
  status: OrderStatus;
  placedAt: number;       // unix ms
  customer: string;
  /** Optional reason recorded when staff cancels an order */
  cancelReason?: string;
  /** On-chain order ID (uint256 returned by placeOrder). Needed for rejectOrder/completeOrder calls. */
  onchainOrderId?: number;
  /** Tx hash of the on-chain rejectOrder call (refund confirmed). */
  refundTxHash?: string;
  /** Tx hash of the on-chain completeOrder call (USDC released to treasury). */
  completeTxHash?: string;
}
