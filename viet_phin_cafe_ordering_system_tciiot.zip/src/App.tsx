import { useState } from 'react';
import { CartProvider, useCart } from './context/CartContext';
import { MenuProvider } from './context/MenuContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomePage } from './components/HomePage';
import { MenuPage } from './components/MenuPage';
import { CartPage } from './components/CartPage';
import { OrdersPage } from './components/OrdersPage';
import { LoyaltyPage } from './components/LoyaltyPage';
import { StaffDashboard } from './components/StaffDashboard';
import type { CartItem } from './types/order';

type View = 'home' | 'menu' | 'cart' | 'orders' | 'loyalty' | 'staff';

function AppContent() {
  const [view, setView] = useState<View>('home');
  const { addItem } = useCart();

  function handleAddToCart(item: CartItem) {
    addItem(item);
  }

  function handleNavigate(v: View) {
    setView(v);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  return (
    <div
      className="min-h-dvh flex flex-col"
      style={{ background: 'var(--bg-gradient)', backgroundAttachment: 'fixed' }}
    >
      <Navbar view={view} onNavigate={handleNavigate} />

      <main className="flex-1">
        {view === 'home' && (
          <HomePage
            onNavigate={(v) => handleNavigate(v)}
            onAddToCart={handleAddToCart}
          />
        )}
        {view === 'menu' && (
          <MenuPage onAddToCart={handleAddToCart} />
        )}
        {view === 'cart' && (
          <CartPage
            onNavigate={(v) => handleNavigate(v)}
          />
        )}
        {view === 'orders' && (
          <OrdersPage onNavigate={(v) => handleNavigate(v)} />
        )}
        {view === 'loyalty' && <LoyaltyPage />}
        {view === 'staff' && <StaffDashboard />}
      </main>

      <Footer onNavigate={handleNavigate} />
    </div>
  );
}

export default function App() {
  return (
    <MenuProvider>
      <CartProvider>
        <AppContent />
      </CartProvider>
    </MenuProvider>
  );
}
