/**
 * wagmi configuration
 * Built with Arc Studio — https://studio.arc.io
 *
 * Auto-reconnect is intentionally disabled: users must connect manually on
 * every visit. This prevents the wallet from silently re-attaching to a
 * previously connected account across sessions or after disconnect.
 *
 * Supports both Arc Testnet (chain 5042002) and Arc Mainnet (chain 5042).
 */

import { http, createConfig, createStorage, noopStorage } from 'wagmi'
import { mainnet } from 'wagmi/chains'
import { arcTestnet, arc } from 'viem/chains'
import { injected } from 'wagmi/connectors'
import { registerChain } from './tracing'

// Pre-register chain RPC URLs so trace events show correct chain names immediately
registerChain(arcTestnet.id, arcTestnet.rpcUrls.default.http[0])
registerChain(arc.id, arc.rpcUrls.default.http[0])

export const config = createConfig({
  chains: [arc, arcTestnet, mainnet], // arc mainnet first = default prompt chain
  connectors: [injected()],
  transports: {
    [arc.id]: http('https://rpc.mainnet.arc.io'),
    [arcTestnet.id]: http('https://rpc.testnet.arc.io'),
    [mainnet.id]: http(), // ENS resolution
  },
  // Disable all wallet state persistence — no auto-reconnect across page loads.
  storage: createStorage({ storage: noopStorage }),
})
