import { motion } from 'framer-motion';
import { Package, Clock, CheckCircle2, XCircle, ChefHat, ExternalLink, Hash } from 'lucide-react';
import { useCart } from '../context/CartContext';
import type { OrderStatus, PlacedOrder } from '../types/order';
import { ORDER_STATUS_LABELS } from '../types/order';
import { buildTxExplorerUrl } from '@/onchain-facts';
import { ARC_TESTNET_CHAIN_ID } from '../lib/contract';

const STATUS_CONFIG: Record<OrderStatus, { icon: React.ReactNode; color: string; bg: string; step: number }> = {
  Received:       { icon: <Clock size={16} />,        color: '#b8860b', bg: 'rgba(184,134,11,0.1)',  step: 1 },
  Preparing:      { icon: <ChefHat size={16} />,      color: '#2563eb', bg: 'rgba(37,99,235,0.1)',   step: 2 },
  ReadyForPickup: { icon: <CheckCircle2 size={16} />, color: '#1a8047', bg: 'rgba(26,128,71,0.1)',   step: 3 },
  Completed:      { icon: <CheckCircle2 size={16} />, color: '#4a2c1a', bg: 'rgba(74,44,26,0.1)',    step: 4 },
  Cancelled:      { icon: <XCircle size={16} />,      color: '#6b7280', bg: 'rgba(107,114,128,0.1)', step: 0 },
  Rejected:       { icon: <XCircle size={16} />,      color: '#b22b2b', bg: 'rgba(178,43,43,0.1)',   step: 0 },
};

const PIPELINE: OrderStatus[] = ['Received', 'Preparing', 'ReadyForPickup'];

function formatPickup(pickupTime: string) {
  try {
    return new Date(pickupTime).toLocaleString('en-US', {
      weekday: 'short', month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit',
    });
  } catch {
    return pickupTime;
  }
}

function formatPlacedAt(ts: number) {
  try {
    return new Date(ts).toLocaleString('en-US', {
      weekday: 'short', month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit',
    });
  } catch {
    return '';
  }
}

function ItemCustomizations({ item }: { item: PlacedOrder['items'][number] }) {
  const parts = [item.size, item.milk, item.sugar, item.ice].filter(Boolean);
  if (parts.length === 0) return null;
  return (
    <span className="text-xs" style={{ color: 'var(--subtle)' }}>
      {' · '}{parts.join(' · ')}
    </span>
  );
}

function OrderCard({ order }: { order: PlacedOrder }) {
  const config = STATUS_CONFIG[order.status];
  const isCancelled = order.status === 'Cancelled' || order.status === 'Rejected';
  const isCompleted = order.status === 'Completed';
  const pipelineStep = PIPELINE.indexOf(order.status);
  const itemCount = order.items.reduce((s, i) => s + i.quantity, 0);

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-3xl overflow-hidden"
      style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}
    >
      {/* ── Header: Order code + status badge ── */}
      <div
        className="flex items-start justify-between gap-3 px-5 py-4"
        style={{ borderBottom: '1px solid var(--border)' }}
      >
        <div className="flex flex-col gap-0.5 min-w-0">
          {/* Order code — primary identifier */}
          <div className="flex items-center gap-1.5">
            <Hash size={13} style={{ color: 'var(--accent-gold)', flexShrink: 0 }} />
            <span
              className="font-mono font-bold text-base tracking-wide"
              style={{ color: 'var(--ink)' }}
            >
              {order.orderCode || <span className="text-xs font-sans font-normal" style={{ color: 'var(--subtle)' }}>assigning…</span>}
            </span>
          </div>
          {/* Placed date */}
          <p className="text-xs" style={{ color: 'var(--subtle)' }}>
            Placed {formatPlacedAt(order.placedAt)}
          </p>
        </div>

        {/* Status badge */}
        <div
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold flex-shrink-0"
          style={{ background: config.bg, color: config.color }}
        >
          {config.icon}
          {ORDER_STATUS_LABELS[order.status]}
        </div>
      </div>

      {/* ── Progress bar ── */}
      {!isCancelled && !isCompleted && (
        <div className="px-5 pt-4 pb-2">
          <div className="flex items-center">
            {PIPELINE.map((s, idx) => (
              <div key={s} className="flex items-center flex-1">
                <div
                  className="flex-1 h-1.5 rounded-full transition-all duration-500"
                  style={{ background: idx <= pipelineStep ? 'var(--accent-gold)' : 'var(--border)' }}
                />
                {idx < PIPELINE.length - 1 && (
                  <div
                    className="w-2 h-2 rounded-full mx-1 flex-shrink-0 transition-all duration-500"
                    style={{ background: idx < pipelineStep ? 'var(--accent-gold)' : 'var(--border)' }}
                  />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-1.5">
            {PIPELINE.map((s) => (
              <span
                key={s}
                className="text-xs"
                style={{ color: order.status === s ? 'var(--accent-gold)' : 'var(--subtle)' }}
              >
                {ORDER_STATUS_LABELS[s]}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* ── Items list ── */}
      <div className="px-5 py-3 flex flex-col gap-2">
        <p className="text-xs font-semibold uppercase tracking-widest mb-0.5" style={{ color: 'var(--subtle)', letterSpacing: '0.1em' }}>
          {itemCount} item{itemCount !== 1 ? 's' : ''}
        </p>
        {order.items.map((item, idx) => (
          <div key={idx} className="flex items-baseline justify-between gap-2">
            <div className="flex-1 min-w-0">
              <span className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>
                {item.quantity > 1 && `${item.quantity}× `}{item.name}
              </span>
              <ItemCustomizations item={item} />
              {item.notes && (
                <span className="block text-xs mt-0.5 italic" style={{ color: 'var(--subtle)' }}>
                  "{item.notes}"
                </span>
              )}
            </div>
            <span className="tabular-nums text-sm font-medium flex-shrink-0" style={{ color: 'var(--muted)' }}>
              ${(item.price * item.quantity).toFixed(2)}
            </span>
          </div>
        ))}
      </div>

      {/* ── Refund / release settlement banner ── */}
      {order.refundTxHash && (
        <div
          className="mx-5 mb-3 flex items-start gap-3 px-4 py-3 rounded-2xl"
          style={{ background: 'rgba(178,43,43,0.06)', border: '1px solid rgba(178,43,43,0.2)' }}
        >
          <XCircle size={15} style={{ color: '#b22b2b', flexShrink: 0, marginTop: 1 }} />
          <div className="flex flex-col gap-0.5 min-w-0">
            <span className="text-xs font-semibold" style={{ color: '#b22b2b' }}>
              Refund confirmed on-chain
            </span>
            <span className="text-xs" style={{ color: 'var(--subtle)' }}>
              ${order.totalUsdc.toFixed(2)} USDC returned to your wallet.
            </span>
            <a
              href={buildTxExplorerUrl(ARC_TESTNET_CHAIN_ID, order.refundTxHash)}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-xs mt-0.5"
              style={{ color: '#b22b2b', textDecoration: 'underline' }}
            >
              View refund transaction <ExternalLink size={10} />
            </a>
          </div>
        </div>
      )}
      {order.completeTxHash && (
        <div
          className="mx-5 mb-3 flex items-start gap-3 px-4 py-3 rounded-2xl"
          style={{ background: 'rgba(26,128,71,0.06)', border: '1px solid rgba(26,128,71,0.2)' }}
        >
          <CheckCircle2 size={15} style={{ color: '#1a8047', flexShrink: 0, marginTop: 1 }} />
          <div className="flex flex-col gap-0.5 min-w-0">
            <span className="text-xs font-semibold" style={{ color: '#1a8047' }}>
              Payment released to shop
            </span>
            <span className="text-xs" style={{ color: 'var(--subtle)' }}>
              ${order.totalUsdc.toFixed(2)} USDC transferred to the shop treasury.
            </span>
            <a
              href={buildTxExplorerUrl(ARC_TESTNET_CHAIN_ID, order.completeTxHash)}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-xs mt-0.5"
              style={{ color: '#1a8047', textDecoration: 'underline' }}
            >
              View release transaction <ExternalLink size={10} />
            </a>
          </div>
        </div>
      )}

      {/* ── Summary row: total + pickup ── */}
      <div
        className="flex items-center justify-between gap-4 px-5 py-3"
        style={{ borderTop: '1px solid var(--border)', background: 'var(--surface-muted)' }}
      >
        {/* Pickup time */}
        <div className="flex items-center gap-1.5 text-xs min-w-0" style={{ color: 'var(--subtle)' }}>
          <Clock size={12} style={{ flexShrink: 0 }} />
          <span className="truncate">Pickup: <strong style={{ color: 'var(--ink)' }}>{formatPickup(order.pickupTime)}</strong></span>
        </div>

        {/* Total + placement tx */}
        <div className="flex items-center gap-3 flex-shrink-0">
          <span className="tabular-nums text-sm font-bold" style={{ color: 'var(--ink)' }}>
            ${order.totalUsdc.toFixed(2)} <span className="text-xs font-normal" style={{ color: 'var(--subtle)' }}>USDC</span>
          </span>
          {order.txHash && (
            <a
              href={buildTxExplorerUrl(ARC_TESTNET_CHAIN_ID, order.txHash)}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-xs underline flex-shrink-0"
              style={{ color: 'var(--subtle)' }}
              title="View order placement transaction"
            >
              Paid <ExternalLink size={10} />
            </a>
          )}
        </div>
      </div>
    </motion.div>
  );
}

interface OrdersPageProps {
  onNavigate: (v: 'menu') => void;
}

export function OrdersPage({ onNavigate }: OrdersPageProps) {
  const { placedOrders } = useCart();

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8">
      <div className="mb-8">
        <p className="text-xs font-semibold uppercase tracking-widest mb-1" style={{ color: 'var(--accent-gold)', letterSpacing: '0.12em' }}>
          Order History
        </p>
        <h1 className="display text-3xl font-bold" style={{ color: 'var(--ink)', letterSpacing: '-0.03em' }}>
          My Orders
        </h1>
      </div>

      {placedOrders.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="w-20 h-20 rounded-3xl flex items-center justify-center mb-5" style={{ background: 'var(--surface-muted)' }}>
            <Package size={36} style={{ color: 'var(--subtle)' }} />
          </div>
          <p className="display text-xl font-semibold mb-2" style={{ color: 'var(--ink)' }}>No orders yet</p>
          <p className="text-sm mb-6" style={{ color: 'var(--muted)' }}>
            Your orders will appear here after you place them
          </p>
          <button
            onClick={() => onNavigate('menu')}
            className="px-6 py-3 rounded-2xl font-semibold text-sm transition-all duration-200 hover:scale-105 active:scale-95"
            style={{ background: 'var(--accent)', color: 'white' }}
          >
            Order now
          </button>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          {placedOrders.map((order) => (
            <OrderCard key={order.orderId} order={order} />
          ))}
        </div>
      )}
    </div>
  );
}
