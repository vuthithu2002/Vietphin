/** Viet Phin SVG logo with phin filter motif */
export function VietPhinLogo({ size = 40, className = '' }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="Viet Phin logo"
    >
      {/* Outer circle */}
      <circle cx="20" cy="20" r="19" stroke="#3d1f0a" strokeWidth="1.5" fill="#faf4eb" />

      {/* Phin filter body — trapezoid */}
      <path d="M13 12 L27 12 L24 24 L16 24 Z" fill="#3d1f0a" />

      {/* Phin filter holes */}
      <circle cx="17" cy="16" r="1" fill="#faf4eb" />
      <circle cx="20" cy="16" r="1" fill="#faf4eb" />
      <circle cx="23" cy="16" r="1" fill="#faf4eb" />
      <circle cx="18.5" cy="19.5" r="1" fill="#faf4eb" />
      <circle cx="21.5" cy="19.5" r="1" fill="#faf4eb" />

      {/* Phin lid handle */}
      <rect x="17" y="10" width="6" height="2.5" rx="1.25" fill="#b8860b" />

      {/* Coffee drip */}
      <path
        d="M20 24 Q20.5 27 20 30"
        stroke="#b8860b"
        strokeWidth="1.5"
        strokeLinecap="round"
        fill="none"
      />

      {/* Cup */}
      <path
        d="M15 30 Q15 34 20 34 Q25 34 25 30 Z"
        fill="#3d1f0a"
        opacity="0.15"
      />
      <path
        d="M15 30 L25 30"
        stroke="#3d1f0a"
        strokeWidth="1.2"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function VietPhinWordmark({ className = '' }: { className?: string }) {
  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <VietPhinLogo size={36} />
      <div className="flex flex-col leading-none">
        <span
          className="display font-bold text-lg tracking-tight"
          style={{ color: 'var(--ink)', letterSpacing: '-0.03em' }}
        >
          Viet Phin
        </span>
        <span
          className="text-xs font-medium tracking-widest uppercase"
          style={{ color: 'var(--accent-gold)', letterSpacing: '0.12em' }}
        >
          Vietnamese Coffee
        </span>
      </div>
    </div>
  );
}
