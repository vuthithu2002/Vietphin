import { useState, useEffect, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ChefHat, Clock, LayoutDashboard, History,
  RefreshCw, Lock, Eye, EyeOff, Package, Hash, Loader2,
  XCircle, ChevronDown, ChevronUp, Filter, Wallet, ShieldCheck,
} from 'lucide-react';
import { useAccount, useWriteContract, useWaitForTransactionReceipt } from 'wagmi';
import { useCart } from '../context/CartContext';
import { ORDER_STATUS_LABELS } from '../types/order';
import type { OrderStatus, PlacedOrder } from '../types/order';
import { ProductManager } from './ProductManager';
import { VIETPHIN_ABI, getVietPhinAddress, parseOnchainError, ARC_TESTNET_CHAIN_ID, ARC_MAINNET_CHAIN_ID, isSupportedChain } from '../lib/contract';
import { buildTxExplorerUrl } from '@/onchain-facts';
import { toast } from 'sonner';

/** Maps our OrderStatus string to the uint8 the contract expects */
const STATUS_ENUM: Record<OrderStatus, number> = {
  Received:       0,
  Preparing:      1,
  ReadyForPickup: 2,
  Completed:      3,
  Cancelled:      4,
  Rejected:       5,
};

// The owner / staff admin wallet — can call rejectOrder, completeOrder, updateOrderStatus
const OWNER_WALLET = '0x078c32a9788cf2368ae57d2de3e180d8f81caa3e';

type StaffTab = 'orders' | 'history' | 'products';

const NEXT_STATUS: Partial<Record<OrderStatus, OrderStatus>> = {
  Received: 'Preparing',
  Preparing: 'ReadyForPickup',
};

const STATUS_COLORS: Record<OrderStatus, { color: string; bg: string }> = {
  Received:      { color: '#b8860b', bg: 'rgba(184,134,11,0.1)' },
  Preparing:     { color: '#2563eb', bg: 'rgba(37,99,235,0.1)'  },
  ReadyForPickup:{ color: '#1a8047', bg: 'rgba(26,128,71,0.1)'  },
  Completed:     { color: '#4a2c1a', bg: 'rgba(74,44,26,0.1)'   },
  Cancelled:     { color: '#6b7280', bg: 'rgba(107,114,128,0.1)' },
  Rejected:      { color: '#b22b2b', bg: 'rgba(178,43,43,0.1)'  },
};

// ── Shared helpers ────────────────────────────────────────────────────────────

function fmtDateTime(ms: number) {
  try {
    return new Date(ms).toLocaleString('en-US', {
      month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit',
    });
  } catch { return ''; }
}

function fmtPickup(raw: string) {
  try {
    return new Date(raw).toLocaleString('en-US', {
      weekday: 'short', month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit',
    });
  } catch { return raw; }
}

// ── Active order card ─────────────────────────────────────────────────────────

function StaffOrderCard({
  order,
  isOwner,
  onAdvance,
  onAdvanceOnChain,
  onCancel,
  onRejectOnChain,
  onCompleteOnChain,
}: {
  order: PlacedOrder;
  isOwner: boolean;
  onAdvance: (orderId: string, newStatus: OrderStatus) => Promise<void>;
  /** Called when isOwner + onchainOrderId — must advance both SQLite and chain */
  onAdvanceOnChain: (order: PlacedOrder, newStatus: OrderStatus) => Promise<void>;
  onCancel: (orderId: string, reason: string) => Promise<void>;
  onRejectOnChain: (order: PlacedOrder) => void;
  onCompleteOnChain: (order: PlacedOrder) => void;
}) {
  const [busy, setBusy] = useState(false);
  const [showCancel, setShowCancel] = useState(false);
  const [cancelReason, setCancelReason] = useState('');

  const config = STATUS_COLORS[order.status];
  const nextStatus = NEXT_STATUS[order.status];
  const itemCount = order.items.reduce((s, i) => s + i.quantity, 0);
  const isReadyForPickup = order.status === 'ReadyForPickup';

  async function doAdvance(status: OrderStatus) {
    setBusy(true);
    try {
      // When the owner is connected and the order has an on-chain ID, advance
      // both the contract state and SQLite together so they stay in sync.
      if (isOwner && order.onchainOrderId) {
        await onAdvanceOnChain(order, status);
      } else {
        await onAdvance(order.orderId, status);
      }
    } finally {
      setBusy(false);
    }
  }

  async function doCancel() {
    setBusy(true);
    try {
      await onCancel(order.orderId, cancelReason);
      setShowCancel(false);
      setCancelReason('');
    } finally { setBusy(false); }
  }

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.97 }}
      className="rounded-3xl overflow-hidden"
      style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-3 px-5 py-4" style={{ borderBottom: '1px solid var(--border)' }}>
        <div className="flex flex-col gap-0.5 min-w-0">
          <div className="flex items-center gap-1.5 flex-wrap">
            <Hash size={13} style={{ color: 'var(--accent-gold)', flexShrink: 0 }} />
            <span className="font-mono font-bold text-base tracking-wide" style={{ color: 'var(--ink)' }}>
              {order.orderCode || <span className="text-xs font-sans font-normal italic" style={{ color: 'var(--subtle)' }}>pending…</span>}
            </span>
            {/* On-chain ID chip — green if present, amber warning if missing */}
            {order.onchainOrderId ? (
              <span
                className="px-1.5 py-0.5 rounded-md text-[10px] font-mono font-semibold"
                style={{ background: 'rgba(26,128,71,0.12)', color: '#1a8047', border: '1px solid rgba(26,128,71,0.25)' }}
                title="On-chain order ID — required for Reject & Refund / Complete & Release"
              >
                #{order.onchainOrderId}
              </span>
            ) : (
              <span
                className="px-1.5 py-0.5 rounded-md text-[10px] font-semibold"
                style={{ background: 'rgba(184,134,11,0.1)', color: '#b8860b', border: '1px solid rgba(184,134,11,0.2)' }}
                title="No on-chain ID — order was not placed through the contract. On-chain Reject/Complete unavailable."
              >
                off-chain
              </span>
            )}
          </div>
          <p className="text-xs" style={{ color: 'var(--subtle)' }}>
            {fmtDateTime(order.placedAt)}
            {order.customer ? ` · ${order.customer.slice(0, 6)}…${order.customer.slice(-4)}` : ''}
          </p>
        </div>
        <div
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold flex-shrink-0"
          style={{ background: config.bg, color: config.color }}
        >
          {ORDER_STATUS_LABELS[order.status]}
        </div>
      </div>

      {/* Items */}
      <div className="px-5 py-3 flex flex-col gap-2">
        <p className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'var(--subtle)', letterSpacing: '0.1em' }}>
          {itemCount} item{itemCount !== 1 ? 's' : ''}
        </p>
        {order.items.map((item, idx) => {
          const custom = [item.size, item.milk, item.sugar, item.ice].filter(Boolean);
          return (
            <div key={idx} className="flex items-baseline justify-between gap-2">
              <div className="flex-1 min-w-0">
                <span className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>
                  {item.quantity > 1 ? `${item.quantity}× ` : ''}{item.name}
                </span>
                {custom.length > 0 && (
                  <span className="text-xs" style={{ color: 'var(--subtle)' }}>{' · '}{custom.join(' · ')}</span>
                )}
              </div>
              <span className="tabular-nums text-xs flex-shrink-0" style={{ color: 'var(--muted)' }}>
                ${(item.price * item.quantity).toFixed(2)}
              </span>
            </div>
          );
        })}
      </div>

      {/* Footer */}
      <div className="px-5 py-3" style={{ borderTop: '1px solid var(--border)', background: 'var(--surface-muted)' }}>
        <div className="flex items-center justify-between gap-2">
          <div className="flex flex-col gap-0.5 min-w-0">
            <span className="tabular-nums text-sm font-bold" style={{ color: 'var(--ink)' }}>
              ${order.totalUsdc.toFixed(2)}{' '}
              <span className="text-xs font-normal" style={{ color: 'var(--subtle)' }}>USDC</span>
            </span>
            <div className="flex items-center gap-1 text-xs" style={{ color: 'var(--subtle)' }}>
              <Clock size={11} />
              <span className="truncate">{fmtPickup(order.pickupTime)}</span>
            </div>
          </div>

          <AnimatePresence mode="wait">
            {busy ? (
              <motion.div key="spin" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="px-3 py-2">
                <Loader2 size={16} className="animate-spin" style={{ color: 'var(--accent)' }} />
              </motion.div>
            ) : (
              <motion.div key="btns" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-2 flex-wrap justify-end">
                {/* Reject button */}
                <button
                  onClick={() => {
                    if (isOwner) {
                      onRejectOnChain(order);
                    } else {
                      setShowCancel((v) => !v);
                    }
                  }}
                  className="flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-150 hover:scale-105 active:scale-95"
                  style={{
                    background: showCancel ? 'rgba(178,43,43,0.12)' : 'var(--surface-strong)',
                    color: showCancel ? '#b22b2b' : 'var(--subtle)',
                    border: '1px solid var(--border)',
                  }}
                >
                  <XCircle size={12} />
                  {isOwner ? 'Reject & Refund' : (showCancel ? 'Keep' : 'Reject')}
                </button>

                {/* Off-chain advance (Received→Preparing, Preparing→ReadyForPickup) */}
                {nextStatus && (
                  <button
                    onClick={() => void doAdvance(nextStatus)}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition-all duration-150 hover:scale-105 active:scale-95"
                    style={{ background: 'var(--accent)', color: 'white' }}
                  >
                    <ChefHat size={12} />
                    {ORDER_STATUS_LABELS[nextStatus]}
                  </button>
                )}

                {/* On-chain complete (ReadyForPickup → Completed, releases USDC to treasury) */}
                {isReadyForPickup && (
                  <button
                    onClick={() => onCompleteOnChain(order)}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition-all duration-150 hover:scale-105 active:scale-95"
                    style={{ background: isOwner ? 'var(--success)' : 'var(--surface-muted)', color: isOwner ? 'white' : 'var(--subtle)', border: isOwner ? 'none' : '1px solid var(--border)' }}
                    title={isOwner ? 'Release USDC to treasury' : 'Connect owner wallet to complete'}
                  >
                    <ShieldCheck size={12} />
                    {isOwner ? 'Complete & Release' : 'Complete'}
                  </button>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Off-chain cancel reason panel (non-owner only) */}
        <AnimatePresence>
          {showCancel && !busy && !isOwner && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden"
            >
              <div className="pt-3 flex flex-col gap-2">
                <input
                  type="text"
                  value={cancelReason}
                  onChange={(e) => setCancelReason(e.target.value)}
                  placeholder="Reason (optional) — e.g. Out of stock"
                  className="w-full px-3 py-2 rounded-xl text-xs outline-none"
                  style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)', color: 'var(--ink)', fontFamily: 'inherit' }}
                />
                <button
                  onClick={() => void doCancel()}
                  className="w-full flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-semibold"
                  style={{ background: '#b22b2b', color: 'white' }}
                >
                  <XCircle size={13} />
                  Confirm Cancellation
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Owner wallet badge */}
        {isOwner && (
          <p className="text-[10px] mt-2 flex items-center gap-1" style={{ color: 'var(--accent-gold)' }}>
            <ShieldCheck size={10} />
            Owner wallet connected — Reject triggers on-chain refund; Complete releases USDC to treasury
          </p>
        )}
      </div>
    </motion.div>
  );
}

// ── On-chain action modal ─────────────────────────────────────────────────────

function OnChainActionModal({
  order,
  action,
  onClose,
  onSuccess,
}: {
  order: PlacedOrder;
  action: 'reject' | 'complete';
  onClose: () => void;
  onSuccess: (orderId: string, newStatus: OrderStatus, txHash: string) => void;
}) {
  const { chainId: walletChainId } = useAccount();
  // Always prefer mainnet when the wallet is on mainnet; fall back to testnet
  const activeChainId: typeof ARC_MAINNET_CHAIN_ID | typeof ARC_TESTNET_CHAIN_ID =
    walletChainId === ARC_MAINNET_CHAIN_ID ? ARC_MAINNET_CHAIN_ID : ARC_TESTNET_CHAIN_ID;
  const contractAddress = getVietPhinAddress(activeChainId);
  const networkLabel = activeChainId === ARC_MAINNET_CHAIN_ID ? 'Arc Mainnet' : 'Arc Testnet';
  const { writeContract, data: txHash, isPending, error: writeError } = useWriteContract();
  const { isLoading: isConfirming, isSuccess, error: receiptError } = useWaitForTransactionReceipt({ hash: txHash });

  const isReject = action === 'reject';
  const title = isReject ? 'Reject Order & Refund Customer' : 'Complete Order & Release USDC';
  const description = isReject
    ? `This will call rejectOrder on-chain, automatically refunding $${order.totalUsdc.toFixed(2)} USDC to the customer's wallet.`
    : `This will call completeOrder on-chain, releasing $${order.totalUsdc.toFixed(2)} USDC from escrow to the treasury wallet.`;
  const confirmLabel = isReject ? 'Confirm Reject & Refund' : 'Confirm Complete & Release';
  const newStatus: OrderStatus = isReject ? 'Rejected' : 'Completed';

  const error = writeError ?? receiptError;

  useEffect(() => {
    if (isSuccess && txHash) {
      onSuccess(order.orderId, newStatus, txHash);
      onClose();
    }
  }, [isSuccess, txHash, order.orderId, newStatus, onSuccess, onClose]);

  function handleConfirm() {
    if (!contractAddress) return;
    writeContract({
      address: contractAddress,
      abi: VIETPHIN_ABI,
      functionName: isReject ? 'rejectOrder' : 'completeOrder',
      args: [BigInt(order.onchainOrderId ?? 0)],
      chainId: activeChainId, // forces wallet to be on the right network before signing
    });
  }

  const isBusy = isPending || isConfirming;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(28,14,8,0.6)', backdropFilter: 'blur(4px)' }}>
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="w-full max-w-sm rounded-3xl overflow-hidden"
        style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: '1px solid var(--border)' }}>
          <div className="flex items-center gap-2">
            {isReject
              ? <XCircle size={18} style={{ color: '#b22b2b' }} />
              : <ShieldCheck size={18} style={{ color: 'var(--success)' }} />
            }
            <span className="font-bold text-sm" style={{ color: 'var(--ink)' }}>{title}</span>
          </div>
          <button onClick={onClose} disabled={isBusy} style={{ color: 'var(--subtle)' }}>
            <XCircle size={16} />
          </button>
        </div>

        {/* Body */}
        <div className="px-5 py-4 flex flex-col gap-4">
          {/* Order summary */}
          <div className="rounded-2xl p-3 flex flex-col gap-1" style={{ background: 'var(--surface-muted)' }}>
            <div className="flex items-center gap-1.5">
              <Hash size={12} style={{ color: 'var(--accent-gold)' }} />
              <span className="font-mono text-sm font-bold" style={{ color: 'var(--ink)' }}>{order.orderCode}</span>
            </div>
            <p className="text-xs" style={{ color: 'var(--subtle)' }}>
              {order.items.length} item{order.items.length !== 1 ? 's' : ''} · ${order.totalUsdc.toFixed(2)} USDC
            </p>
          </div>

          <p className="text-sm leading-relaxed" style={{ color: 'var(--muted)' }}>{description}</p>

          {order.onchainOrderId ? (
            <div className="rounded-xl p-3 flex items-center gap-2" style={{ background: 'rgba(26,128,71,0.08)', border: '1px solid rgba(26,128,71,0.2)' }}>
              <span className="text-xs font-semibold" style={{ color: '#1a8047' }}>On-chain order</span>
              <span className="font-mono text-xs font-bold" style={{ color: '#1a8047' }}>#{order.onchainOrderId}</span>
              <span className="text-xs ml-auto" style={{ color: 'var(--subtle)' }}>{networkLabel}</span>
            </div>
          ) : (
            <div className="rounded-xl p-3 flex items-start gap-2" style={{ background: 'rgba(184,134,11,0.1)', border: '1px solid rgba(184,134,11,0.3)' }}>
              <p className="text-xs" style={{ color: '#b8860b' }}>
                This order has no on-chain ID — it was not placed through the smart contract. On-chain Reject and Complete are unavailable. Use the off-chain Cancel button instead.
              </p>
            </div>
          )}

          {error && (
            <div className="rounded-xl p-3" style={{ background: 'rgba(178,43,43,0.1)', border: '1px solid rgba(178,43,43,0.3)' }}>
              <p className="text-xs font-medium" style={{ color: '#b22b2b' }}>{parseOnchainError(error)}</p>
            </div>
          )}

          {isConfirming && (
            <div className="flex items-center gap-2 text-xs" style={{ color: 'var(--subtle)' }}>
              <Loader2 size={13} className="animate-spin" />
              Confirming on-chain…
            </div>
          )}
        </div>

        {/* Buttons */}
        <div className="px-5 pb-5 flex flex-col gap-2">
          <button
            onClick={handleConfirm}
            disabled={isBusy || !order.onchainOrderId}
            className="w-full py-3 rounded-2xl font-semibold text-sm transition-all duration-200 hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            style={{ background: isReject ? '#b22b2b' : 'var(--success)', color: 'white' }}
          >
            {isBusy ? <Loader2 size={15} className="animate-spin" /> : null}
            {isBusy ? 'Processing…' : confirmLabel}
          </button>
          <button
            onClick={onClose}
            disabled={isBusy}
            className="w-full py-2.5 rounded-2xl text-sm font-medium transition-all duration-200 hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50"
            style={{ background: 'var(--surface-muted)', color: 'var(--muted)', border: '1px solid var(--border)' }}
          >
            Cancel
          </button>
        </div>
      </motion.div>
    </div>
  );
}

// ── History order card (read-only) ────────────────────────────────────────────

function HistoryCard({ order, chainId: displayChainId }: { order: PlacedOrder; chainId?: number }) {
  const resolvedChainId = displayChainId ?? ARC_TESTNET_CHAIN_ID;
  const [expanded, setExpanded] = useState(false);
  const config = STATUS_COLORS[order.status];
  const itemCount = order.items.reduce((s, i) => s + i.quantity, 0);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl overflow-hidden"
      style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}
    >
      <button
        onClick={() => setExpanded((v) => !v)}
        className="w-full flex items-center gap-3 px-4 py-3 text-left transition-colors"
      >
        <div className="flex flex-col gap-0.5 flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-mono text-sm font-bold" style={{ color: 'var(--ink)' }}>
              {order.orderCode || order.orderId.slice(0, 10)}
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold" style={{ background: config.bg, color: config.color }}>
              {ORDER_STATUS_LABELS[order.status]}
            </span>
          </div>
          <p className="text-xs" style={{ color: 'var(--subtle)' }}>
            {fmtDateTime(order.placedAt)} · {itemCount} item{itemCount !== 1 ? 's' : ''} · ${order.totalUsdc.toFixed(2)} USDC
          </p>
          {order.cancelReason && (
            <p className="text-xs italic" style={{ color: '#b22b2b' }}>Reason: {order.cancelReason}</p>
          )}
          {(order.refundTxHash || order.completeTxHash) && (
            <a
              href={buildTxExplorerUrl(resolvedChainId, (order.refundTxHash ?? order.completeTxHash)!)}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs flex items-center gap-1 mt-0.5"
              style={{ color: order.refundTxHash ? '#b22b2b' : '#1a8047', textDecoration: 'underline' }}
              onClick={(e) => e.stopPropagation()}
            >
              {order.refundTxHash ? '↩ Refund tx' : '✓ Release tx'} ↗
            </a>
          )}
        </div>
        <div style={{ color: 'var(--subtle)', flexShrink: 0 }}>
          {expanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
        </div>
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 flex flex-col gap-2" style={{ borderTop: '1px solid var(--border)' }}>
              <div className="pt-3 flex flex-col gap-1.5">
                {order.items.map((item, idx) => {
                  const custom = [item.size, item.milk, item.sugar, item.ice].filter(Boolean);
                  return (
                    <div key={idx} className="flex items-baseline justify-between gap-2">
                      <span className="text-sm" style={{ color: 'var(--ink)' }}>
                        {item.quantity > 1 ? `${item.quantity}× ` : ''}{item.name}
                        {custom.length > 0 && <span className="text-xs" style={{ color: 'var(--subtle)' }}> · {custom.join(' · ')}</span>}
                      </span>
                      <span className="tabular-nums text-xs" style={{ color: 'var(--muted)' }}>
                        ${(item.price * item.quantity).toFixed(2)}
                      </span>
                    </div>
                  );
                })}
              </div>
              <div className="flex items-center justify-between pt-1 mt-1" style={{ borderTop: '1px solid var(--border)' }}>
                <span className="flex items-center gap-1 text-xs" style={{ color: 'var(--subtle)' }}>
                  <Clock size={11} />
                  Pickup: {fmtPickup(order.pickupTime)}
                </span>
                <span className="tabular-nums text-sm font-bold" style={{ color: 'var(--ink)' }}>
                  ${order.totalUsdc.toFixed(2)} USDC
                </span>
              </div>

              {/* On-chain settlement links */}
              {order.refundTxHash && (
                <div className="flex items-center gap-2 px-3 py-2 rounded-xl" style={{ background: 'rgba(178,43,43,0.06)', border: '1px solid rgba(178,43,43,0.18)' }}>
                  <span className="text-xs font-semibold" style={{ color: '#b22b2b' }}>↩ Refunded on-chain</span>
                  <a
                    href={buildTxExplorerUrl(resolvedChainId, order.refundTxHash)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs font-mono truncate"
                    style={{ color: '#b22b2b', textDecoration: 'underline' }}
                  >
                    {order.refundTxHash.slice(0, 10)}…{order.refundTxHash.slice(-6)} ↗
                  </a>
                </div>
              )}
              {order.completeTxHash && (
                <div className="flex items-center gap-2 px-3 py-2 rounded-xl" style={{ background: 'rgba(26,128,71,0.06)', border: '1px solid rgba(26,128,71,0.18)' }}>
                  <span className="text-xs font-semibold" style={{ color: '#1a8047' }}>✓ USDC released to treasury</span>
                  <a
                    href={buildTxExplorerUrl(resolvedChainId, order.completeTxHash)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs font-mono truncate"
                    style={{ color: '#1a8047', textDecoration: 'underline' }}
                  >
                    {order.completeTxHash.slice(0, 10)}…{order.completeTxHash.slice(-6)} ↗
                  </a>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

// ── Login gate ────────────────────────────────────────────────────────────────

const STAFF_HASH = btoa('vietphin2026');

function StaffLogin({ onUnlock }: { onUnlock: () => void }) {
  const [pw, setPw] = useState('');
  const [show, setShow] = useState(false);
  const [error, setError] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (btoa(pw) === STAFF_HASH) {
      onUnlock();
    } else {
      setError(true);
      setPw('');
      setTimeout(() => setError(false), 2000);
    }
  }

  return (
    <div className="max-w-sm mx-auto px-4 py-16 flex flex-col items-center gap-6">
      <div className="w-16 h-16 rounded-2xl flex items-center justify-center" style={{ background: 'var(--accent)', color: 'white' }}>
        <Lock size={28} />
      </div>
      <div className="text-center">
        <h2 className="display text-2xl font-bold mb-1" style={{ color: 'var(--ink)' }}>Staff Access</h2>
        <p className="text-sm" style={{ color: 'var(--muted)' }}>Enter your staff password to view and manage orders.</p>
      </div>
      <form onSubmit={handleSubmit} className="w-full flex flex-col gap-3">
        <div className="relative">
          <input
            type={show ? 'text' : 'password'}
            value={pw}
            onChange={(e) => setPw(e.target.value)}
            placeholder="Staff password"
            autoComplete="current-password"
            className="w-full px-4 py-3.5 pr-12 rounded-2xl text-sm outline-none"
            style={{ background: 'var(--surface-strong)', border: `1px solid ${error ? 'var(--danger)' : 'var(--border)'}`, color: 'var(--ink)', fontFamily: 'inherit' }}
          />
          <button type="button" onClick={() => setShow((s) => !s)} className="absolute right-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--muted)' }}>
            {show ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
        </div>
        {error && <p className="text-xs font-medium" style={{ color: 'var(--danger)' }}>Incorrect password. Please try again.</p>}
        <button type="submit" className="w-full py-3.5 rounded-2xl font-semibold text-sm transition-all duration-200 hover:scale-[1.01] active:scale-[0.99]" style={{ background: 'var(--accent)', color: 'white' }}>
          Access Dashboard
        </button>
      </form>
      <p className="text-xs text-center" style={{ color: 'var(--subtle)' }}>
        Demo password: <span className="font-mono">vietphin2026</span>
      </p>
    </div>
  );
}

// ── Main dashboard ────────────────────────────────────────────────────────────

export function StaffDashboard() {
  const { placedOrders, updateOrderStatus, refreshOrders } = useCart();
  const { address: walletAddress, chainId: walletChainId } = useAccount();
  const isMainnet = walletChainId === ARC_MAINNET_CHAIN_ID;
  const dashboardChainId = isMainnet ? ARC_MAINNET_CHAIN_ID : ARC_TESTNET_CHAIN_ID;
  const { writeContractAsync: advanceWriteAsync } = useWriteContract();
  const [filter, setFilter] = useState<OrderStatus | 'all'>('all');
  const [unlocked, setUnlocked] = useState(false);
  const [tab, setTab] = useState<StaffTab>('orders');
  const [refreshing, setRefreshing] = useState(false);
  const [historyStatus, setHistoryStatus] = useState<'all' | 'Completed' | 'Cancelled' | 'Rejected'>('all');
  const [historyDate, setHistoryDate] = useState('');
  const [onChainModal, setOnChainModal] = useState<{ order: PlacedOrder; action: 'reject' | 'complete' } | null>(null);

  const isOwner = walletAddress?.toLowerCase() === OWNER_WALLET;

  // ── All hooks before any conditional return ───────────────────────────────

  const handleAdvance = useCallback(
    async (orderId: string, newStatus: OrderStatus) => {
      await updateOrderStatus(orderId, newStatus);
    },
    [updateOrderStatus],
  );

  const handleCancel = useCallback(
    async (orderId: string, reason: string) => {
      await updateOrderStatus(orderId, 'Cancelled', reason || undefined);
    },
    [updateOrderStatus],
  );

  /**
   * Advance an on-chain order status (Received→Preparing or Preparing→ReadyForPickup).
   * Calls updateOrderStatus on the contract first, then syncs SQLite on success.
   * completeOrder requires ReadyForPickup — this is what makes that work.
   */
  const handleAdvanceOnChain = useCallback(
    async (order: PlacedOrder, newStatus: OrderStatus) => {
      const contractAddress = getVietPhinAddress(dashboardChainId);
      if (!contractAddress || !order.onchainOrderId) return;
      try {
        const hash = await advanceWriteAsync({
          address: contractAddress,
          abi: VIETPHIN_ABI,
          functionName: 'updateOrderStatus',
          args: [BigInt(order.onchainOrderId), STATUS_ENUM[newStatus]],
          chainId: dashboardChainId,
        });
        toast.success(`Order advanced to ${ORDER_STATUS_LABELS[newStatus]}`);
        // Sync SQLite after the tx is broadcast (no need to wait for confirmation)
        await updateOrderStatus(order.orderId, newStatus, undefined, hash);
      } catch (err) {
        const msg = parseOnchainError(err);
        toast.error(`Failed to advance order: ${msg}`);
        throw err;
      }
    },
    [dashboardChainId, advanceWriteAsync, updateOrderStatus],
  );

  const handleOnChainSuccess = useCallback(
    (orderId: string, newStatus: OrderStatus, txHash: string) => {
      void updateOrderStatus(orderId, newStatus, undefined, txHash);
    },
    [updateOrderStatus],
  );

  const doRefresh = useCallback(() => {
    setRefreshing(true);
    void refreshOrders().finally(() => setRefreshing(false));
  }, [refreshOrders]);

  // Refresh orders whenever the Orders or History tab is visible.
  // Also refresh on window focus so a staff member picking up the device
  // immediately sees the latest orders without waiting for the poll.
  useEffect(() => {
    if (!unlocked || (tab !== 'orders' && tab !== 'history')) return;
    doRefresh();
    const id = setInterval(doRefresh, 15_000); // poll every 15 s
    window.addEventListener('focus', doRefresh);
    return () => {
      clearInterval(id);
      window.removeEventListener('focus', doRefresh);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [unlocked, tab]);

  const activeTabs: Array<OrderStatus | 'all'> = ['all', 'Received', 'Preparing', 'ReadyForPickup'];

  const counts = useMemo<Partial<Record<OrderStatus | 'all', number>>>(() => ({
    all:            placedOrders.filter((o) => o.status !== 'Completed' && o.status !== 'Cancelled' && o.status !== 'Rejected').length,
    Received:       placedOrders.filter((o) => o.status === 'Received').length,
    Preparing:      placedOrders.filter((o) => o.status === 'Preparing').length,
    ReadyForPickup: placedOrders.filter((o) => o.status === 'ReadyForPickup').length,
  }), [placedOrders]);

  const activeOrders = useMemo(() => placedOrders.filter((o) =>
    filter === 'all'
      ? o.status !== 'Completed' && o.status !== 'Cancelled' && o.status !== 'Rejected'
      : o.status === filter,
  ), [placedOrders, filter]);

  const historyOrders = useMemo(() => {
    return placedOrders
      .filter((o) => o.status === 'Completed' || o.status === 'Cancelled' || o.status === 'Rejected')
      .filter((o) => historyStatus === 'all' || o.status === historyStatus)
      .filter((o) => {
        if (!historyDate) return true;
        const d = new Date(o.placedAt);
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const dd = String(d.getDate()).padStart(2, '0');
        return `${y}-${m}-${dd}` === historyDate;
      });
  }, [placedOrders, historyStatus, historyDate]);

  if (!unlocked) return <StaffLogin onUnlock={() => setUnlocked(true)} />;

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
      {/* On-chain action modal */}
      {onChainModal && (
        <OnChainActionModal
          order={onChainModal.order}
          action={onChainModal.action}
          onClose={() => setOnChainModal(null)}
          onSuccess={handleOnChainSuccess}
        />
      )}

      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <LayoutDashboard size={20} style={{ color: 'var(--accent-gold)' }} />
            <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--accent-gold)', letterSpacing: '0.12em' }}>Staff Portal</p>
          </div>
          <h1 className="display text-3xl font-bold" style={{ color: 'var(--ink)', letterSpacing: '-0.03em' }}>Staff Dashboard</h1>
          {/* Owner wallet + network indicator */}
          <div className="flex items-center gap-2 flex-wrap mt-1.5">
            <div className="flex items-center gap-1.5 text-xs font-medium" style={{ color: isOwner ? 'var(--accent-gold)' : 'var(--subtle)' }}>
              {isOwner ? <ShieldCheck size={13} /> : <Wallet size={13} />}
              {isOwner
                ? 'Owner wallet connected — on-chain actions enabled'
                : walletAddress
                  ? `Connected: ${walletAddress.slice(0, 6)}…${walletAddress.slice(-4)} (not owner)`
                  : 'No wallet — connect owner wallet to reject/complete orders on-chain'
              }
            </div>
            {walletChainId && isSupportedChain(walletChainId) && (
              <span
                className="px-2 py-0.5 rounded-full text-[10px] font-semibold"
                style={{
                  background: isMainnet ? 'rgba(74,44,26,0.15)' : 'rgba(37,99,235,0.1)',
                  color: isMainnet ? '#4a2c1a' : '#2563eb',
                  border: `1px solid ${isMainnet ? 'rgba(74,44,26,0.3)' : 'rgba(37,99,235,0.2)'}`,
                }}
              >
                {isMainnet ? '🟢 Arc Mainnet' : '🔵 Arc Testnet'}
              </span>
            )}
          </div>
        </div>
        {(tab === 'orders' || tab === 'history') && (
          <button
            onClick={doRefresh}
            disabled={refreshing}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium transition-all duration-200 hover:scale-105 active:scale-95 disabled:opacity-50 mt-2"
            style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)', color: 'var(--muted)' }}
          >
            <RefreshCw size={13} className={refreshing ? 'animate-spin' : ''} />
            Refresh
          </button>
        )}
      </div>

      {/* Tab bar */}
      <div className="flex rounded-2xl overflow-hidden p-1 mb-6" style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}>
        {(
          [
            { id: 'orders', label: 'Orders',   icon: <ChefHat  size={15} />, badge: counts.all },
            { id: 'history', label: 'History',  icon: <History  size={15} />, badge: undefined  },
            { id: 'products', label: 'Products', icon: <Package  size={15} />, badge: undefined  },
          ] satisfies { id: StaffTab; label: string; icon: React.ReactNode; badge: number | undefined }[]
        ).map(({ id, label, icon, badge }) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-all duration-200 relative"
            style={{ background: tab === id ? 'var(--accent)' : 'transparent', color: tab === id ? 'white' : 'var(--muted)' }}
          >
            {icon}{label}
            {badge !== undefined && badge > 0 && tab !== id && (
              <span className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-bold" style={{ background: '#b22b2b', color: 'white' }}>
                {badge > 9 ? '9+' : badge}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Products tab */}
      {tab === 'products' && <ProductManager />}

      {/* Active Orders tab */}
      {tab === 'orders' && (
        <div className="flex flex-col gap-6">
          <div className="grid grid-cols-3 gap-3">
            {(['Received', 'Preparing', 'ReadyForPickup'] as OrderStatus[]).map((s) => (
              <div key={s} className="rounded-2xl p-4 text-center" style={{ background: STATUS_COLORS[s].bg, border: `1.5px solid ${STATUS_COLORS[s].color}22` }}>
                <p className="display text-2xl font-bold tabular-nums" style={{ color: STATUS_COLORS[s].color }}>{counts[s] ?? 0}</p>
                <p className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>{ORDER_STATUS_LABELS[s]}</p>
              </div>
            ))}
          </div>

          <div className="flex gap-2 overflow-x-auto pb-1">
            {activeTabs.map((t) => (
              <button
                key={t}
                onClick={() => setFilter(t)}
                className="flex-shrink-0 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200"
                style={{ background: filter === t ? 'var(--accent)' : 'var(--surface-strong)', color: filter === t ? 'white' : 'var(--muted)', border: '1px solid var(--border)' }}
              >
                {t === 'all' ? 'Active' : ORDER_STATUS_LABELS[t]}
                {(counts[t] ?? 0) > 0 && (
                  <span className="ml-1.5 px-1.5 py-0.5 rounded-full text-xs" style={{ background: filter === t ? 'rgba(255,255,255,0.3)' : 'var(--surface-muted)' }}>
                    {counts[t]}
                  </span>
                )}
              </button>
            ))}
          </div>

          {activeOrders.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4" style={{ background: 'var(--surface-muted)' }}>
                <ChefHat size={28} style={{ color: 'var(--subtle)' }} />
              </div>
              <p className="font-medium" style={{ color: 'var(--ink)' }}>No active orders</p>
              <p className="text-sm mt-1" style={{ color: 'var(--muted)' }}>New orders appear here — auto-refreshing every 30 s</p>
            </div>
          ) : (
            <AnimatePresence mode="popLayout">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {activeOrders.map((order) => (
                  <StaffOrderCard
                    key={order.orderId}
                    order={order}
                    isOwner={isOwner}
                    onAdvance={handleAdvance}
                    onAdvanceOnChain={handleAdvanceOnChain}
                    onCancel={handleCancel}
                    onRejectOnChain={(o) => setOnChainModal({ order: o, action: 'reject' })}
                    onCompleteOnChain={(o) => setOnChainModal({ order: o, action: 'complete' })}
                  />
                ))}
              </div>
            </AnimatePresence>
          )}

          <p className="text-xs text-center" style={{ color: 'var(--subtle)' }}>
            {isOwner
              ? 'All status changes (Preparing, Ready, Complete, Reject) are recorded on-chain.'
              : 'Connect the owner wallet to enable on-chain status tracking and Reject & Complete.'}
          </p>
        </div>
      )}

      {/* History tab */}
      {tab === 'history' && (
        <div className="flex flex-col gap-5">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex items-center gap-2 flex-1">
              <Filter size={13} style={{ color: 'var(--subtle)', flexShrink: 0 }} />
              <div className="flex gap-1.5 overflow-x-auto">
                {(['all', 'Completed', 'Rejected', 'Cancelled'] as const).map((s) => (
                  <button
                    key={s}
                    onClick={() => setHistoryStatus(s)}
                    className="flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-medium transition-all duration-150"
                    style={{
                      background: historyStatus === s ? 'var(--accent)' : 'var(--surface-strong)',
                      color: historyStatus === s ? 'white' : 'var(--muted)',
                      border: '1px solid var(--border)',
                    }}
                  >
                    {s === 'all' ? 'All' : ORDER_STATUS_LABELS[s]}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="date"
                value={historyDate}
                onChange={(e) => setHistoryDate(e.target.value)}
                className="px-3 py-1.5 rounded-xl text-xs outline-none"
                style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)', color: historyDate ? 'var(--ink)' : 'var(--subtle)', fontFamily: 'inherit' }}
              />
              {historyDate && (
                <button onClick={() => setHistoryDate('')} className="text-xs" style={{ color: 'var(--subtle)' }}>Clear</button>
              )}
            </div>
          </div>

          <div className="flex gap-4 px-4 py-3 rounded-2xl text-sm" style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}>
            <div className="flex flex-col">
              <span className="text-xs" style={{ color: 'var(--subtle)' }}>Orders</span>
              <span className="font-bold tabular-nums" style={{ color: 'var(--ink)' }}>{historyOrders.length}</span>
            </div>
            <div className="flex flex-col">
              <span className="text-xs" style={{ color: 'var(--subtle)' }}>Revenue</span>
              <span className="font-bold tabular-nums" style={{ color: 'var(--ink)' }}>
                ${historyOrders.filter((o) => o.status === 'Completed').reduce((s, o) => s + o.totalUsdc, 0).toFixed(2)} USDC
              </span>
            </div>
            <div className="flex flex-col">
              <span className="text-xs" style={{ color: '#b22b2b' }}>Rejected/Cancelled</span>
              <span className="font-bold tabular-nums" style={{ color: '#b22b2b' }}>
                {historyOrders.filter((o) => o.status === 'Rejected' || o.status === 'Cancelled').length}
              </span>
            </div>
          </div>

          {historyOrders.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4" style={{ background: 'var(--surface-muted)' }}>
                <History size={28} style={{ color: 'var(--subtle)' }} />
              </div>
              <p className="font-medium" style={{ color: 'var(--ink)' }}>No history yet</p>
              <p className="text-sm mt-1" style={{ color: 'var(--muted)' }}>Completed and cancelled orders will appear here</p>
            </div>
          ) : (
            <div className="flex flex-col gap-2">
              {historyOrders.map((order) => (
                <HistoryCard key={order.orderId} order={order} chainId={dashboardChainId} />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
