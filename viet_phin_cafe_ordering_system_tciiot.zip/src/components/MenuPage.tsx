import { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, X, ChevronRight } from 'lucide-react';
import { CATEGORY_LABELS, CATEGORY_LABELS_VI, CATEGORY_ORDER } from '../data/menuData';
import type { Category } from '../data/menuData';
import { useMenu } from '../context/MenuContext';
import { MenuItemCard } from './MenuItemCard';
import type { CartItem } from '../types/order';

interface MenuPageProps {
  onAddToCart: (item: CartItem) => void;
}

const CATEGORY_EMOJI: Record<Category, string> = {
  vietnamese: '☕',
  milktea: '🧋',
  tea: '🍵',
  pastries: '🥐',
  sandwiches: '🥖',
  desserts: '🍮',
};

export function MenuPage({ onAddToCart }: MenuPageProps) {
  const { visibleItems } = useMenu();
  const [activeCategory, setActiveCategory] = useState<Category | 'all'>('all');
  const [search, setSearch] = useState('');
  const tabsRef = useRef<HTMLDivElement>(null);
  const sectionRefs = useRef<Record<string, HTMLElement | null>>({});

  // Scroll active tab into view in the scrollable tab strip
  useEffect(() => {
    if (!tabsRef.current) return;
    const active = tabsRef.current.querySelector('[data-active="true"]') as HTMLElement | null;
    active?.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
  }, [activeCategory]);

  const filtered = visibleItems.filter((item) => {
    const matchCat = activeCategory === 'all' || item.category === activeCategory;
    const q = search.toLowerCase().trim();
    if (!q) return matchCat;
    return (
      matchCat &&
      (item.name.toLowerCase().includes(q) ||
        (item.nameVi?.toLowerCase().includes(q) ?? false) ||
        item.description.toLowerCase().includes(q) ||
        (item.tags?.some((t) => t.toLowerCase().includes(q)) ?? false))
    );
  });

  const groupedCategories =
    activeCategory === 'all'
      ? CATEGORY_ORDER.filter((cat) => filtered.some((i) => i.category === cat))
      : ([activeCategory] as Category[]);

  function handleCategoryClick(cat: Category | 'all') {
    setActiveCategory(cat);
    if (cat !== 'all') {
      setTimeout(() => {
        const el = sectionRefs.current[cat];
        if (el) {
          const offset = 136; // navbar + sticky tab bar height
          const top = el.getBoundingClientRect().top + window.scrollY - offset;
          window.scrollTo({ top, behavior: 'smooth' });
        }
      }, 60);
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  const totalVisible = visibleItems.length;

  return (
    <div className="min-h-dvh">
      {/* ── Page header ──────────────────────────────────────────── */}
      <div
        className="px-4 sm:px-6 pt-8 pb-6"
        style={{ background: 'linear-gradient(180deg, #2c1810 0%, #3d1f0a 100%)' }}
      >
        <div className="max-w-4xl mx-auto">
          <p
            className="text-xs font-semibold uppercase tracking-widest mb-2"
            style={{ color: '#d4a520', letterSpacing: '0.14em' }}
          >
            Our Menu
          </p>
          <h1
            className="display text-3xl md:text-4xl font-bold mb-5"
            style={{ color: '#faf7f2', letterSpacing: '-0.02em' }}
          >
            What are you craving?
          </h1>

          {/* Search bar */}
          <div
            className="flex items-center gap-3 px-4 py-3 rounded-2xl"
            style={{
              background: 'rgba(250,247,242,0.10)',
              border: '1.5px solid rgba(250,247,242,0.18)',
            }}
          >
            <Search size={17} style={{ color: 'rgba(250,247,242,0.55)', flexShrink: 0 }} />
            <input
              type="text"
              placeholder="Search drinks, food, ingredients…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="flex-1 bg-transparent text-sm outline-none placeholder:opacity-50"
              style={{ color: '#faf7f2', fontFamily: 'inherit' }}
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="flex items-center justify-center w-5 h-5 rounded-full"
                style={{ background: 'rgba(250,247,242,0.2)', color: '#faf7f2' }}
                aria-label="Clear search"
              >
                <X size={11} />
              </button>
            )}
          </div>

          {/* Result count */}
          <p className="text-xs mt-2.5" style={{ color: 'rgba(250,247,242,0.45)' }}>
            {search
              ? `${filtered.length} result${filtered.length !== 1 ? 's' : ''} for "${search}"`
              : `${totalVisible} items across ${CATEGORY_ORDER.length} categories`}
          </p>
        </div>
      </div>

      {/* ── Sticky category tab strip ─────────────────────────────── */}
      <div
        className="sticky z-40"
        style={{
          top: 64, // height of the navbar
          background: 'rgba(250,247,242,0.95)',
          backdropFilter: 'blur(16px)',
          WebkitBackdropFilter: 'blur(16px)',
          borderBottom: '1px solid var(--border)',
          boxShadow: '0 2px 12px rgba(44,24,16,0.06)',
        }}
      >
        <div
          ref={tabsRef}
          className="max-w-4xl mx-auto flex items-center gap-2 px-4 sm:px-6 overflow-x-auto py-3"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {/* All tab */}
          <button
            data-active={activeCategory === 'all'}
            onClick={() => handleCategoryClick('all')}
            className="flex-shrink-0 flex items-center gap-1.5 h-9 px-4 rounded-xl text-sm font-semibold whitespace-nowrap transition-all duration-200 hover:scale-[1.02] active:scale-95"
            style={{
              background: activeCategory === 'all' ? 'var(--accent)' : 'var(--surface-muted)',
              color: activeCategory === 'all' ? '#faf7f2' : 'var(--muted)',
              border: `1.5px solid ${activeCategory === 'all' ? 'var(--accent)' : 'transparent'}`,
            }}
          >
            All
          </button>

          {CATEGORY_ORDER.map((cat) => {
            const isActive = activeCategory === cat;
            const count = visibleItems.filter((i) => i.category === cat).length;
            return (
              <button
                key={cat}
                data-active={isActive}
                onClick={() => handleCategoryClick(cat)}
                className="flex-shrink-0 flex items-center gap-2 h-9 px-4 rounded-xl text-sm font-medium whitespace-nowrap transition-all duration-200 hover:scale-[1.02] active:scale-95"
                style={{
                  background: isActive ? 'var(--accent)' : 'var(--surface-muted)',
                  color: isActive ? '#faf7f2' : 'var(--muted)',
                  border: `1.5px solid ${isActive ? 'var(--accent)' : 'transparent'}`,
                  fontWeight: isActive ? 600 : 400,
                }}
              >
                <span style={{ fontSize: 15 }}>{CATEGORY_EMOJI[cat]}</span>
                <span>{CATEGORY_LABELS_VI[cat]}</span>
                {!isActive && (
                  <span
                    className="text-xs rounded-full px-1.5 py-0.5 tabular-nums leading-none"
                    style={{ background: 'rgba(44,24,16,0.08)', color: 'var(--subtle)' }}
                  >
                    {count}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* ── Main content ─────────────────────────────────────────── */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">

        {/* Empty state */}
        {filtered.length === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center py-24 text-center"
          >
            <div
              className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4"
              style={{ background: 'var(--surface-muted)' }}
            >
              <Search size={26} style={{ color: 'var(--subtle)' }} />
            </div>
            <p className="display text-lg font-bold mb-1" style={{ color: 'var(--ink)' }}>
              Nothing found
            </p>
            <p className="text-sm mb-5" style={{ color: 'var(--muted)' }}>
              Try a different keyword or browse all categories.
            </p>
            <button
              onClick={() => { setSearch(''); setActiveCategory('all'); }}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all hover:scale-[1.02] active:scale-95"
              style={{ background: 'var(--accent)', color: 'white' }}
            >
              <X size={14} />
              Clear filters
            </button>
          </motion.div>
        )}

        {/* Category sections */}
        <div className="flex flex-col gap-14">
          {groupedCategories.map((cat) => {
            const items = filtered.filter((i) => i.category === cat);
            if (items.length === 0) return null;
            return (
              <section
                key={cat}
                ref={(el) => { sectionRefs.current[cat] = el; }}
              >
                {/* Section header */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0"
                      style={{ background: 'var(--surface-muted)' }}
                    >
                      {CATEGORY_EMOJI[cat]}
                    </div>
                    <div>
                      <h2
                        className="display text-xl md:text-2xl font-bold leading-tight"
                        style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}
                      >
                        {CATEGORY_LABELS[cat]}
                      </h2>
                      <p className="text-xs mt-0.5 flex items-center gap-1" style={{ color: 'var(--accent-gold)' }}>
                        <span className="font-medium">{CATEGORY_LABELS_VI[cat]}</span>
                        <span style={{ color: 'var(--border-strong)' }}>·</span>
                        <span style={{ color: 'var(--subtle)' }}>{items.length} items</span>
                      </p>
                    </div>
                  </div>
                  <span
                    className="hidden sm:flex items-center gap-1 text-xs font-medium"
                    style={{ color: 'var(--subtle)' }}
                  >
                    Scroll to explore <ChevronRight size={13} />
                  </span>
                </div>

                {/* Divider */}
                <div className="mb-5" style={{ height: 1, background: 'var(--border)' }} />

                {/* Product grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                  {items.map((item, idx) => (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.25, delay: Math.min(idx * 0.04, 0.3) }}
                      style={{ display: 'flex', flexDirection: 'column' }}
                    >
                      <MenuItemCard item={item} onAddToCart={onAddToCart} />
                    </motion.div>
                  ))}
                </div>
              </section>
            );
          })}
        </div>

        {/* Bottom padding */}
        <div className="h-12" />
      </div>
    </div>
  );
}
