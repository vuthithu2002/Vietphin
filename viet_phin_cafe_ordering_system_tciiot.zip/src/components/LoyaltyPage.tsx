import { motion } from 'framer-motion';
import { Star, Gift, Wallet, TrendingUp } from 'lucide-react';
import { useAccount, useReadContract } from 'wagmi';
import { ConnectKitButton } from 'connectkit';
import { ARC_TESTNET_CHAIN_ID, VIETPHIN_ABI, getVietPhinAddress } from '../lib/contract';
import { useCart } from '../context/CartContext';

const REWARDS = [
  { points: 5, label: 'Free Drip Coffee', description: 'Redeem for a complimentary Cà Phê Đen' },
  { points: 8, label: 'Free Iced Latte', description: 'Any size, any milk' },
  { points: 12, label: '50% off Egg Coffee', description: 'Half-price on our signature egg coffee' },
  { points: 20, label: 'Free Bánh Mì', description: 'Classic or Veggie, your choice' },
  { points: 30, label: 'Free Dessert Platter', description: 'Chè Ba Màu + Pandan Pudding' },
];

export function LoyaltyPage() {
  const { address, isConnected } = useAccount();
  const { placedOrders } = useCart();

  const contractAddress = getVietPhinAddress();

  const { data: onchainPoints } = useReadContract({
    address: contractAddress ?? '0x0000000000000000000000000000000000000001',
    abi: VIETPHIN_ABI,
    functionName: 'getLoyaltyPoints',
    args: [address ?? '0x0000000000000000000000000000000000000000'],
    chainId: ARC_TESTNET_CHAIN_ID,
    query: { enabled: Boolean(address && contractAddress) },
  });

  // Local estimate from placed orders (before on-chain sync)
  const localPoints = placedOrders.reduce((s, o) => s + Math.floor(o.totalUsdc), 0);
  const displayPoints = onchainPoints !== undefined ? Number(onchainPoints) : localPoints;

  const totalSpent = placedOrders.reduce((s, o) => s + o.totalUsdc, 0);
  const nextReward = REWARDS.find((r) => r.points > displayPoints);
  const progress = nextReward ? (displayPoints / nextReward.points) * 100 : 100;

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8">
      <div className="mb-8">
        <p className="text-xs font-semibold uppercase tracking-widest mb-1" style={{ color: 'var(--accent-gold)', letterSpacing: '0.12em' }}>
          Rewards
        </p>
        <h1 className="display text-3xl font-bold" style={{ color: 'var(--ink)', letterSpacing: '-0.03em' }}>
          Loyalty Program
        </h1>
      </div>

      {!isConnected ? (
        <div className="flex flex-col items-center justify-center py-20 text-center gap-5">
          <div className="w-20 h-20 rounded-3xl flex items-center justify-center" style={{ background: 'var(--surface-muted)' }}>
            <Wallet size={36} style={{ color: 'var(--subtle)' }} />
          </div>
          <div>
            <p className="display text-xl font-semibold mb-2" style={{ color: 'var(--ink)' }}>Connect to view points</p>
            <p className="text-sm" style={{ color: 'var(--muted)' }}>
              Your loyalty points are stored on-chain and tied to your wallet address
            </p>
          </div>
          <ConnectKitButton />
        </div>
      ) : (
        <div className="flex flex-col gap-6">
          {/* Points hero card */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-3xl p-6 relative overflow-hidden"
            style={{ background: 'linear-gradient(135deg, #2c1810 0%, #5c3317 100%)' }}
          >
            <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 80% 20%, #d4a520, transparent 60%)' }} />
            <div className="relative z-10">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-widest mb-1" style={{ color: 'rgba(212,165,32,0.8)', letterSpacing: '0.12em' }}>
                    Your Balance
                  </p>
                  <p className="display text-5xl font-bold tabular-nums" style={{ color: '#faf4eb', letterSpacing: '-0.03em' }}>
                    {displayPoints}
                  </p>
                  <p className="text-sm mt-1" style={{ color: 'rgba(250,244,235,0.6)' }}>
                    loyalty points
                  </p>
                </div>
                <div
                  className="w-12 h-12 rounded-2xl flex items-center justify-center"
                  style={{ background: 'rgba(212,165,32,0.2)' }}
                >
                  <Star size={24} fill="#d4a520" style={{ color: '#d4a520' }} />
                </div>
              </div>

              {/* Progress to next reward */}
              {nextReward && (
                <div>
                  <div className="flex justify-between text-xs mb-2" style={{ color: 'rgba(250,244,235,0.6)' }}>
                    <span>Next reward: <strong style={{ color: '#d4a520' }}>{nextReward.label}</strong></span>
                    <span className="tabular-nums">{displayPoints} / {nextReward.points} pts</span>
                  </div>
                  <div className="h-2 rounded-full" style={{ background: 'rgba(250,244,235,0.15)' }}>
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${Math.min(progress, 100)}%` }}
                      transition={{ duration: 0.8, ease: 'easeOut' }}
                      className="h-full rounded-full"
                      style={{ background: '#d4a520' }}
                    />
                  </div>
                  <p className="text-xs mt-1.5" style={{ color: 'rgba(250,244,235,0.5)' }}>
                    {nextReward.points - displayPoints} more points to unlock
                  </p>
                </div>
              )}
            </div>
          </motion.div>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-4">
            <div className="rounded-2xl p-4" style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}>
              <TrendingUp size={18} style={{ color: 'var(--accent-gold)' }} className="mb-2" />
              <p className="text-xs" style={{ color: 'var(--subtle)' }}>Total spent</p>
              <p className="display text-xl font-bold tabular-nums mt-0.5" style={{ color: 'var(--ink)' }}>
                ${totalSpent.toFixed(2)}
              </p>
              <p className="text-xs" style={{ color: 'var(--subtle)' }}>USDC</p>
            </div>
            <div className="rounded-2xl p-4" style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}>
              <Gift size={18} style={{ color: 'var(--accent-gold)' }} className="mb-2" />
              <p className="text-xs" style={{ color: 'var(--subtle)' }}>Total orders</p>
              <p className="display text-xl font-bold tabular-nums mt-0.5" style={{ color: 'var(--ink)' }}>
                {placedOrders.length}
              </p>
              <p className="text-xs" style={{ color: 'var(--subtle)' }}>orders placed</p>
            </div>
          </div>

          {/* Earn guide */}
          <div className="rounded-3xl p-5" style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}>
            <h3 className="font-semibold text-sm mb-3" style={{ color: 'var(--ink)' }}>How to earn points</h3>
            <div className="flex items-center gap-3 p-3 rounded-2xl" style={{ background: 'var(--surface-muted)' }}>
              <Star size={20} fill="var(--accent-gold)" style={{ color: 'var(--accent-gold)', flexShrink: 0 }} />
              <div>
                <p className="text-sm font-medium" style={{ color: 'var(--ink)' }}>1 point per USDC spent</p>
                <p className="text-xs" style={{ color: 'var(--muted)' }}>Points are recorded on-chain with every order</p>
              </div>
            </div>
          </div>

          {/* Rewards catalog */}
          <div>
            <h3 className="font-semibold text-base mb-4" style={{ color: 'var(--ink)' }}>Reward Catalog</h3>
            <div className="flex flex-col gap-3">
              {REWARDS.map((reward) => {
                const canRedeem = displayPoints >= reward.points;
                return (
                  <motion.div
                    key={reward.label}
                    whileHover={{ scale: 1.01 }}
                    className="flex items-center gap-4 p-4 rounded-2xl transition-all duration-200"
                    style={{
                      background: canRedeem ? 'rgba(26,128,71,0.05)' : 'var(--surface-strong)',
                      border: `1.5px solid ${canRedeem ? 'rgba(26,128,71,0.3)' : 'var(--border)'}`,
                    }}
                  >
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                      style={{
                        background: canRedeem ? 'rgba(26,128,71,0.1)' : 'var(--surface-muted)',
                      }}
                    >
                      <Gift size={20} style={{ color: canRedeem ? 'var(--success)' : 'var(--subtle)' }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm" style={{ color: 'var(--ink)' }}>{reward.label}</p>
                      <p className="text-xs" style={{ color: 'var(--muted)' }}>{reward.description}</p>
                    </div>
                    <div className="flex flex-col items-end flex-shrink-0">
                      <span
                        className="display text-lg font-bold tabular-nums"
                        style={{ color: canRedeem ? 'var(--success)' : 'var(--subtle)' }}
                      >
                        {reward.points}
                      </span>
                      <span className="text-xs" style={{ color: 'var(--subtle)' }}>pts</span>
                      {canRedeem && (
                        <span className="text-xs font-medium mt-0.5" style={{ color: 'var(--success)' }}>
                          Redeemable
                        </span>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </div>
            <p className="text-xs text-center mt-4" style={{ color: 'var(--subtle)' }}>
              To redeem, show your connected wallet address to staff
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
