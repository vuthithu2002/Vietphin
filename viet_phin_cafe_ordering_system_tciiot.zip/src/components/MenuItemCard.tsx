import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, X, Check, Snowflake, Coffee } from 'lucide-react';
import type { MenuItem, SizeOption } from '../data/menuData';
import { DEFAULT_SIZES, MILK_OPTIONS, SUGAR_LEVELS, ICE_LEVELS } from '../data/menuData';
import type { CartItem } from '../types/order';

interface MenuItemCardProps {
  item: MenuItem & { paused?: boolean };
  onAddToCart: (item: CartItem) => void;
}

// ── Pill option button ─────────────────────────────────────────────────────────
function OptionPill({
  label, selected, onClick,
}: { label: string; selected: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="px-3 py-1.5 rounded-xl text-xs font-medium transition-all duration-150 active:scale-95 whitespace-nowrap"
      style={{
        background: selected ? 'var(--accent)' : 'var(--surface-muted)',
        color: selected ? 'white' : 'var(--muted)',
        border: `1px solid ${selected ? 'var(--accent)' : 'var(--border)'}`,
      }}
    >
      {label}
    </button>
  );
}

// ── Section heading inside the modal ─────────────────────────────────────────
function OptionSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <p
        className="text-[10px] font-bold uppercase tracking-widest mb-2"
        style={{ color: 'var(--subtle)', letterSpacing: '0.12em' }}
      >
        {title}
      </p>
      <div className="flex flex-wrap gap-1.5">{children}</div>
    </div>
  );
}

// ── Main card ─────────────────────────────────────────────────────────────────
export function MenuItemCard({ item, onAddToCart }: MenuItemCardProps) {
  const [showCustomize, setShowCustomize] = useState(false);
  const [selectedSize, setSelectedSize] = useState<SizeOption | null>(
    item.sizes ? item.sizes[0] : null,
  );
  const [selectedMilk, setSelectedMilk] = useState<string>(
    item.milkOptions ? item.milkOptions[0] : '',
  );
  const [selectedSugar, setSelectedSugar] = useState<string>(
    item.sugarLevels ? item.sugarLevels[4] ?? item.sugarLevels[0] : '',
  );
  const [selectedIce, setSelectedIce] = useState<string>(
    item.iceLevels ? (item.iceLevels[2] ?? item.iceLevels[0]) : '',
  );
  const [added, setAdded] = useState(false);

  const hasSizes = Boolean(item.sizes?.length);
  const hasMilk  = Boolean(item.milkOptions?.length);
  const hasSugar = Boolean(item.sugarLevels?.length);
  const hasIce   = Boolean(item.iceLevels?.length);
  const hasOptions = hasSizes || hasMilk || hasSugar || hasIce;

  const finalPrice = item.price + (selectedSize?.priceDelta ?? 0);
  const FALLBACK = 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=600&q=80';

  function doAdd() {
    onAddToCart({
      menuItemId: item.id,
      name: item.name,
      price: finalPrice,
      quantity: 1,
      size: selectedSize?.label,
      milk: selectedMilk || undefined,
      sugar: selectedSugar || undefined,
      ice: selectedIce || undefined,
    });
    setAdded(true);
    setShowCustomize(false);
    setTimeout(() => setAdded(false), 2200);
  }

  return (
    <>
      {/* ── Card ─────────────────────────────────────────────────── */}
      <article
        className="rounded-2xl overflow-hidden flex flex-col h-full group transition-all duration-300 hover:shadow-xl hover:-translate-y-0.5"
        style={{
          background: 'var(--surface-strong)',
          border: '1px solid var(--border)',
          boxShadow: '0 2px 12px rgba(44,24,16,0.07)',
        }}
      >
        {/* Image — fixed height so cards align */}
        <div
          className="relative flex-shrink-0 overflow-hidden"
          style={{ height: 176, background: '#f0e8d8' }}
        >
          <img
            src={item.imageUrl || FALLBACK}
            alt={item.name}
            loading="lazy"
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
            onError={(e) => { (e.target as HTMLImageElement).src = FALLBACK; }}
          />
          {/* Popular badge */}
          {item.popular && (
            <span
              className="absolute top-2.5 left-2.5 flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold"
              style={{ background: '#b8860b', color: 'white', backdropFilter: 'blur(4px)' }}
            >
              ★ Popular
            </span>
          )}
          {/* Vietnamese name badge */}
          {item.nameVi && item.nameVi !== item.name && (
            <span
              className="absolute bottom-2 left-2.5 px-2 py-0.5 rounded-full text-[11px] italic"
              style={{
                background: 'rgba(28,14,8,0.65)',
                color: 'rgba(250,244,235,0.92)',
                backdropFilter: 'blur(4px)',
              }}
            >
              {item.nameVi}
            </span>
          )}
          {/* Customizable badge (hidden when paused) */}
          {hasOptions && !item.paused && (
            <span
              className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-full text-[10px] font-semibold"
              style={{
                background: 'rgba(250,244,235,0.85)',
                color: 'var(--accent)',
                backdropFilter: 'blur(4px)',
              }}
            >
              Customise
            </span>
          )}
          {/* Sold-out overlay */}
          {item.paused && (
            <div
              className="absolute inset-0 flex items-center justify-center"
              style={{ background: 'rgba(28,14,8,0.55)' }}
            >
              <span
                className="px-3 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest"
                style={{ background: 'rgba(28,14,8,0.75)', color: 'rgba(250,244,235,0.9)', backdropFilter: 'blur(4px)' }}
              >
                Unavailable
              </span>
            </div>
          )}
        </div>

        {/* Body — flex-1 so it fills remaining height */}
        <div className="flex flex-col flex-1 p-4">
          {/* Name + description */}
          <div className="flex-1">
            <h3
              className="font-semibold text-[15px] leading-snug mb-1"
              style={{ color: 'var(--ink)' }}
            >
              {item.name}
            </h3>
            <p
              className="text-sm leading-relaxed"
              style={{
                color: 'var(--muted)',
                display: '-webkit-box',
                WebkitLineClamp: 2,
                WebkitBoxOrient: 'vertical',
                overflow: 'hidden',
              }}
            >
              {item.description}
            </p>

            {/* Tags */}
            {item.tags && item.tags.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-2">
                {item.tags.slice(0, 2).map((t) => (
                  <span
                    key={t}
                    className="px-2 py-0.5 rounded-full text-[11px]"
                    style={{ background: 'var(--surface-muted)', color: 'var(--subtle)' }}
                  >
                    {t}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Price + Add button — always pinned to bottom */}
          <div
            className="flex items-center justify-between mt-4 pt-3"
            style={{ borderTop: '1px solid var(--border)' }}
          >
            <div>
              <span
                className="display text-xl font-bold tabular-nums leading-none"
                style={{ color: 'var(--ink)' }}
              >
                ${finalPrice.toFixed(2)}
              </span>
              <span className="text-xs ml-1 font-normal" style={{ color: 'var(--subtle)' }}>
                USDC
              </span>
            </div>

            <button
              type="button"
              disabled={item.paused}
              onClick={() => !item.paused && (hasOptions ? setShowCustomize(true) : doAdd())}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-200 hover:scale-[1.04] active:scale-95 disabled:cursor-not-allowed disabled:opacity-60"
              style={{
                background: item.paused ? 'var(--surface-muted)' : added ? 'var(--success)' : 'var(--accent)',
                color: item.paused ? 'var(--subtle)' : 'white',
                minWidth: 76,
                justifyContent: 'center',
              }}
            >
              {item.paused ? (
                <>Sold out</>
              ) : added ? (
                <><Check size={14} />Added</>
              ) : (
                <><Plus size={14} />Add</>
              )}
            </button>
          </div>
        </div>
      </article>

      {/* ── Customisation modal ──────────────────────────────────── */}
      <AnimatePresence>
        {showCustomize && (
          <motion.div
            key="overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-6"
            style={{ background: 'rgba(28,14,8,0.6)', backdropFilter: 'blur(2px)' }}
            onClick={(e) => { if (e.target === e.currentTarget) setShowCustomize(false); }}
          >
            <motion.div
              key="sheet"
              initial={{ y: 48, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 48, opacity: 0 }}
              transition={{ type: 'spring', damping: 28, stiffness: 320 }}
              className="w-full sm:max-w-sm rounded-t-3xl sm:rounded-3xl overflow-hidden flex flex-col"
              style={{
                background: 'var(--bg)',
                border: '1px solid var(--border)',
                maxHeight: '92dvh',
              }}
            >
              {/* Item image header */}
              <div
                className="relative flex-shrink-0 overflow-hidden"
                style={{ height: 140, background: '#f0e8d8' }}
              >
                <img
                  src={item.imageUrl || FALLBACK}
                  alt={item.name}
                  className="w-full h-full object-cover"
                  onError={(e) => { (e.target as HTMLImageElement).src = FALLBACK; }}
                />
                <div
                  className="absolute inset-0"
                  style={{ background: 'linear-gradient(to top, rgba(28,14,8,0.65) 0%, transparent 55%)' }}
                />
                <button
                  type="button"
                  onClick={() => setShowCustomize(false)}
                  className="absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center transition-all hover:scale-110"
                  style={{ background: 'rgba(28,14,8,0.55)', color: 'white' }}
                  aria-label="Close"
                >
                  <X size={15} />
                </button>
                <div className="absolute bottom-3 left-4 right-4">
                  <p className="display font-bold text-base text-white leading-snug line-clamp-1">
                    {item.name}
                  </p>
                  {item.nameVi && item.nameVi !== item.name && (
                    <p className="text-xs italic" style={{ color: 'rgba(250,244,235,0.75)' }}>
                      {item.nameVi}
                    </p>
                  )}
                </div>
              </div>

              {/* Scrollable options */}
              <div className="flex-1 overflow-y-auto px-5 py-4 flex flex-col gap-4">
                <p className="text-sm leading-relaxed" style={{ color: 'var(--muted)' }}>
                  {item.description}
                </p>

                {hasSizes && (
                  <OptionSection title="Size">
                    {(item.sizes ?? DEFAULT_SIZES).map((s) => (
                      <button
                        key={s.label}
                        type="button"
                        onClick={() => setSelectedSize(s)}
                        className="flex flex-col items-center px-4 py-2 rounded-xl text-sm font-medium transition-all duration-150 active:scale-95"
                        style={{
                          background: selectedSize?.label === s.label ? 'var(--accent)' : 'var(--surface-muted)',
                          color: selectedSize?.label === s.label ? 'white' : 'var(--ink)',
                          border: `1px solid ${selectedSize?.label === s.label ? 'var(--accent)' : 'var(--border)'}`,
                          minWidth: 56,
                        }}
                      >
                        <span>{s.label}</span>
                        {s.priceDelta > 0 && (
                          <span className="text-[10px] opacity-75 tabular-nums">+${s.priceDelta.toFixed(2)}</span>
                        )}
                      </button>
                    ))}
                  </OptionSection>
                )}

                {hasMilk && (
                  <OptionSection title="Milk">
                    {(item.milkOptions ?? MILK_OPTIONS).map((m) => (
                      <OptionPill key={m} label={m} selected={selectedMilk === m} onClick={() => setSelectedMilk(m)} />
                    ))}
                  </OptionSection>
                )}

                {hasSugar && (
                  <OptionSection title="Sweetness">
                    {(item.sugarLevels ?? SUGAR_LEVELS).map((s) => (
                      <OptionPill key={s} label={s} selected={selectedSugar === s} onClick={() => setSelectedSugar(s)} />
                    ))}
                  </OptionSection>
                )}

                {hasIce && (
                  <OptionSection title={
                    <span className="flex items-center gap-1">
                      <Snowflake size={10} />Ice Level
                    </span> as unknown as string
                  }>
                    {(item.iceLevels ?? ICE_LEVELS).map((lvl) => (
                      <OptionPill key={lvl} label={lvl} selected={selectedIce === lvl} onClick={() => setSelectedIce(lvl)} />
                    ))}
                  </OptionSection>
                )}
              </div>

              {/* Footer — price + add to cart */}
              <div
                className="flex-shrink-0 flex items-center justify-between px-5 py-4"
                style={{ borderTop: '1px solid var(--border)', background: 'var(--surface-strong)' }}
              >
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-widest mb-0.5" style={{ color: 'var(--subtle)' }}>
                    Total
                  </p>
                  <div className="flex items-baseline gap-1">
                    <span className="display text-2xl font-bold tabular-nums" style={{ color: 'var(--ink)' }}>
                      ${finalPrice.toFixed(2)}
                    </span>
                    <span className="text-xs" style={{ color: 'var(--subtle)' }}>USDC</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={doAdd}
                  className="flex items-center gap-2 px-6 py-3 rounded-2xl font-semibold text-sm transition-all duration-200 hover:scale-[1.03] active:scale-95"
                  style={{ background: 'var(--accent)', color: 'white' }}
                >
                  <Coffee size={15} />
                  Add to cart
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
