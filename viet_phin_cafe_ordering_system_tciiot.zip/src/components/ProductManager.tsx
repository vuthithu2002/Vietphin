/**
 * ProductManager — staff product CRUD panel.
 * Lives inside StaffDashboard behind the password gate.
 */

import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus, Pencil, Trash2, Eye, EyeOff, Star, StarOff,
  Upload, Link2, X, Check, Search, ImageOff, ChevronDown,
  Tag, DollarSign, LayoutGrid, PauseCircle, PlayCircle, Loader2,
} from 'lucide-react';
import { useAccount } from 'wagmi';
import { useMenu } from '../context/MenuContext';
import { blankProduct } from '../data/blankProduct';
import type { ManagedMenuItem } from '../context/MenuContext';
import {
  CATEGORY_LABELS, CATEGORY_LABELS_VI, CATEGORY_ORDER,
} from '../data/menuData';
import type { Category } from '../data/menuData';

// ── Product Form ──────────────────────────────────────────────────────────────

interface ProductFormProps {
  initial: Omit<ManagedMenuItem, 'id'> & { id?: string };
  onSave: (data: Omit<ManagedMenuItem, 'id'>) => void;
  onCancel: () => void;
  isNew?: boolean;
}

function ImageUploader({
  value,
  onChange,
}: {
  value: string;
  onChange: (url: string) => void;
}) {
  const [mode, setMode] = useState<'url' | 'upload'>('url');
  const [urlInput, setUrlInput] = useState(value.startsWith('data:') ? '' : value);
  const [dragging, setDragging] = useState(false);

  // Local file uploads cannot be stored on-chain (base64 data URLs exceed block
  // gas limits). Show an info message and keep the existing URL instead.
  const [uploadHint, setUploadHint] = useState(false);

  function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    setDragging(false);
    setUploadHint(true);
  }

  function handleUrlBlur() {
    if (urlInput.trim()) onChange(urlInput.trim());
  }

  const preview = value || urlInput;

  return (
    <div className="flex flex-col gap-2">
      <label className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--subtle)', letterSpacing: '0.1em' }}>
        Product Image
      </label>

      {/* Mode toggle */}
      <div className="flex rounded-xl overflow-hidden" style={{ border: '1px solid var(--border)' }}>
        {(['url', 'upload'] as const).map((m) => (
          <button
            key={m}
            type="button"
            onClick={() => setMode(m)}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-medium transition-all duration-150"
            style={{
              background: mode === m ? 'var(--accent)' : 'var(--surface-strong)',
              color: mode === m ? 'white' : 'var(--muted)',
            }}
          >
            {m === 'url' ? <Link2 size={12} /> : <Upload size={12} />}
            {m === 'url' ? 'Paste URL' : 'Upload File'}
          </button>
        ))}
      </div>

      {mode === 'url' ? (
        <input
          type="url"
          value={urlInput}
          onChange={(e) => setUrlInput(e.target.value)}
          onBlur={handleUrlBlur}
          placeholder="https://images.unsplash.com/..."
          className="w-full px-3.5 py-2.5 rounded-xl text-sm outline-none"
          style={{
            background: 'var(--surface-strong)',
            border: '1px solid var(--border)',
            color: 'var(--ink)',
          }}
        />
      ) : (
        <div
          className="rounded-xl flex flex-col items-center justify-center gap-2 py-6 transition-all duration-200"
          style={{
            border: `2px dashed ${dragging ? 'var(--accent)' : 'var(--border)'}`,
            background: dragging ? 'rgba(150,90,50,0.06)' : 'var(--surface-strong)',
          }}
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={handleDrop}
        >
          <Upload size={20} style={{ color: 'var(--subtle)' }} />
          {uploadHint ? (
            <p className="text-xs text-center px-4" style={{ color: '#ea580c' }}>
              Local files can't be stored on-chain.<br />
              Please upload your image to a hosting service (e.g. Unsplash, Imgur, Cloudinary) and paste the URL instead.
            </p>
          ) : (
            <>
              <p className="text-xs" style={{ color: 'var(--muted)' }}>
                Images must be hosted online
              </p>
              <p className="text-[10px] text-center px-4" style={{ color: 'var(--subtle)' }}>
                Use "Paste URL" to add an image URL from Unsplash, Imgur, or any CDN
              </p>
            </>
          )}
        </div>
      )}

      {/* Preview */}
      {preview ? (
        <div className="relative rounded-xl overflow-hidden" style={{ height: 120 }}>
          <img
            src={preview}
            alt="Preview"
            className="w-full h-full object-cover"
            onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
          />
          <button
            type="button"
            onClick={() => { onChange(''); setUrlInput(''); }}
            className="absolute top-2 right-2 w-7 h-7 rounded-full flex items-center justify-center"
            style={{ background: 'rgba(44,24,16,0.7)', color: 'white' }}
          >
            <X size={13} />
          </button>
        </div>
      ) : (
        <div
          className="rounded-xl flex items-center justify-center"
          style={{ height: 80, background: 'var(--surface-muted)', border: '1px solid var(--border)' }}
        >
          <ImageOff size={20} style={{ color: 'var(--subtle)' }} />
        </div>
      )}
    </div>
  );
}

function FieldLabel({ children }: { children: React.ReactNode }) {
  return (
    <label className="text-xs font-semibold uppercase tracking-widest block mb-1.5" style={{ color: 'var(--subtle)', letterSpacing: '0.1em' }}>
      {children}
    </label>
  );
}

function TextInput({
  value, onChange, placeholder, multiline, type,
}: {
  value: string; onChange: (v: string) => void; placeholder?: string;
  multiline?: boolean; type?: string;
}) {
  const base = {
    background: 'var(--surface-strong)',
    border: '1px solid var(--border)',
    color: 'var(--ink)',
    outline: 'none',
    width: '100%',
    fontFamily: 'inherit',
    fontSize: '0.875rem',
    padding: '0.625rem 0.875rem',
    borderRadius: '0.75rem',
    resize: 'vertical' as const,
  };
  if (multiline) {
    return (
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows={3}
        style={base}
      />
    );
  }
  return (
    <input
      type={type ?? 'text'}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      style={base}
    />
  );
}

function ProductForm({ initial, onSave, onCancel, isNew }: ProductFormProps) {
  const [form, setForm] = useState<Omit<ManagedMenuItem, 'id'>>(() => ({ ...initial }));
  const [tagInput, setTagInput] = useState('');

  function patch(updates: Partial<Omit<ManagedMenuItem, 'id'>>) {
    setForm((f) => ({ ...f, ...updates }));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim()) return;
    onSave(form);
  }

  function addTag() {
    const t = tagInput.trim().toLowerCase();
    if (t && !form.tags?.includes(t)) {
      patch({ tags: [...(form.tags ?? []), t] });
    }
    setTagInput('');
  }

  function removeTag(t: string) {
    patch({ tags: (form.tags ?? []).filter((x) => x !== t) });
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-5">
      {/* Category */}
      <div>
        <FieldLabel>Category</FieldLabel>
        <div className="relative">
          <select
            value={form.category}
            onChange={(e) => patch({ category: e.target.value as Category })}
            className="w-full appearance-none px-3.5 py-2.5 pr-9 rounded-xl text-sm outline-none"
            style={{
              background: 'var(--surface-strong)',
              border: '1px solid var(--border)',
              color: 'var(--ink)',
              fontFamily: 'inherit',
            }}
          >
            {CATEGORY_ORDER.map((c) => (
              <option key={c} value={c}>
                {CATEGORY_LABELS_VI[c]} — {CATEGORY_LABELS[c]}
              </option>
            ))}
          </select>
          <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: 'var(--subtle)' }} />
        </div>
      </div>

      {/* Names row */}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <FieldLabel>Name (English) *</FieldLabel>
          <TextInput value={form.name} onChange={(v) => patch({ name: v })} placeholder="e.g. Egg Coffee" />
        </div>
        <div>
          <FieldLabel>Tên tiếng Việt</FieldLabel>
          <TextInput value={form.nameVi ?? ''} onChange={(v) => patch({ nameVi: v })} placeholder="e.g. Cà Phê Trứng" />
        </div>
      </div>

      {/* Description */}
      <div>
        <FieldLabel>Description</FieldLabel>
        <TextInput
          value={form.description}
          onChange={(v) => patch({ description: v })}
          placeholder="Short, appetizing description of this item…"
          multiline
        />
      </div>

      {/* Price */}
      <div>
        <FieldLabel>Price (USDC)</FieldLabel>
        <div className="relative">
          <DollarSign size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--subtle)' }} />
          <input
            type="number"
            step="0.01"
            min="0.01"
            max="99.99"
            value={form.price}
            onChange={(e) => patch({ price: parseFloat(e.target.value) || 0 })}
            className="w-full pl-8 pr-3.5 py-2.5 rounded-xl text-sm outline-none"
            style={{
              background: 'var(--surface-strong)',
              border: '1px solid var(--border)',
              color: 'var(--ink)',
              fontFamily: 'inherit',
            }}
          />
        </div>
      </div>

      {/* Image */}
      <ImageUploader
        value={form.imageUrl}
        onChange={(url) => patch({ imageUrl: url })}
      />

      {/* Tags */}
      <div>
        <FieldLabel>Tags</FieldLabel>
        <div className="flex gap-2 mb-2">
          <input
            type="text"
            value={tagInput}
            onChange={(e) => setTagInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addTag(); } }}
            placeholder="Add tag and press Enter"
            className="flex-1 px-3.5 py-2 rounded-xl text-sm outline-none"
            style={{
              background: 'var(--surface-strong)',
              border: '1px solid var(--border)',
              color: 'var(--ink)',
              fontFamily: 'inherit',
            }}
          />
          <button
            type="button"
            onClick={addTag}
            className="px-3 rounded-xl text-sm font-medium"
            style={{ background: 'var(--accent)', color: 'white' }}
          >
            Add
          </button>
        </div>
        {(form.tags ?? []).length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {(form.tags ?? []).map((t) => (
              <span
                key={t}
                className="flex items-center gap-1 px-2.5 py-1 rounded-full text-xs"
                style={{ background: 'var(--surface-muted)', color: 'var(--ink)', border: '1px solid var(--border)' }}
              >
                {t}
                <button type="button" onClick={() => removeTag(t)}>
                  <X size={10} style={{ color: 'var(--subtle)' }} />
                </button>
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Flags */}
      <div className="flex gap-3">
        {([
          { key: 'popular', label: 'Mark as Popular', icon: <Star size={14} /> },
          { key: 'hidden', label: 'Hidden from menu', icon: <EyeOff size={14} /> },
        ] as const).map(({ key, label, icon }) => (
          <button
            key={key}
            type="button"
            onClick={() => patch({ [key]: !form[key] })}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-medium border transition-all duration-150"
            style={{
              borderColor: form[key] ? 'var(--accent)' : 'var(--border)',
              background: form[key] ? 'var(--accent)' : 'transparent',
              color: form[key] ? 'white' : 'var(--muted)',
            }}
          >
            {icon}
            {label}
          </button>
        ))}
      </div>

      {/* Actions */}
      <div className="flex gap-3 pt-2" style={{ borderTop: '1px solid var(--border)' }}>
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 py-3 rounded-2xl text-sm font-semibold transition-all duration-150"
          style={{ background: 'var(--surface-strong)', color: 'var(--muted)', border: '1px solid var(--border)' }}
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={!form.name.trim()}
          className="flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl text-sm font-semibold transition-all duration-150 hover:scale-[1.01] active:scale-[0.99] disabled:opacity-40"
          style={{ background: 'var(--accent)', color: 'white' }}
        >
          <Check size={15} />
          {isNew ? 'Add Product' : 'Save Changes'}
        </button>
      </div>
    </form>
  );
}

// ── Product Row ───────────────────────────────────────────────────────────────

function ProductRow({
  item,
  onEdit,
  onDelete,
  onToggleHidden,
  onTogglePopular,
  onTogglePaused,
}: {
  item: ManagedMenuItem;
  onEdit: () => void;
  onDelete: () => unknown;
  onToggleHidden: () => unknown;
  onTogglePopular: () => unknown;
  onTogglePaused: () => unknown;
}) {
  const [confirmDelete, setConfirmDelete] = useState(false);
  const dimmed = item.hidden || item.paused;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: dimmed ? 0.55 : 1, y: 0 }}
      exit={{ opacity: 0, height: 0, marginBottom: 0 }}
      className="flex items-center gap-3 px-4 py-3 rounded-2xl transition-all duration-200"
      style={{
        background: 'var(--surface-strong)',
        border: `1px solid ${item.paused ? 'rgba(234,88,12,0.3)' : 'var(--border)'}`,
      }}
    >
      {/* Thumbnail */}
      <div className="w-14 h-14 rounded-xl overflow-hidden flex-shrink-0 relative" style={{ background: 'var(--surface-muted)' }}>
        {item.imageUrl ? (
          <img
            src={item.imageUrl}
            alt={item.name}
            className="w-full h-full object-cover"
            onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <ImageOff size={18} style={{ color: 'var(--subtle)' }} />
          </div>
        )}
        {/* Paused overlay */}
        {item.paused && (
          <div className="absolute inset-0 flex items-center justify-center rounded-xl" style={{ background: 'rgba(0,0,0,0.45)' }}>
            <PauseCircle size={18} style={{ color: 'white' }} />
          </div>
        )}
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 flex-wrap">
          <p className="font-semibold text-sm truncate" style={{ color: dimmed ? 'var(--subtle)' : 'var(--ink)' }}>
            {item.name}
          </p>
          {item.nameVi && item.nameVi !== item.name && (
            <span className="text-xs" style={{ color: 'var(--subtle)' }}>({item.nameVi})</span>
          )}
          {item.popular && !item.paused && !item.hidden && (
            <span className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-[10px] font-semibold" style={{ background: '#fef3c7', color: '#92400e' }}>
              <Star size={8} />Popular
            </span>
          )}
          {item.paused && (
            <span className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-[10px] font-semibold" style={{ background: 'rgba(234,88,12,0.1)', color: '#ea580c' }}>
              <PauseCircle size={8} />Sold out
            </span>
          )}
          {item.hidden && (
            <span className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-[10px] font-semibold" style={{ background: 'var(--surface-muted)', color: 'var(--subtle)' }}>
              <EyeOff size={8} />Hidden
            </span>
          )}
        </div>
        <p className="text-xs mt-0.5" style={{ color: 'var(--subtle)' }}>
          {CATEGORY_LABELS[item.category]} · ${item.price.toFixed(2)} USDC
        </p>
        {item.description && (
          <p className="text-xs mt-0.5 truncate" style={{ color: 'var(--muted)' }}>{item.description}</p>
        )}
      </div>

      {/* Actions */}
      <div className="flex items-center gap-1 flex-shrink-0">
        <ActionIconBtn title={item.popular ? 'Unfeature' : 'Feature'} onClick={onTogglePopular}>
          {item.popular ? <StarOff size={13} /> : <Star size={13} />}
        </ActionIconBtn>
        {/* Pause = temporarily sold out; stays visible on menu as Unavailable */}
        <ActionIconBtn
          title={item.paused ? 'Mark available again' : 'Mark as sold out (pause)'}
          onClick={onTogglePaused}
          warn={item.paused}
        >
          {item.paused ? <PlayCircle size={13} /> : <PauseCircle size={13} />}
        </ActionIconBtn>
        {/* Hide = remove from menu entirely */}
        <ActionIconBtn title={item.hidden ? 'Show on menu' : 'Hide from menu'} onClick={onToggleHidden}>
          {item.hidden ? <Eye size={13} /> : <EyeOff size={13} />}
        </ActionIconBtn>
        <ActionIconBtn title="Edit product" onClick={onEdit}>
          <Pencil size={13} />
        </ActionIconBtn>
        {confirmDelete ? (
          <div className="flex gap-1">
            <button
              onClick={onDelete}
              className="px-2.5 py-1.5 rounded-xl text-xs font-semibold transition-all duration-150"
              style={{ background: '#ef4444', color: 'white' }}
            >
              Delete
            </button>
            <button
              onClick={() => setConfirmDelete(false)}
              className="px-2.5 py-1.5 rounded-xl text-xs font-semibold"
              style={{ background: 'var(--surface-muted)', color: 'var(--muted)' }}
            >
              No
            </button>
          </div>
        ) : (
          <ActionIconBtn title="Delete product" onClick={() => setConfirmDelete(true)} danger>
            <Trash2 size={13} />
          </ActionIconBtn>
        )}
      </div>
    </motion.div>
  );
}

function ActionIconBtn({
  children, title, onClick, danger, warn,
}: {
  children: React.ReactNode; title: string; onClick: () => void; danger?: boolean; warn?: boolean;
}) {
  return (
    <button
      type="button"
      title={title}
      onClick={onClick}
      className="w-8 h-8 rounded-xl flex items-center justify-center transition-all duration-150 hover:scale-105 active:scale-95"
      style={{
        background: danger ? 'rgba(239,68,68,0.08)' : warn ? 'rgba(234,88,12,0.1)' : 'var(--surface-muted)',
        color: danger ? '#ef4444' : warn ? '#ea580c' : 'var(--muted)',
        border: '1px solid var(--border)',
      }}
    >
      {children}
    </button>
  );
}

// ── Main ProductManager ───────────────────────────────────────────────────────

export function ProductManager() {
  const { allItems, addItem, updateItem, deleteItem, toggleHidden, togglePopular, togglePaused, writing, loading, isContractSource } = useMenu();
  const { isConnected } = useAccount();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [catFilter, setCatFilter] = useState<Category | 'all'>('all');
  const [showHidden, setShowHidden] = useState(true);

  const editingItem = editingId ? allItems.find((i) => i.id === editingId) : null;

  const filtered = allItems.filter((it) => {
    if (!showHidden && it.hidden) return false;
    if (catFilter !== 'all' && it.category !== catFilter) return false;
    const q = search.toLowerCase();
    if (!q) return true;
    return (
      it.name.toLowerCase().includes(q) ||
      (it.nameVi?.toLowerCase().includes(q) ?? false) ||
      it.description.toLowerCase().includes(q)
    );
  });

  const handleSaveNew = useCallback(
    (data: Omit<ManagedMenuItem, 'id'>) => {
      void addItem(data);
      setShowForm(false);
    },
    [addItem],
  );

  const handleSaveEdit = useCallback(
    (data: Omit<ManagedMenuItem, 'id'>) => {
      if (!editingId) return;
      void updateItem(editingId, data);
      setEditingId(null);
    },
    [editingId, updateItem],
  );

  const counts = CATEGORY_ORDER.reduce<Record<string, number>>((acc, cat) => {
    acc[cat] = allItems.filter((i) => i.category === cat).length;
    return acc;
  }, {});

  return (
    <div className="flex flex-col gap-5">

      {/* Wallet required notice */}
      {!isConnected && (
        <div
          className="flex items-center gap-2 px-4 py-3 rounded-2xl text-sm"
          style={{ background: 'rgba(150,90,50,0.08)', border: '1px solid var(--accent)', color: 'var(--accent)' }}
        >
          <DollarSign size={14} />
          <span>Connect your owner wallet to save product changes on-chain.</span>
        </div>
      )}

      {/* Not-seeded notice: contract connected but empty */}
      {!loading && isContractSource && allItems.length === 0 && (
        <div
          className="flex flex-col gap-1 px-4 py-3 rounded-2xl text-sm"
          style={{ background: 'rgba(234,88,12,0.07)', border: '1px solid #ea580c', color: '#ea580c' }}
        >
          <p className="font-semibold">Contract is empty — no products seeded yet.</p>
          <p className="text-xs" style={{ color: '#c2410c' }}>
            Call <code>seedProducts</code> from Remix or use the Staff Dashboard to add products one by one.
            See <strong>docs/seed-products.md</strong> for the batch payloads.
          </p>
        </div>
      )}

      {/* Not-contract notice: showing static fallback data */}
      {!loading && !isContractSource && (
        <div
          className="flex items-center gap-2 px-4 py-3 rounded-2xl text-sm"
          style={{ background: 'rgba(100,100,100,0.07)', border: '1px solid var(--border)', color: 'var(--muted)' }}
        >
          <EyeOff size={14} />
          <span>Showing preview data only — contract not reachable. Changes cannot be saved until the contract is available.</span>
        </div>
      )}

      {/* Writing pending banner */}
      {writing && (
        <div
          className="flex items-center gap-2 px-4 py-3 rounded-2xl text-sm"
          style={{ background: 'rgba(22,163,74,0.08)', border: '1px solid #16a34a', color: '#16a34a' }}
        >
          <Loader2 size={14} className="animate-spin" />
          <span>Transaction submitted — waiting for confirmation&hellip;</span>
        </div>
      )}

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <div className="flex items-center gap-2 flex-wrap">
          <p className="font-semibold text-sm" style={{ color: 'var(--ink)' }}>
            {allItems.length} products
            {allItems.filter((i) => i.hidden).length > 0 && (
              <span className="ml-1 text-xs" style={{ color: 'var(--subtle)' }}>
                ({allItems.filter((i) => i.hidden).length} hidden)
              </span>
            )}
          </p>
          <button
            type="button"
            onClick={() => setShowHidden((v) => !v)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs"
            style={{
              background: showHidden ? 'var(--surface-muted)' : 'var(--accent)',
              color: showHidden ? 'var(--muted)' : 'white',
              border: '1px solid var(--border)',
            }}
          >
            {showHidden ? <Eye size={11} /> : <EyeOff size={11} />}
            {showHidden ? 'Showing hidden' : 'Hidden filtered'}
          </button>
        </div>
        <button
          type="button"
          onClick={() => { setEditingId(null); setShowForm(true); }}
          disabled={writing}
          className="flex items-center gap-2 px-4 py-2.5 rounded-2xl text-sm font-semibold transition-all duration-150 hover:scale-[1.02] active:scale-[0.98] disabled:opacity-40 disabled:pointer-events-none"
          style={{ background: 'var(--accent)', color: 'white' }}
        >
          {writing ? <Loader2 size={15} className="animate-spin" /> : <Plus size={15} />}
          Add Product
        </button>
      </div>

      {/* Search + category filter */}
      <div className="flex flex-col gap-2">
        <div
          className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl"
          style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}
        >
          <Search size={14} style={{ color: 'var(--subtle)', flexShrink: 0 }} />
          <input
            type="text"
            placeholder="Search products…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 bg-transparent text-sm outline-none"
            style={{ color: 'var(--ink)' }}
          />
          {search && (
            <button onClick={() => setSearch('')} style={{ color: 'var(--subtle)' }}>
              <X size={13} />
            </button>
          )}
        </div>

        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-hide">
          <button
            onClick={() => setCatFilter('all')}
            className="flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-medium transition-all duration-150"
            style={{
              background: catFilter === 'all' ? 'var(--accent)' : 'var(--surface-strong)',
              color: catFilter === 'all' ? 'white' : 'var(--muted)',
              border: '1px solid var(--border)',
            }}
          >
            All ({allItems.length})
          </button>
          {CATEGORY_ORDER.map((cat) => (
            <button
              key={cat}
              onClick={() => setCatFilter(cat)}
              className="flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-medium transition-all duration-150"
              style={{
                background: catFilter === cat ? 'var(--accent)' : 'var(--surface-strong)',
                color: catFilter === cat ? 'white' : 'var(--muted)',
                border: '1px solid var(--border)',
              }}
            >
              {CATEGORY_LABELS_VI[cat]} ({counts[cat] ?? 0})
            </button>
          ))}
        </div>
      </div>

      {/* Stats strip */}
      <div className="grid grid-cols-4 gap-2">
        {[
          { label: 'Total',    value: allItems.length,                           icon: <LayoutGrid  size={14} /> },
          { label: 'Featured', value: allItems.filter((i) => i.popular).length,  icon: <Star        size={14} /> },
          { label: 'Sold out', value: allItems.filter((i) => i.paused).length,   icon: <PauseCircle size={14} />, warn: true },
          { label: 'Hidden',   value: allItems.filter((i) => i.hidden).length,   icon: <EyeOff      size={14} /> },
        ].map(({ label, value, icon, warn }) => (
          <div
            key={label}
            className="flex flex-col items-center gap-1 py-3 rounded-2xl"
            style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}
          >
            <span style={{ color: warn ? '#ea580c' : 'var(--accent-gold)' }}>{icon}</span>
            <span className="display text-xl font-bold tabular-nums" style={{ color: warn && value > 0 ? '#ea580c' : 'var(--ink)' }}>{value}</span>
            <span className="text-[10px] uppercase tracking-widest" style={{ color: 'var(--subtle)' }}>{label}</span>
          </div>
        ))}
      </div>

      {/* Product list */}
      <div className="flex flex-col gap-2">
        <AnimatePresence>
          {filtered.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center py-12 text-center"
            >
              <Tag size={28} style={{ color: 'var(--subtle)' }} className="mb-3" />
              <p className="font-medium" style={{ color: 'var(--ink)' }}>No products found</p>
              <p className="text-sm mt-1" style={{ color: 'var(--muted)' }}>
                Try a different search or add a new product.
              </p>
            </motion.div>
          ) : (
            filtered.map((item) => (
              <ProductRow
                key={item.id}
                item={item}
                onEdit={() => { setShowForm(false); setEditingId(item.id); }}
                onDelete={() => deleteItem(item.id)}
                onToggleHidden={() => toggleHidden(item.id)}
                onTogglePopular={() => togglePopular(item.id)}
                onTogglePaused={() => togglePaused(item.id)}
              />
            ))
          )}
        </AnimatePresence>
      </div>

      {/* Add / Edit slide-in modal */}
      <AnimatePresence>
        {(showForm || editingItem) && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4"
            style={{ background: 'rgba(44,24,16,0.6)' }}
            onClick={(e) => {
              if (e.target === e.currentTarget) {
                setShowForm(false);
                setEditingId(null);
              }
            }}
          >
            <motion.div
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 40, opacity: 0 }}
              transition={{ type: 'spring', damping: 26, stiffness: 280 }}
              className="w-full max-w-lg rounded-3xl overflow-hidden"
              style={{ background: 'var(--bg)', border: '1px solid var(--border)', maxHeight: '90dvh', overflowY: 'auto' }}
            >
              {/* Modal header */}
              <div
                className="flex items-center justify-between px-5 pt-5 pb-4"
                style={{ borderBottom: '1px solid var(--border)' }}
              >
                <div className="flex items-center gap-2">
                  {editingItem ? <Pencil size={16} style={{ color: 'var(--accent-gold)' }} /> : <Plus size={16} style={{ color: 'var(--accent-gold)' }} />}
                  <h3 className="display font-bold text-lg" style={{ color: 'var(--ink)' }}>
                    {editingItem ? `Edit "${editingItem.name}"` : 'Add New Product'}
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => { setShowForm(false); setEditingId(null); }}
                  className="w-8 h-8 rounded-full flex items-center justify-center"
                  style={{ background: 'var(--surface-muted)', color: 'var(--muted)' }}
                >
                  <X size={15} />
                </button>
              </div>

              <div className="p-5">
                <ProductForm
                  initial={editingItem ?? (blankProduct())}
                  onSave={editingItem ? handleSaveEdit : handleSaveNew}
                  onCancel={() => { setShowForm(false); setEditingId(null); }}
                  isNew={!editingItem}
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Legend */}
      <div
        className="flex flex-wrap gap-3 p-3.5 rounded-2xl text-xs"
        style={{ background: 'var(--surface-muted)', color: 'var(--subtle)', border: '1px solid var(--border)' }}
      >
        {[
          { icon: <Star size={11} />, label: 'Feature / unfeature on menu' },
          { icon: <PauseCircle size={11} />, label: 'Sold out — shown as Unavailable; re-enable anytime' },
          { icon: <EyeOff size={11} />, label: 'Hide — invisible to customers entirely' },
          { icon: <Pencil size={11} />, label: 'Edit name, price, image, description' },
          { icon: <Trash2 size={11} />, label: 'Delete permanently' },
          { icon: <DollarSign size={11} />, label: 'Changes are saved on-chain and persist permanently' },
        ].map(({ icon, label }) => (
          <span key={label} className="flex items-center gap-1">
            {icon} {label}
          </span>
        ))}
      </div>
    </div>
  );
}
