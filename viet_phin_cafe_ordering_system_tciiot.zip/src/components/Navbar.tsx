import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingCart, Menu, X, LayoutDashboard, Star } from 'lucide-react';
import { ConnectKitButton } from 'connectkit';
import { useAccount } from 'wagmi';
import { VietPhinWordmark } from './Logo';
import { useCart } from '../context/CartContext';

type View = 'home' | 'menu' | 'cart' | 'orders' | 'loyalty' | 'staff';

interface NavbarProps {
  view: View;
  onNavigate: (v: View) => void;
}

export function Navbar({ view, onNavigate }: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { itemCount } = useCart();
  const { isConnected } = useAccount();

  const links: { label: string; view: View }[] = [
    { label: 'Home', view: 'home' },
    { label: 'Menu', view: 'menu' },
    { label: 'My Orders', view: 'orders' },
    { label: 'Loyalty', view: 'loyalty' },
    { label: 'Staff', view: 'staff' },
  ];

  return (
    <header
      className="sticky top-0 z-50 w-full"
      style={{
        background: 'rgba(250, 247, 242, 0.88)',
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        borderBottom: '1px solid var(--border)',
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Logo */}
        <button
          onClick={() => onNavigate('home')}
          className="flex-shrink-0 focus:outline-none focus-visible:ring-2 focus-visible:ring-yellow-600 rounded-lg"
        >
          <VietPhinWordmark />
        </button>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-1">
          {links.map((l) => {
            const isStaff = l.view === 'staff';
            const isActive = view === l.view;
            return (
              <button
                key={l.view}
                onClick={() => onNavigate(l.view)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm transition-all duration-200"
                style={isStaff ? {
                  color: isActive ? 'var(--ink)' : 'var(--accent-gold)',
                  background: isActive ? 'var(--surface-muted)' : 'transparent',
                  border: '1px solid var(--accent-gold)',
                  fontWeight: 500,
                  borderRadius: 8,
                } : {
                  color: isActive ? 'var(--ink)' : 'var(--muted)',
                  background: isActive ? 'var(--surface-muted)' : 'transparent',
                  fontWeight: isActive ? 600 : 400,
                  border: '1px solid transparent',
                }}
              >
                {isStaff && <LayoutDashboard size={13} />}
                {l.label}
              </button>
            );
          })}

        </nav>

        {/* Right side actions */}
        <div className="flex items-center gap-2">
          {/* Cart button */}
          <button
            onClick={() => onNavigate('cart')}
            className="relative flex items-center justify-center w-10 h-10 rounded-xl transition-all duration-200 active:scale-95"
            style={{
              background: view === 'cart' ? 'var(--accent)' : 'var(--surface-muted)',
              color: view === 'cart' ? 'white' : 'var(--ink)',
            }}
            aria-label={`Cart — ${itemCount} items`}
          >
            <ShoppingCart size={18} />
            {itemCount > 0 && (
              <motion.span
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute -top-1 -right-1 w-4.5 h-4.5 min-w-[18px] min-h-[18px] flex items-center justify-center rounded-full text-xs font-bold tabular-nums"
                style={{ background: 'var(--accent-gold)', color: 'white', fontSize: '10px', padding: '0 3px' }}
              >
                {itemCount}
              </motion.span>
            )}
          </button>

          {/* Loyalty points quick badge */}
          {isConnected && (
            <button
              onClick={() => onNavigate('loyalty')}
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium transition-all duration-200"
              style={{ background: 'var(--surface-muted)', color: 'var(--accent-gold)' }}
            >
              <Star size={14} fill="currentColor" />
              Points
            </button>
          )}

          {/* Wallet */}
          <div className="hidden sm:block">
            <ConnectKitButton />
          </div>

          {/* Mobile menu toggle */}
          <button
            className="md:hidden flex items-center justify-center w-10 h-10 rounded-xl"
            style={{ background: 'var(--surface-muted)', color: 'var(--ink)' }}
            onClick={() => setMobileOpen((o) => !o)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.18 }}
            className="md:hidden border-t px-4 py-4 flex flex-col gap-1"
            style={{ borderColor: 'var(--border)', background: 'rgba(250,247,242,0.97)' }}
          >
            {links.map((l) => (
              <button
                key={l.view}
                onClick={() => { onNavigate(l.view); setMobileOpen(false); }}
                className="text-left px-3 py-3 rounded-xl text-sm font-medium"
                style={{
                  color: view === l.view ? 'var(--ink)' : 'var(--muted)',
                  background: view === l.view ? 'var(--surface-muted)' : 'transparent',
                  fontWeight: view === l.view ? 600 : 400,
                }}
              >
                {l.label}
              </button>
            ))}

            <div className="pt-2">
              <ConnectKitButton />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
