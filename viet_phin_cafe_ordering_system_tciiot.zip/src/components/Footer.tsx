import { LayoutDashboard, Coffee, MapPin, Clock } from 'lucide-react';
import { VietPhinLogo } from './Logo';

type View = 'home' | 'menu' | 'cart' | 'orders' | 'loyalty' | 'staff';

interface FooterProps {
  onNavigate: (v: View) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  return (
    <footer
      className="mt-auto"
      style={{
        background: 'linear-gradient(180deg, #2c1810 0%, #1a0e08 100%)',
        borderTop: '1px solid rgba(255,255,255,0.06)',
      }}
    >
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">

          {/* Brand */}
          <div className="flex flex-col gap-3">
            <VietPhinLogo />
            <p className="text-sm leading-relaxed" style={{ color: 'rgba(250,244,235,0.55)' }}>
              Authentic Vietnamese coffee &amp; more, brewed with love.
              Order ahead, pick up fresh.
            </p>
            <div className="flex items-center gap-1.5 text-xs" style={{ color: 'rgba(250,244,235,0.4)' }}>
              <MapPin size={12} />
              <span>123 Phố Cổ Street · Hà Nội</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs" style={{ color: 'rgba(250,244,235,0.4)' }}>
              <Clock size={12} />
              <span>Mon–Sun · 7:00 am – 9:00 pm</span>
            </div>
          </div>

          {/* Quick links */}
          <div>
            <p
              className="text-[10px] font-bold uppercase tracking-widest mb-3"
              style={{ color: 'rgba(250,244,235,0.35)', letterSpacing: '0.14em' }}
            >
              Explore
            </p>
            <div className="flex flex-col gap-1.5">
              {([
                { label: 'Home', view: 'home' },
                { label: 'Full Menu', view: 'menu' },
                { label: 'My Orders', view: 'orders' },
                { label: 'Loyalty Rewards', view: 'loyalty' },
              ] as const).map(({ label, view }) => (
                <button
                  key={view}
                  onClick={() => onNavigate(view)}
                  className="text-left text-sm transition-all duration-150 hover:translate-x-0.5"
                  style={{ color: 'rgba(250,244,235,0.65)' }}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Staff portal */}
          <div>
            <p
              className="text-[10px] font-bold uppercase tracking-widest mb-3"
              style={{ color: 'rgba(250,244,235,0.35)', letterSpacing: '0.14em' }}
            >
              For Staff
            </p>
            <button
              onClick={() => onNavigate('staff')}
              className="flex items-center gap-2.5 px-4 py-3 rounded-2xl text-sm font-semibold w-full transition-all duration-200 hover:scale-[1.02] active:scale-95"
              style={{
                background: 'rgba(184,134,11,0.15)',
                border: '1px solid rgba(184,134,11,0.35)',
                color: '#d4a520',
              }}
            >
              <LayoutDashboard size={16} />
              Staff Dashboard
            </button>
            <p className="text-[11px] mt-2.5 leading-relaxed" style={{ color: 'rgba(250,244,235,0.35)' }}>
              Manage orders, update status, and configure the menu.
            </p>
            <p className="text-[10px] mt-2 font-mono" style={{ color: 'rgba(250,244,235,0.25)' }}>
              Password: vietphin2026
            </p>
          </div>
        </div>

        {/* Bottom bar */}
        <div
          className="flex flex-col sm:flex-row items-center justify-between gap-2 mt-8 pt-6"
          style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}
        >
          <div className="flex items-center gap-1.5 text-xs" style={{ color: 'rgba(250,244,235,0.3)' }}>
            <Coffee size={11} />
            <span>© 2026 Viet Phin. Built with love on Arc Testnet.</span>
          </div>
          <p className="text-[11px]" style={{ color: 'rgba(250,244,235,0.2)' }}>
            USDC payments powered by Circle
          </p>
        </div>
      </div>
    </footer>
  );
}
