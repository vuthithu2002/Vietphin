import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingCart, Minus, Plus, Trash2, Clock, ArrowRight } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { CheckoutFlow } from './CheckoutFlow';

/** Returns an ISO datetime-local string 15 minutes from now */
function getMinPickupTime(): string {
  const d = new Date(Date.now() + 15 * 60 * 1000);
  d.setSeconds(0, 0);
  return d.toISOString().slice(0, 16);
}

interface CartPageProps {
  onNavigate: (v: 'menu' | 'orders') => void;
}

export function CartPage({ onNavigate }: CartPageProps) {
  const { items, subtotal, itemCount, removeItem, updateQty, pickupTime, setPickupTime, notes, setNotes } = useCart();
  const [showCheckout, setShowCheckout] = useState(false);

  const minPickupTime = getMinPickupTime();

  if (showCheckout) {
    return (
      <CheckoutFlow
        onBack={() => setShowCheckout(false)}
        onSuccess={() => { setShowCheckout(false); onNavigate('orders'); }}
      />
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
      <div className="mb-8">
        <p className="text-xs font-semibold uppercase tracking-widest mb-1" style={{ color: 'var(--accent-gold)', letterSpacing: '0.12em' }}>
          Your Cart
        </p>
        <h1 className="display text-3xl font-bold" style={{ color: 'var(--ink)', letterSpacing: '-0.03em' }}>
          {itemCount === 0 ? 'Cart is empty' : `${itemCount} item${itemCount !== 1 ? 's' : ''}`}
        </h1>
      </div>

      {items.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div
            className="w-20 h-20 rounded-3xl flex items-center justify-center mb-5"
            style={{ background: 'var(--surface-muted)' }}
          >
            <ShoppingCart size={36} style={{ color: 'var(--subtle)' }} />
          </div>
          <p className="display text-xl font-semibold mb-2" style={{ color: 'var(--ink)' }}>
            Nothing here yet
          </p>
          <p className="text-sm mb-6" style={{ color: 'var(--muted)' }}>
            Browse our menu and add your favourite drinks
          </p>
          <button
            onClick={() => onNavigate('menu')}
            className="flex items-center gap-2 px-6 py-3 rounded-2xl font-semibold text-sm transition-all duration-200 hover:scale-105 active:scale-95"
            style={{ background: 'var(--accent)', color: 'white' }}
          >
            Browse Menu <ArrowRight size={16} />
          </button>
        </div>
      ) : (
        <div className="flex flex-col gap-6">
          {/* Items list */}
          <div
            className="rounded-3xl overflow-hidden"
            style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}
          >
            <AnimatePresence mode="popLayout">
              {items.map((item, idx) => (
                <motion.div
                  key={`${item.menuItemId}|${item.size}|${item.milk}|${item.sugar}|${item.ice}`}
                  layout
                  initial={{ opacity: 0, x: -16 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 16, height: 0 }}
                  transition={{ duration: 0.2 }}
                  className="flex items-center gap-4 px-5 py-4"
                  style={{ borderTop: idx > 0 ? '1px solid var(--border)' : 'none' }}
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm truncate" style={{ color: 'var(--ink)' }}>
                      {item.name}
                    </p>
                    <p className="text-xs mt-0.5 truncate" style={{ color: 'var(--muted)' }}>
                      {[item.size, item.milk, item.sugar, item.ice].filter(Boolean).join(' · ')}
                    </p>
                  </div>

                  {/* Qty control */}
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button
                      onClick={() => updateQty(item.menuItemId, item.size, item.milk, item.sugar, item.ice, item.quantity - 1)}
                      className="w-7 h-7 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110 active:scale-95"
                      style={{ background: 'var(--surface-muted)', color: 'var(--ink)' }}
                    >
                      {item.quantity === 1 ? <Trash2 size={12} /> : <Minus size={12} />}
                    </button>
                    <span className="w-5 text-center text-sm font-semibold tabular-nums" style={{ color: 'var(--ink)' }}>
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateQty(item.menuItemId, item.size, item.milk, item.sugar, item.ice, item.quantity + 1)}
                      className="w-7 h-7 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110 active:scale-95"
                      style={{ background: 'var(--accent)', color: 'white' }}
                    >
                      <Plus size={12} />
                    </button>
                  </div>

                  {/* Price */}
                  <span
                    className="tabular-nums text-sm font-bold text-right flex-shrink-0"
                    style={{ color: 'var(--ink)', minWidth: 64 }}
                  >
                    ${(item.price * item.quantity).toFixed(2)}
                  </span>

                  {/* Remove */}
                  <button
                    onClick={() => removeItem(item.menuItemId, item.size, item.milk, item.sugar, item.ice)}
                    className="flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center transition-all duration-200 hover:bg-red-50"
                    style={{ color: 'var(--danger)' }}
                  >
                    <Trash2 size={14} />
                  </button>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          {/* Pickup time */}
          <div
            className="rounded-3xl p-5"
            style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}
          >
            <div className="flex items-center gap-2 mb-3">
              <Clock size={16} style={{ color: 'var(--accent-gold)' }} />
              <h3 className="font-semibold text-sm" style={{ color: 'var(--ink)' }}>
                Pickup Time
              </h3>
              <span className="text-xs font-medium px-2 py-0.5 rounded-full" style={{ background: 'var(--surface-muted)', color: 'var(--muted)' }}>
                Required
              </span>
            </div>
            <input
              type="datetime-local"
              min={minPickupTime}
              value={pickupTime}
              onChange={(e) => setPickupTime(e.target.value)}
              className="w-full px-4 py-3 rounded-2xl text-sm outline-none transition-all duration-200 focus:ring-2"
              style={{
                background: 'var(--surface-muted)',
                border: '1.5px solid var(--border)',
                color: 'var(--ink)',
              }}
            />
            <p className="text-xs mt-2" style={{ color: 'var(--subtle)' }}>
              Minimum 15 minutes from now
            </p>
          </div>

          {/* Notes */}
          <div
            className="rounded-3xl p-5"
            style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}
          >
            <h3 className="font-semibold text-sm mb-3" style={{ color: 'var(--ink)' }}>
              Special Instructions
              <span className="font-normal ml-1" style={{ color: 'var(--subtle)' }}>(optional)</span>
            </h3>
            <textarea
              placeholder="Allergies, extra ice, extra strong…"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              className="w-full px-4 py-3 rounded-2xl text-sm outline-none resize-none transition-all duration-200"
              style={{
                background: 'var(--surface-muted)',
                border: '1.5px solid var(--border)',
                color: 'var(--ink)',
              }}
            />
          </div>

          {/* Order summary + CTA */}
          <div
            className="rounded-3xl p-5"
            style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}
          >
            <div className="flex flex-col gap-2 mb-5">
              <div className="flex justify-between text-sm" style={{ color: 'var(--muted)' }}>
                <span>Subtotal ({itemCount} items)</span>
                <span className="tabular-nums">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm" style={{ color: 'var(--muted)' }}>
                <span>Service fee</span>
                <span className="text-xs" style={{ color: 'var(--success)' }}>Free</span>
              </div>
              <div
                className="flex justify-between font-bold text-base mt-1 pt-3"
                style={{ color: 'var(--ink)', borderTop: '1px solid var(--border)' }}
              >
                <span>Total</span>
                <span className="tabular-nums">${subtotal.toFixed(2)} USDC</span>
              </div>
            </div>

            <button
              onClick={() => setShowCheckout(true)}
              disabled={!pickupTime}
              className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl font-semibold text-base transition-all duration-200 hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50 disabled:cursor-not-allowed"
              style={{ background: 'var(--accent)', color: 'white' }}
            >
              Proceed to Payment
              <ArrowRight size={18} />
            </button>
            {!pickupTime && (
              <p className="text-xs text-center mt-2" style={{ color: 'var(--danger)' }}>
                Please select a pickup time to continue
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
