import { motion } from 'framer-motion';
import { ArrowRight, Star, Clock, Leaf } from 'lucide-react';
import { FEATURED_IDS, CATEGORY_ORDER, CATEGORY_LABELS, CATEGORY_LABELS_VI } from '../data/menuData';
import { useMenu } from '../context/MenuContext';
import { MenuItemCard } from './MenuItemCard';
import type { CartItem } from '../types/order';
import { VietPhinLogo } from './Logo';

interface HomePageProps {
  onNavigate: (v: 'menu' | 'cart') => void;
  onAddToCart: (item: CartItem) => void;
}

export function HomePage({ onNavigate, onAddToCart }: HomePageProps) {
  const { visibleItems } = useMenu();
  // Featured: try the curated IDs first, fill with popular items if some are hidden
  const featuredById = FEATURED_IDS.map((id) => visibleItems.find((m) => m.id === id)).filter(Boolean);
  const popular = visibleItems.filter((m) => m.popular && !FEATURED_IDS.includes(m.id));
  const featured = [...featuredById, ...popular].slice(0, 6) as typeof visibleItems;

  return (
    <div className="min-h-dvh">
      {/* Hero */}
      <section
        className="relative overflow-hidden"
        style={{ background: 'linear-gradient(135deg, #2c1810 0%, #3d1f0a 50%, #5c3317 100%)' }}
      >
        {/* Decorative circles */}
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage:
              'radial-gradient(circle at 20% 50%, #b8860b 0%, transparent 50%), radial-gradient(circle at 80% 20%, #d4a520 0%, transparent 40%)',
          }}
        />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-16 md:py-24">
          <div className="flex flex-col md:flex-row items-center gap-12">
            {/* Text */}
            <motion.div
              className="flex-1 text-center md:text-left"
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full mb-6 text-xs font-semibold tracking-widest uppercase"
                style={{ background: 'rgba(184,134,11,0.2)', color: '#d4a520', letterSpacing: '0.12em' }}
              >
                <Star size={12} fill="currentColor" />
                Authentic Vietnamese Coffee
              </div>

              <h1
                className="display text-4xl md:text-5xl lg:text-6xl font-bold mb-5"
                style={{ color: '#faf4eb', letterSpacing: '-0.03em', lineHeight: 1.1 }}
              >
                Every cup tells<br />
                <span style={{ color: '#d4a520' }}>a story</span>
              </h1>

              <p className="text-base md:text-lg mb-8 max-w-lg" style={{ color: 'rgba(250,244,235,0.72)', lineHeight: 1.65 }}>
                From the classic <em>cà phê sữa đá</em> to silky egg coffee —
                brewed through a phin, paid with USDC.
              </p>

              <div className="flex flex-col sm:flex-row gap-3 justify-center md:justify-start">
                <button
                  onClick={() => onNavigate('menu')}
                  className="flex items-center justify-center gap-2 px-7 py-3.5 rounded-2xl text-base font-semibold transition-all duration-200 hover:scale-105 active:scale-95"
                  style={{ background: '#d4a520', color: '#2c1810' }}
                >
                  Browse Menu
                  <ArrowRight size={18} />
                </button>
                <button
                  onClick={() => onNavigate('menu')}
                  className="flex items-center justify-center gap-2 px-7 py-3.5 rounded-2xl text-base font-medium transition-all duration-200 hover:bg-white/10"
                  style={{ border: '1.5px solid rgba(250,244,235,0.3)', color: '#faf4eb' }}
                >
                  See today's specials
                </button>
              </div>
            </motion.div>

            {/* Hero visual */}
            <motion.div
              className="flex-shrink-0"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.7, delay: 0.15 }}
            >
              <div
                className="relative w-48 h-48 md:w-64 md:h-64 rounded-full flex items-center justify-center"
                style={{ background: 'rgba(184,134,11,0.15)', border: '2px solid rgba(212,165,32,0.3)' }}
              >
                <VietPhinLogo size={120} />
                {/* Floating badges */}
                <motion.div
                  animate={{ y: [-4, 4, -4] }}
                  transition={{ repeat: Infinity, duration: 3, ease: 'easeInOut' }}
                  className="absolute -top-3 -right-3 px-3 py-1.5 rounded-full text-xs font-bold"
                  style={{ background: '#d4a520', color: '#2c1810' }}
                >
                  Phin Brewed
                </motion.div>
                <motion.div
                  animate={{ y: [4, -4, 4] }}
                  transition={{ repeat: Infinity, duration: 3.5, ease: 'easeInOut' }}
                  className="absolute -bottom-3 -left-4 px-3 py-1.5 rounded-full text-xs font-bold"
                  style={{ background: 'rgba(250,244,235,0.1)', border: '1px solid rgba(212,165,32,0.4)', color: '#d4a520' }}
                >
                  Pay with USDC
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Perks strip */}
      <section style={{ background: 'var(--surface-muted)', borderBottom: '1px solid var(--border)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-5">
          <div className="flex flex-wrap gap-4 justify-center md:justify-between">
            {[
              { icon: <Clock size={16} />, text: 'Pre-order & skip the line' },
              { icon: <Star size={16} />, text: 'Earn loyalty points on every order' },
              { icon: <Leaf size={16} />, text: 'Single-origin Vietnamese beans' },
            ].map((perk) => (
              <div key={perk.text} className="flex items-center gap-2 text-sm font-medium" style={{ color: 'var(--muted)' }}>
                <span style={{ color: 'var(--accent-gold)' }}>{perk.icon}</span>
                {perk.text}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Category quick-links */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pt-12 pb-4">
        <p className="text-xs font-semibold uppercase tracking-widest mb-6 text-center" style={{ color: 'var(--subtle)', letterSpacing: '0.12em' }}>
          Explore our menu
        </p>
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
          {CATEGORY_ORDER.map((cat, i) => (
            <motion.button
              key={cat}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, delay: i * 0.05 }}
              onClick={() => onNavigate('menu')}
              className="flex flex-col items-center gap-1.5 p-3 rounded-2xl transition-all duration-200 hover:scale-105 active:scale-95"
              style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}
            >
              <span className="text-lg" aria-hidden="true">
                {['☕', '🧋', '🍵', '🥐', '🥖', '🍮'][i]}
              </span>
              <span className="text-xs font-semibold text-center leading-tight" style={{ color: 'var(--ink)' }}>
                {CATEGORY_LABELS_VI[cat]}
              </span>
              <span className="text-[10px] text-center" style={{ color: 'var(--subtle)' }}>
                {CATEGORY_LABELS[cat]}
              </span>
            </motion.button>
          ))}
        </div>
      </section>

      {/* Featured */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-14">
        <div className="flex items-end justify-between mb-8">
          <div>
            <p className="text-xs font-semibold uppercase tracking-widest mb-1" style={{ color: 'var(--accent-gold)', letterSpacing: '0.12em' }}>
              Our Favourites
            </p>
            <h2 className="display text-2xl md:text-3xl font-bold" style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}>
              Staff Picks
            </h2>
          </div>
          <button
            onClick={() => onNavigate('menu')}
            className="flex items-center gap-1.5 text-sm font-medium transition-colors duration-200"
            style={{ color: 'var(--accent-gold)' }}
          >
            Full menu <ArrowRight size={14} />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {featured.slice(0, 6).map((item, idx) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: idx * 0.07 }}
            >
              <MenuItemCard item={item} onAddToCart={onAddToCart} />
            </motion.div>
          ))}
        </div>
      </section>

      {/* Promotion banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pb-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="rounded-3xl p-8 md:p-12 relative overflow-hidden"
          style={{ background: 'linear-gradient(135deg, #2c1810 0%, #5c3317 100%)' }}
        >
          <div
            className="absolute inset-0 opacity-10"
            style={{
              backgroundImage: 'radial-gradient(circle at 80% 50%, #d4a520 0%, transparent 60%)',
            }}
          />
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: '#d4a520', letterSpacing: '0.12em' }}>
                Loyalty Program
              </p>
              <h3 className="display text-2xl md:text-3xl font-bold mb-2" style={{ color: '#faf4eb', letterSpacing: '-0.02em' }}>
                Earn 1 point per USDC spent
              </h3>
              <p className="text-sm" style={{ color: 'rgba(250,244,235,0.65)' }}>
                Redeem your points for free drinks and exclusive discounts. Connect your wallet to start earning.
              </p>
            </div>
            <button
              onClick={() => onNavigate('menu')}
              className="flex-shrink-0 flex items-center gap-2 px-7 py-3.5 rounded-2xl text-sm font-semibold transition-all duration-200 hover:scale-105 active:scale-95"
              style={{ background: '#d4a520', color: '#2c1810' }}
            >
              <Star size={16} fill="currentColor" />
              Order now
            </button>
          </div>
        </motion.div>
      </section>
    </div>
  );
}
