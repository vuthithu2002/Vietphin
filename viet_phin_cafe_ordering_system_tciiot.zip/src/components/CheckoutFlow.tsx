import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Check, AlertCircle, Wallet, Clock, Star, Loader2 } from 'lucide-react';
import { useAccount, useWriteContract, useWaitForTransactionReceipt, useSwitchChain, useReadContract } from 'wagmi';
import { ConnectKitButton } from 'connectkit';
import { erc20Abi, keccak256, toBytes, parseEventLogs, createPublicClient, http } from 'viem';
import { arcTestnet, arc } from 'viem/chains';
import { toast } from 'sonner';
import { useCart } from '../context/CartContext';
import {
  ARC_TESTNET_CHAIN_ID,
  ARC_MAINNET_CHAIN_ID,
  USDC_ADDRESS,
  VIETPHIN_ABI,
  getVietPhinAddress,
  isSupportedChain,
  usdcDollarsToRaw,
  parseOnchainError,
} from '../lib/contract';
import { buildTxExplorerUrl } from '@/onchain-facts';
import type { PlacedOrder } from '../types/order';

type Step = 'review' | 'approve' | 'pay' | 'success';

interface CheckoutFlowProps {
  onBack: () => void;
  onSuccess: () => void;
}

/**
 * Safely parse a datetime-local string ("YYYY-MM-DDTHH:MM") to a Unix
 * timestamp in seconds (bigint), or return null if invalid / in the past.
 *
 * datetime-local values have NO timezone indicator — they are treated as
 * local time by browsers. We append ":00" to make them parseable everywhere,
 * then verify the result is a real future timestamp before converting.
 */
function parsePickupTimestamp(pickupTime: string): bigint | null {
  if (!pickupTime) return null;
  // Normalise: some pickers give "YYYY-MM-DDTHH:MM", others "YYYY-MM-DDTHH:MM:SS"
  const normalised = pickupTime.length === 16 ? `${pickupTime}:00` : pickupTime;
  const ms = new Date(normalised).getTime();
  if (!Number.isFinite(ms) || ms <= Date.now()) return null;
  return BigInt(Math.floor(ms / 1000));
}

export function CheckoutFlow({ onBack, onSuccess }: CheckoutFlowProps) {
  const [step, setStep] = useState<Step>('review');
  const [txHash, setTxHash] = useState<string | null>(null);
  const [orderCode, setOrderCode] = useState<string | null>(null);
  // Local error for pickup-time validation failures (separate from wallet errors)
  const [pickupError, setPickupError] = useState<string | null>(null);

  const { items, subtotal, pickupTime, notes, clearCart, addPlacedOrder, placedOrders } = useCart();
  const { address, chainId, isConnected } = useAccount();
  const placedOrderIdRef = useRef<string | null>(null);
  const { switchChain, isPending: isSwitching } = useSwitchChain();

  const contractAddress = getVietPhinAddress(chainId);
  const isWrongChain = isConnected && !isSupportedChain(chainId);
  const isMainnet = chainId === ARC_MAINNET_CHAIN_ID;
  const activeChainId = isMainnet ? ARC_MAINNET_CHAIN_ID : ARC_TESTNET_CHAIN_ID;

  // Compute these safely — never call BigInt at render time
  const totalRaw = usdcDollarsToRaw(subtotal);
  const pickupTs = parsePickupTimestamp(pickupTime); // null if invalid/past
  const pickupValid = pickupTs !== null;

  // Read current USDC allowance
  const { data: allowance, refetch: refetchAllowance } = useReadContract({
    address: USDC_ADDRESS,
    abi: erc20Abi,
    functionName: 'allowance',
    args: [
      address ?? '0x0000000000000000000000000000000000000000',
      contractAddress ?? '0x0000000000000000000000000000000000000001',
    ],
    chainId: activeChainId,
    query: { enabled: Boolean(address && contractAddress) },
  });

  // Approve USDC
  const {
    writeContract: approveUsdc,
    data: approveTxHash,
    isPending: isApprovePending,
    error: approveError,
    reset: resetApprove,
  } = useWriteContract();

  const { isLoading: isApproveConfirming, isSuccess: isApproveSuccess } =
    useWaitForTransactionReceipt({ hash: approveTxHash });

  // Place order
  const {
    writeContract: placeOrder,
    data: placeTxHash,
    isPending: isPlacePending,
    error: placeError,
    reset: resetPlace,
  } = useWriteContract();

  const { isLoading: isPlaceConfirming, isSuccess: isPlaceSuccess, data: placeReceipt } =
    useWaitForTransactionReceipt({ hash: placeTxHash });

  // Refs to prevent double-firing side-effects for a given tx
  const approveHandled = useRef(false);
  const placeHandled = useRef(false);

  // After approve confirmed → advance to pay step
  useEffect(() => {
    if (isApproveSuccess && !approveHandled.current) {
      approveHandled.current = true;
      void refetchAllowance();
      setStep('pay');
    }
    if (!isApproveSuccess) approveHandled.current = false;
  }, [isApproveSuccess, refetchAllowance]);

  // After order confirmed → success
  useEffect(() => {
    if (isPlaceSuccess && placeTxHash && !placeHandled.current) {
      placeHandled.current = true;
      setTxHash(placeTxHash);
      const now = Date.now();
      const newOrderId = `vp-${now}-${Math.random().toString(36).slice(2, 7)}`;
      placedOrderIdRef.current = newOrderId;

      // ── Extract on-chain order ID ──────────────────────────────────────────
      // Primary: parse the OrderPlaced event from the receipt logs.
      // Fallback: read orderCount() from the contract — the last placed order
      //           always equals orderCount at confirmation time.
      async function resolveOnchainId(): Promise<number | undefined> {
        // Try event logs first (instantaneous, no extra RPC)
        if (placeReceipt?.logs?.length) {
          try {
            const parsed = parseEventLogs({ abi: VIETPHIN_ABI, logs: placeReceipt.logs });
            const placed = parsed.find((e) => e.eventName === 'OrderPlaced');
            if (placed && 'orderId' in placed.args) {
              return Number(placed.args.orderId);
            }
          } catch { /* fall through to RPC fallback */ }
        }
        // Fallback: read orderCount from contract (1-indexed; last ID = count)
        const addr = getVietPhinAddress(chainId);
        if (!addr) return undefined;
        try {
          const viemChain = chainId === ARC_MAINNET_CHAIN_ID ? arc : arcTestnet;
          const client = createPublicClient({
            chain: viemChain,
            transport: http(viemChain.rpcUrls.default.http[0]),
          });
          const count = await client.readContract({
            address: addr,
            abi: VIETPHIN_ABI,
            functionName: 'orderCount',
          });
          return Number(count);
        } catch { return undefined; }
      }

      const capturedItems   = [...items];
      const capturedSubtotal = subtotal;
      const capturedPickup  = pickupTime;
      const capturedAddress = address ?? '';
      const capturedTxHash  = placeTxHash;

      void (async () => {
        const onchainOrderId = await resolveOnchainId();

        const newOrder: PlacedOrder = {
          orderId: newOrderId,
          orderCode: '',        // server assigns VP-YYMMDD-NNNN
          txHash: capturedTxHash,
          items: capturedItems,
          totalUsdc: capturedSubtotal,
          pickupTime: capturedPickup,
          status: 'Received',
          placedAt: now,
          customer: capturedAddress,
          onchainOrderId,
        };
        void addPlacedOrder(newOrder);
        clearCart();
        setStep('success');
        toast.success('Order placed successfully!');

        if (!onchainOrderId) {
          console.warn('[checkout] onchainOrderId not resolved — Complete Order requires owner to set it manually');
        }
      })();
    }
    if (!isPlaceSuccess) placeHandled.current = false;
  }, [isPlaceSuccess, placeTxHash, placeReceipt, items, subtotal, pickupTime, address, addPlacedOrder, clearCart]);

  // Watch for the server-assigned orderCode to arrive in context
  useEffect(() => {
    if (!placedOrderIdRef.current) return;
    const order = placedOrders.find((o) => o.orderId === placedOrderIdRef.current);
    if (order?.orderCode) setOrderCode(order.orderCode);
  }, [placedOrders]);

  // Wallet / contract errors
  const displayError =
    (approveError ? parseOnchainError(approveError) : null) ??
    (placeError ? parseOnchainError(placeError) : null);

  const needsApproval = !allowance || allowance < totalRaw;
  const hasContract = Boolean(contractAddress);

  // ── Approve handler ───────────────────────────────────────────────────────

  function handleApprove() {
    if (!contractAddress || !address) return;
    resetApprove();
    approveUsdc({
      address: USDC_ADDRESS,
      abi: erc20Abi,
      functionName: 'approve',
      args: [contractAddress, totalRaw],
    });
  }

  // ── Place order handler ───────────────────────────────────────────────────
  // pickupTs is computed here, not at render time, so BigInt never sees NaN.

  function handlePlaceOrder() {
    if (!contractAddress || !address) return;

    // Re-validate the pickup time right before submission
    const ts = parsePickupTimestamp(pickupTime);
    if (!ts) {
      setPickupError('Pickup time is invalid or in the past. Please go back and select a future time.');
      return;
    }

    setPickupError(null);
    resetPlace();

    const itemsJson = JSON.stringify(
      items.map((i) => ({ id: i.menuItemId, qty: i.quantity, price: i.price, notes: i.notes })),
    );
    const itemsHash = keccak256(toBytes(itemsJson));

    placeOrder({
      address: contractAddress,
      abi: VIETPHIN_ABI,
      functionName: 'placeOrder',
      args: [totalRaw, ts, itemsHash],
    });
  }

  // ── Formatted values ──────────────────────────────────────────────────────

  const pickupFormatted = pickupValid
    ? new Date(pickupTime.length === 16 ? `${pickupTime}:00` : pickupTime).toLocaleString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      })
    : 'Not set';

  const loyaltyPointsEarned = Math.floor(subtotal);

  // ── Render ────────────────────────────────────────────────────────────────

  return (
    <div className="max-w-md mx-auto px-4 sm:px-6 py-8">
      {/* Back button */}
      {step !== 'success' && (
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-sm font-medium mb-6 transition-colors"
          style={{ color: 'var(--muted)' }}
        >
          <ArrowLeft size={16} />
          Back to cart
        </button>
      )}

      <div className="mb-6">
        <p
          className="text-xs font-semibold uppercase tracking-widest mb-1"
          style={{ color: 'var(--accent-gold)', letterSpacing: '0.12em' }}
        >
          {step === 'success' ? 'Order Confirmed' : 'Checkout'}
        </p>
        <h1
          className="display text-3xl font-bold"
          style={{ color: 'var(--ink)', letterSpacing: '-0.03em' }}
        >
          {step === 'review' && 'Review your order'}
          {step === 'approve' && 'Approve USDC'}
          {step === 'pay' && 'Pay with USDC'}
          {step === 'success' && "You're all set!"}
        </h1>
      </div>

      <AnimatePresence mode="wait">
        {/* ── REVIEW ── */}
        {step === 'review' && (
          <motion.div
            key="review"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="flex flex-col gap-5"
          >
            {/* Order items */}
            <div
              className="rounded-3xl overflow-hidden"
              style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}
            >
              {items.map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-3 px-5 py-3.5"
                  style={{ borderTop: idx > 0 ? '1px solid var(--border)' : 'none' }}
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate" style={{ color: 'var(--ink)' }}>
                      {item.quantity > 1 && <span className="font-bold mr-1">{item.quantity}×</span>}
                      {item.name}
                    </p>
                    <p className="text-xs" style={{ color: 'var(--muted)' }}>
                      {[item.size, item.milk, item.sugar, item.ice].filter(Boolean).join(' · ')}
                    </p>
                  </div>
                  <span className="tabular-nums text-sm font-semibold" style={{ color: 'var(--ink)' }}>
                    ${(item.price * item.quantity).toFixed(2)}
                  </span>
                </div>
              ))}
            </div>

            {/* Pickup time */}
            <div
              className="flex items-center gap-3 px-5 py-4 rounded-2xl"
              style={{
                background: pickupValid ? 'var(--surface-muted)' : 'rgba(178,43,43,0.06)',
                border: pickupValid ? 'none' : '1px solid rgba(178,43,43,0.25)',
              }}
            >
              <Clock size={16} style={{ color: pickupValid ? 'var(--accent-gold)' : 'var(--danger)' }} />
              <div>
                <p className="text-xs font-medium" style={{ color: 'var(--subtle)' }}>Pickup time</p>
                <p
                  className="text-sm font-semibold"
                  style={{ color: pickupValid ? 'var(--ink)' : 'var(--danger)' }}
                >
                  {pickupFormatted}
                </p>
                {!pickupValid && (
                  <p className="text-xs mt-0.5" style={{ color: 'var(--danger)' }}>
                    Please go back and select a valid future time
                  </p>
                )}
              </div>
            </div>

            {notes && (
              <div
                className="px-4 py-3 rounded-2xl text-sm"
                style={{ background: 'var(--surface-muted)', color: 'var(--muted)' }}
              >
                <span className="font-medium" style={{ color: 'var(--ink)' }}>Notes: </span>
                {notes}
              </div>
            )}

            {/* Totals */}
            <div
              className="flex flex-col gap-2 p-5 rounded-3xl"
              style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}
            >
              <div className="flex justify-between text-sm" style={{ color: 'var(--muted)' }}>
                <span>Subtotal</span>
                <span className="tabular-nums">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm" style={{ color: 'var(--success)' }}>
                <span className="flex items-center gap-1">
                  <Star size={12} fill="currentColor" />
                  Loyalty points earned
                </span>
                <span className="tabular-nums font-medium">+{loyaltyPointsEarned} pts</span>
              </div>
              <div
                className="flex justify-between font-bold pt-2 mt-1"
                style={{ color: 'var(--ink)', borderTop: '1px solid var(--border)' }}
              >
                <span>Total</span>
                <span className="tabular-nums">${subtotal.toFixed(2)} USDC</span>
              </div>
            </div>

            {/* Not connected */}
            {!isConnected && (
              <div
                className="flex flex-col items-center gap-3 p-5 rounded-3xl text-center"
                style={{ background: 'var(--surface-muted)' }}
              >
                <Wallet size={28} style={{ color: 'var(--muted)' }} />
                <p className="text-sm font-medium" style={{ color: 'var(--ink)' }}>
                  Connect your wallet to pay with USDC
                </p>
                <ConnectKitButton />
              </div>
            )}

            {isWrongChain && (
              <div
                className="flex items-start gap-3 p-4 rounded-2xl"
                style={{ background: '#fff7ed', border: '1px solid #fed7aa' }}
              >
                <AlertCircle size={18} style={{ color: '#ea580c', flexShrink: 0 }} />
                <div className="flex-1">
                  <p className="text-sm font-medium" style={{ color: '#9a3412' }}>
                    Please switch to Arc Mainnet or Arc Testnet
                  </p>
                  <div className="flex gap-2 mt-2">
                    <button
                      onClick={() => switchChain({ chainId: ARC_MAINNET_CHAIN_ID })}
                      disabled={isSwitching}
                      className="px-3 py-1.5 rounded-xl text-xs font-semibold"
                      style={{ background: '#4a2c1a', color: 'white' }}
                    >
                      {isSwitching ? '…' : 'Arc Mainnet'}
                    </button>
                    <button
                      onClick={() => switchChain({ chainId: ARC_TESTNET_CHAIN_ID })}
                      disabled={isSwitching}
                      className="px-3 py-1.5 rounded-xl text-xs font-semibold"
                      style={{ background: '#ea580c', color: 'white' }}
                    >
                      {isSwitching ? '…' : 'Arc Testnet'}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {!hasContract && isConnected && (
              <div
                className="flex items-center gap-3 p-4 rounded-2xl"
                style={{ background: '#fff7ed', border: '1px solid #fed7aa' }}
              >
                <AlertCircle size={18} style={{ color: '#ea580c' }} />
                <p className="text-sm" style={{ color: '#9a3412' }}>
                  Contract not yet deployed. Set VITE_VIETPHIN_ADDRESS in .env after deployment.
                </p>
              </div>
            )}

            <button
              onClick={() => {
                if (!pickupValid) return; // button is disabled anyway
                if (needsApproval) {
                  setStep('approve');
                } else {
                  setStep('pay');
                }
              }}
              disabled={!isConnected || isWrongChain || !hasContract || !pickupValid}
              className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl font-semibold text-base transition-all duration-200 hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50 disabled:cursor-not-allowed"
              style={{ background: 'var(--accent)', color: 'white' }}
            >
              Continue to Payment
            </button>

            {!pickupValid && isConnected && (
              <p className="text-xs text-center" style={{ color: 'var(--danger)' }}>
                Please go back and select a valid pickup time (at least 15 min from now)
              </p>
            )}
          </motion.div>
        )}

        {/* ── APPROVE ── */}
        {step === 'approve' && (
          <motion.div
            key="approve"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="flex flex-col gap-5"
          >
            <div
              className="p-6 rounded-3xl text-center flex flex-col items-center gap-4"
              style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}
            >
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center"
                style={{ background: 'var(--surface-muted)' }}
              >
                <Wallet size={28} style={{ color: 'var(--accent-gold)' }} />
              </div>
              <div>
                <h3 className="font-semibold text-base mb-1" style={{ color: 'var(--ink)' }}>
                  Approve USDC Spending
                </h3>
                <p className="text-sm" style={{ color: 'var(--muted)' }}>
                  Allow the Viet Phin contract to spend{' '}
                  <strong>${subtotal.toFixed(2)} USDC</strong> from your wallet. This is a
                  one-time approval for this order.
                </p>
              </div>
            </div>

            {displayError && (
              <div
                className="flex items-start gap-3 p-4 rounded-2xl"
                style={{ background: '#fef2f2', border: '1px solid #fecaca' }}
              >
                <AlertCircle size={16} className="flex-shrink-0 mt-0.5" style={{ color: 'var(--danger)' }} />
                <p className="text-sm" style={{ color: '#991b1b' }}>{displayError}</p>
              </div>
            )}

            <button
              onClick={handleApprove}
              disabled={isApprovePending || isApproveConfirming}
              className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl font-semibold text-base transition-all duration-200 hover:scale-[1.01] active:scale-[0.99] disabled:opacity-60 disabled:cursor-not-allowed"
              style={{ background: 'var(--accent)', color: 'white' }}
            >
              {(isApprovePending || isApproveConfirming) && <Loader2 size={18} className="animate-spin" />}
              {isApprovePending ? 'Confirm in wallet…' : isApproveConfirming ? 'Confirming…' : 'Approve USDC'}
            </button>

            {approveTxHash && (
              <a
                href={buildTxExplorerUrl(activeChainId, approveTxHash)}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-center underline"
                style={{ color: 'var(--subtle)' }}
              >
                View approval on explorer
              </a>
            )}
          </motion.div>
        )}

        {/* ── PAY ── */}
        {step === 'pay' && (
          <motion.div
            key="pay"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="flex flex-col gap-5"
          >
            <div
              className="p-6 rounded-3xl text-center flex flex-col items-center gap-4"
              style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}
            >
              <div
                className="w-16 h-16 rounded-2xl flex items-center justify-center"
                style={{ background: 'rgba(212,165,32,0.12)' }}
              >
                <span
                  className="display text-2xl font-bold tabular-nums"
                  style={{ color: 'var(--accent-gold)' }}
                >
                  ${subtotal.toFixed(2)}
                </span>
              </div>
              <div>
                <h3 className="font-semibold text-base mb-1" style={{ color: 'var(--ink)' }}>
                  Pay with USDC
                </h3>
                <p className="text-sm" style={{ color: 'var(--muted)' }}>
                  Confirm the payment in your wallet. Your order will be recorded on-chain.
                </p>
              </div>
              <div className="flex items-center gap-2 text-sm" style={{ color: 'var(--success)' }}>
                <Star size={14} fill="currentColor" />
                You'll earn <strong>{loyaltyPointsEarned} loyalty points</strong>
              </div>

              {/* Pickup summary */}
              <div
                className="w-full flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm"
                style={{ background: 'var(--surface-muted)' }}
              >
                <Clock size={13} style={{ color: 'var(--accent-gold)', flexShrink: 0 }} />
                <span style={{ color: 'var(--muted)' }}>Pickup:</span>
                <span className="font-medium" style={{ color: 'var(--ink)' }}>{pickupFormatted}</span>
              </div>
            </div>

            {/* Pickup time error (re-validated on submit) */}
            {pickupError && (
              <div
                className="flex items-start gap-3 p-4 rounded-2xl"
                style={{ background: '#fef2f2', border: '1px solid #fecaca' }}
              >
                <AlertCircle size={16} className="flex-shrink-0 mt-0.5" style={{ color: 'var(--danger)' }} />
                <p className="text-sm" style={{ color: '#991b1b' }}>{pickupError}</p>
              </div>
            )}

            {displayError && (
              <div
                className="flex items-start gap-3 p-4 rounded-2xl"
                style={{ background: '#fef2f2', border: '1px solid #fecaca' }}
              >
                <AlertCircle size={16} className="flex-shrink-0 mt-0.5" style={{ color: 'var(--danger)' }} />
                <p className="text-sm" style={{ color: '#991b1b' }}>{displayError}</p>
              </div>
            )}

            <button
              onClick={handlePlaceOrder}
              disabled={isPlacePending || isPlaceConfirming || !pickupValid}
              className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl font-semibold text-base transition-all duration-200 hover:scale-[1.01] active:scale-[0.99] disabled:opacity-60 disabled:cursor-not-allowed"
              style={{ background: 'var(--accent)', color: 'white' }}
            >
              {(isPlacePending || isPlaceConfirming) && <Loader2 size={18} className="animate-spin" />}
              {isPlacePending
                ? 'Confirm in wallet…'
                : isPlaceConfirming
                  ? 'Processing order…'
                  : `Pay $${subtotal.toFixed(2)} USDC`}
            </button>

            {placeTxHash && (
              <a
                href={buildTxExplorerUrl(activeChainId, placeTxHash)}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-center underline"
                style={{ color: 'var(--subtle)' }}
              >
                View transaction on explorer
              </a>
            )}
          </motion.div>
        )}

        {/* ── SUCCESS ── */}
        {step === 'success' && (
          <motion.div
            key="success"
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col gap-5"
          >
            <div
              className="flex flex-col items-center gap-4 p-8 rounded-3xl text-center"
              style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', damping: 15 }}
                className="w-20 h-20 rounded-full flex items-center justify-center"
                style={{ background: 'rgba(26,128,71,0.12)' }}
              >
                <Check size={40} style={{ color: 'var(--success)' }} />
              </motion.div>

              <div>
                <h2
                  className="display text-2xl font-bold mb-2"
                  style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}
                >
                  Order placed!
                </h2>

                {orderCode ? (
                  <div
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl mb-3"
                    style={{
                      background: 'rgba(212,165,32,0.12)',
                      border: '1px solid rgba(212,165,32,0.3)',
                    }}
                  >
                    <span
                      className="text-xs font-medium uppercase tracking-widest"
                      style={{ color: 'var(--accent-gold)' }}
                    >
                      Order
                    </span>
                    <span className="font-mono font-bold text-lg" style={{ color: 'var(--ink)' }}>
                      {orderCode}
                    </span>
                  </div>
                ) : (
                  <div className="flex items-center justify-center gap-2 mb-3" style={{ color: 'var(--subtle)' }}>
                    <Loader2 size={14} className="animate-spin" />
                    <span className="text-xs">Assigning order code…</span>
                  </div>
                )}

                <p className="text-sm" style={{ color: 'var(--muted)' }}>
                  We've received your order and are getting started. Pickup at{' '}
                  <strong>{pickupFormatted}</strong>.
                </p>
              </div>

              {txHash && (
                <a
                  href={buildTxExplorerUrl(activeChainId, txHash)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs underline"
                  style={{ color: 'var(--subtle)' }}
                >
                  View on explorer
                </a>
              )}

              <div
                className="flex items-center gap-2 px-4 py-2.5 rounded-2xl text-sm font-medium"
                style={{ background: 'rgba(212,165,32,0.1)', color: 'var(--accent-gold)' }}
              >
                <Star size={14} fill="currentColor" />
                +{loyaltyPointsEarned} loyalty points earned
              </div>
            </div>

            <button
              onClick={onSuccess}
              className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl font-semibold text-base transition-all duration-200 hover:scale-[1.01] active:scale-[0.99]"
              style={{ background: 'var(--accent)', color: 'white' }}
            >
              Track my order
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
