/**
 * blankProduct — default template for creating a new menu item.
 * Lives in its own file so MenuContext.tsx can export only React components
 * and satisfy Vite's Fast Refresh constraint.
 */

import {
  DEFAULT_SIZES,
  MILK_OPTIONS,
  SUGAR_LEVELS,
  ICE_LEVELS,
} from './menuData';
import type { ManagedMenuItem } from '../context/MenuContext';

export function blankProduct(): Omit<ManagedMenuItem, 'id'> {
  return {
    category: 'vietnamese',
    name: '',
    nameVi: '',
    description: '',
    price: 2.5,
    imageUrl: '',
    popular: false,
    hidden: false,
    paused: false,
    sizes: DEFAULT_SIZES,
    milkOptions: MILK_OPTIONS,
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: [],
  };
}
