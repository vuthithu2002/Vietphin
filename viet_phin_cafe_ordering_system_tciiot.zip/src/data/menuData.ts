// Viet Phin — Menu Data
// Prices in USDC (2.0 – 3.5 range)
// Every imageUrl uses a unique, relevant Unsplash photo.

export type Category =
  | 'vietnamese'
  | 'milktea'
  | 'tea'
  | 'pastries'
  | 'sandwiches'
  | 'desserts';

export interface MenuItem {
  id: string;
  category: Category;
  name: string;
  nameVi?: string;
  description: string;
  price: number;         // base price in USDC
  tags?: string[];
  popular?: boolean;
  imageUrl: string;
  sizes?: SizeOption[];
  milkOptions?: string[];
  sugarLevels?: string[];
  iceLevels?: string[];
}

export interface SizeOption {
  label: string;
  priceDelta: number;
}

export const DEFAULT_SIZES: SizeOption[] = [
  { label: 'M', priceDelta: 0 },
  { label: 'L', priceDelta: 0.5 },
];

export const MILK_OPTIONS = [
  'Fresh Milk',
  'Condensed Milk',
  'Oat Milk',
  'Almond Milk',
  'Coconut Milk',
  'No Milk',
];

export const SUGAR_LEVELS = [
  '0% — No Sugar',
  '25% — Less Sweet',
  '50% — Half Sweet',
  '75% — Lightly Sweet',
  '100% — Regular',
];

export const ICE_LEVELS = [
  'No Ice',
  'Less Ice',
  'Regular Ice',
  'Extra Ice',
];

// Helper: Unsplash CDN with consistent crop
const U = (id: string) =>
  `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=600&q=80`;

export const MENU_ITEMS: MenuItem[] = [

  // ─────────────────────────────────────────────────────────────────────────
  // VIETNAMESE COFFEE (Cà Phê)
  // ─────────────────────────────────────────────────────────────────────────
  {
    id: 'ca-phe-phin',
    category: 'vietnamese',
    name: 'Cà Phê Phin',
    nameVi: 'Cà Phê Phin',
    description: 'Classic phin-drip coffee brewed slowly over condensed milk. Bold, aromatic, deeply Vietnamese.',
    price: 2.50,
    popular: true,
    // Vietnamese phin drip coffee on glass
    imageUrl: U('1511920183378-df99de3c2ff4'),
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['signature', 'hot & iced'],
  },
  {
    id: 'ca-phe-sua-da',
    category: 'vietnamese',
    name: 'Cà Phê Sữa Đá',
    nameVi: 'Cà Phê Sữa Đá',
    description: 'Iced phin coffee over sweetened condensed milk and crushed ice. Rich, creamy, Vietnam in a glass.',
    price: 3.00,
    popular: true,
    // iced Vietnamese coffee with condensed milk
    imageUrl: U('1514432492-f0a5ab6a1b62'),
    milkOptions: ['Condensed Milk', 'Fresh Milk', 'Oat Milk'],
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['bestseller', 'iced'],
  },
  {
    id: 'egg-coffee',
    category: 'vietnamese',
    name: 'Egg Coffee',
    nameVi: 'Cà Phê Trứng',
    description: 'A Hanoian legend — egg yolk & condensed milk foam whipped silky-smooth atop strong robusta. Velvety and indulgent.',
    price: 3.50,
    popular: true,
    // egg coffee / ca phe trung in ceramic cup
    imageUrl: U('1572097149080-79d7e84a6c95'),
    tags: ['specialty', 'hot', 'Hanoi'],
  },
  {
    id: 'coconut-coffee',
    category: 'vietnamese',
    name: 'Coconut Coffee',
    nameVi: 'Cà Phê Cốt Dừa',
    description: 'Blended phin coffee with rich coconut cream and condensed milk. Tropical, smooth, and refreshing.',
    price: 3.50,
    popular: true,
    // coconut tropical drink with coffee layer
    imageUrl: U('1561882468-9110e03e0f8d'),
    iceLevels: ICE_LEVELS,
    tags: ['signature', 'blended', 'tropical'],
  },
  {
    id: 'salted-coffee',
    category: 'vietnamese',
    name: 'Salted Coffee',
    nameVi: 'Cà Phê Muối',
    description: 'Robusta phin coffee crowned with silky salted cream foam. Sweet, bitter, and savory in every sip.',
    price: 3.00,
    // dark coffee with cream top, overhead
    imageUrl: U('1510591609474-20fb42c4ee17'),
    iceLevels: ICE_LEVELS,
    tags: ['specialty', 'Huế', 'hot & iced'],
  },
  {
    id: 'ca-phe-den-da',
    category: 'vietnamese',
    name: 'Cà Phê Đen Đá',
    nameVi: 'Cà Phê Đen Đá',
    description: 'Pure black Vietnamese iced phin coffee — no milk, no frills. Just bold robusta over ice.',
    price: 2.00,
    // glass of iced black coffee, dark and clear
    imageUrl: U('1495474472287-4d71bcdd2085'),
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['iced', 'strong', 'classic'],
  },
  {
    id: 'bac-xiu',
    category: 'vietnamese',
    name: 'Bạc Xỉu',
    nameVi: 'Bạc Xỉu',
    description: 'A Saigonese classic — mostly hot milk with just a wisp of phin coffee and condensed milk. Mild, sweet, and comforting.',
    price: 2.50,
    // light milky coffee with soft foam
    imageUrl: U('1504630083234-14b9e0a8e9a7'),
    sugarLevels: SUGAR_LEVELS,
    tags: ['mild', 'Saigon', 'hot'],
  },
  {
    id: 'yogurt-coffee',
    category: 'vietnamese',
    name: 'Yogurt Coffee',
    nameVi: 'Cà Phê Sữa Chua',
    description: 'Iced phin coffee poured over tangy homemade yogurt. Uniquely Vietnamese and refreshingly tart.',
    price: 3.00,
    // coffee and yogurt layered drink
    imageUrl: U('1592978261788-c0a68cfa8d0a'),
    iceLevels: ICE_LEVELS,
    tags: ['specialty', 'iced', 'unique'],
  },
  {
    id: 'espresso-phin',
    category: 'vietnamese',
    name: 'Espresso Phin',
    nameVi: 'Espresso Phin',
    description: 'A bold double-shot espresso extracted through a Vietnamese phin for a uniquely textured, intense brew.',
    price: 3.00,
    // espresso shot closeup with crema
    imageUrl: U('1510707577719-ae7c14805e3a'),
    tags: ['espresso', 'strong', 'hot'],
  },
  {
    id: 'ca-phe-sua-tuoi',
    category: 'vietnamese',
    name: 'Cà Phê Sữa Tươi',
    nameVi: 'Cà Phê Sữa Tươi',
    description: 'Phin coffee with fresh steamed milk — lighter than condensed milk, cleaner and more modern.',
    price: 2.50,
    // latte-style coffee with fresh milk
    imageUrl: U('1485808191679-5f86510bd9d5'),
    milkOptions: MILK_OPTIONS,
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['fresh', 'light', 'hot & iced'],
  },
  {
    id: 'ca-phe-hot-chocolate',
    category: 'vietnamese',
    name: 'Cà Phê Chocolate',
    nameVi: 'Cà Phê Sô Cô La',
    description: 'Dark phin coffee stirred with rich Vietnamese cacao and fresh milk. A mocha with a Vietnamese soul.',
    price: 3.00,
    // chocolate coffee mocha in glass
    imageUrl: U('1579888944880-d498e0b5c1e3'),
    milkOptions: MILK_OPTIONS,
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['chocolate', 'mocha', 'hot & iced'],
  },

  // ─────────────────────────────────────────────────────────────────────────
  // MILK TEA (Trà Sữa)
  // ─────────────────────────────────────────────────────────────────────────
  {
    id: 'tra-sua-truyen-thong',
    category: 'milktea',
    name: 'Trà Sữa Truyền Thống',
    nameVi: 'Trà Sữa Truyền Thống',
    description: 'Classic black tea milk tea with fresh milk and chewy tapioca pearls. Smooth, fragrant, and perfectly balanced.',
    price: 2.50,
    popular: true,
    // classic pearl milk tea in clear cup
    imageUrl: U('1571091718767-18b5b1457add'),
    sizes: DEFAULT_SIZES,
    milkOptions: MILK_OPTIONS,
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['classic', 'bestseller'],
  },
  {
    id: 'tra-sua-matcha',
    category: 'milktea',
    name: 'Trà Sữa Matcha',
    nameVi: 'Trà Sữa Matcha',
    description: 'Japanese ceremonial matcha whisked with steamed milk, lightly sweetened. Earthy, creamy, vibrant green.',
    price: 3.00,
    popular: true,
    // green matcha latte in glass
    imageUrl: U('1515823064-d6e0c04616a7'),
    sizes: DEFAULT_SIZES,
    milkOptions: MILK_OPTIONS,
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['matcha', 'popular'],
  },
  {
    id: 'tra-sua-thai',
    category: 'milktea',
    name: 'Trà Sữa Thái',
    nameVi: 'Trà Sữa Thái',
    description: 'Bright orange spiced Thai tea with condensed milk and fresh cream. Rich, exotic, and irresistibly sweet.',
    price: 3.00,
    // thai orange iced tea with milk
    imageUrl: U('1627308595229-7830cf07db7a'),
    sizes: DEFAULT_SIZES,
    milkOptions: MILK_OPTIONS,
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['popular', 'iced', 'orange'],
  },
  {
    id: 'brown-sugar-milk-tea',
    category: 'milktea',
    name: 'Brown Sugar Milk Tea',
    nameVi: 'Trà Sữa Đường Đen',
    description: 'Tiger-striped brown sugar syrup, creamy milk tea and chewy boba pearls. The drink that took over the world.',
    price: 3.50,
    popular: true,
    // brown sugar boba with tiger stripes
    imageUrl: U('1578662996442-48f60103fc96'),
    sizes: DEFAULT_SIZES,
    milkOptions: MILK_OPTIONS,
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['trending', 'bestseller', 'boba'],
  },
  {
    id: 'taro-milk-tea',
    category: 'milktea',
    name: 'Taro Milk Tea',
    nameVi: 'Trà Sữa Khoai Môn',
    description: 'Creamy purple taro blended with fresh milk and a hint of vanilla. Sweet, earthy, and beautifully lavender.',
    price: 3.00,
    // purple taro milk tea in clear cup
    imageUrl: U('1561048020-9fd19ef00aee'),
    sizes: DEFAULT_SIZES,
    milkOptions: MILK_OPTIONS,
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['popular', 'purple', 'boba'],
  },
  {
    id: 'tra-sua-oolong',
    category: 'milktea',
    name: 'Trà Sữa Oolong',
    nameVi: 'Trà Sữa Oolong Sữa Tươi',
    description: 'High-mountain oolong steeped thick, shaken with fresh milk and cheese foam on top. Fragrant and complex.',
    price: 3.00,
    // oolong milk tea with foam top
    imageUrl: U('1556679343-c7306c1976bc'),
    sizes: DEFAULT_SIZES,
    milkOptions: MILK_OPTIONS,
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['oolong', 'cheese foam'],
  },
  {
    id: 'pandan-milk-tea',
    category: 'milktea',
    name: 'Pandan Milk Tea',
    nameVi: 'Trà Sữa Lá Dứa',
    description: 'Fragrant pandan leaf infusion blended with creamy fresh milk. Quintessentially Vietnamese and aromatic.',
    price: 2.50,
    // green pandan drink in glass
    imageUrl: U('1638176066260-9b9106e56310'),
    sizes: DEFAULT_SIZES,
    milkOptions: MILK_OPTIONS,
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['specialty', 'pandan', 'Vietnamese'],
  },
  {
    id: 'tra-sua-tran-chau',
    category: 'milktea',
    name: 'Trà Sữa Trân Châu',
    nameVi: 'Trà Sữa Trân Châu Hoàng Kim',
    description: 'Golden honey milk tea loaded with handmade golden tapioca pearls. Chewy, sweet, and utterly satisfying.',
    price: 3.00,
    // golden boba milk tea
    imageUrl: U('1544145945-f90425340c7e'),
    sizes: DEFAULT_SIZES,
    milkOptions: MILK_OPTIONS,
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['boba', 'honey', 'popular'],
  },
  {
    id: 'tra-sua-hong-tra',
    category: 'milktea',
    name: 'Hồng Trà Sữa',
    nameVi: 'Hồng Trà Sữa',
    description: 'Premium red tea steeped strong, shaken with whole milk until frothy. Clean, bright, and deeply refreshing.',
    price: 2.50,
    // iced red tea milk
    imageUrl: U('1504674900247-0877df9cc836'),
    sizes: DEFAULT_SIZES,
    milkOptions: MILK_OPTIONS,
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['classic', 'red tea'],
  },
  {
    id: 'cheese-foam-milk-tea',
    category: 'milktea',
    name: 'Cheese Foam Milk Tea',
    nameVi: 'Trà Sữa Cheese Foam',
    description: 'Rich black milk tea topped with a thick salted cheese foam. Sip from the side — the magic is in the contrast.',
    price: 3.50,
    // milk tea with thick white foam top
    imageUrl: U('1590080875851-9f7e7bdbb8d1'),
    sizes: DEFAULT_SIZES,
    milkOptions: MILK_OPTIONS,
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['cheese foam', 'trending'],
  },

  // ─────────────────────────────────────────────────────────────────────────
  // TEA (Trà)
  // ─────────────────────────────────────────────────────────────────────────
  {
    id: 'tra-dao',
    category: 'tea',
    name: 'Trà Đào',
    nameVi: 'Trà Đào',
    description: 'Green tea with fresh peach slices, lychee jelly, and honey. Fruity, floral, and irresistibly refreshing.',
    price: 2.50,
    popular: true,
    // peach iced tea with fruit slices
    imageUrl: U('1559181567-c3190100d0fb'),
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['fruity', 'iced', 'bestseller'],
  },
  {
    id: 'tra-vai',
    category: 'tea',
    name: 'Trà Vải',
    nameVi: 'Trà Vải',
    description: 'Jasmine green tea infused with fresh lychee juice and lychee jelly cubes. Floral, tropical, and delicately sweet.',
    price: 2.50,
    // lychee iced tea pink drink
    imageUrl: U('1610641818989-c2051b5e2cfd'),
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['fruity', 'iced', 'lychee'],
  },
  {
    id: 'tra-chanh',
    category: 'tea',
    name: 'Trà Chanh',
    nameVi: 'Trà Chanh',
    description: 'Classic Vietnamese street-style lemon iced tea — black tea, fresh lime, salt, sugar. Tart, cold, and timeless.',
    price: 2.00,
    // lemon iced tea with lime slices
    imageUrl: U('1509042239860-f7cac5ef1c1e'),
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['sour', 'iced', 'classic'],
  },
  {
    id: 'tra-sen',
    category: 'tea',
    name: 'Trà Sen',
    nameVi: 'Trà Sen',
    description: 'Delicate green tea scented overnight with lotus blossoms. A Vietnamese tradition of elegance — subtle and calming.',
    price: 2.50,
    // lotus flower tea elegant ceramic cup
    imageUrl: U('1582450628498-9bca6fbb4916'),
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ['Hot', 'Less Ice', 'Regular Ice'],
    tags: ['floral', 'hot', 'traditional'],
  },
  {
    id: 'tra-oolong',
    category: 'tea',
    name: 'Trà Oolong',
    nameVi: 'Trà Oolong',
    description: 'High-mountain Taiwanese oolong with a roasted, honey-like finish. Complex, smooth, and deeply satisfying.',
    price: 2.50,
    // amber oolong tea in glass teapot
    imageUrl: U('1584968153986-3f5fe684d739'),
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['aromatic', 'hot & iced'],
  },
  {
    id: 'tra-atiso',
    category: 'tea',
    name: 'Trà Atiso',
    nameVi: 'Trà Atisô',
    description: 'Artichoke herbal tea from Đà Lạt — naturally sweet, golden amber color, and wonderfully detoxifying.',
    price: 2.00,
    // golden herbal tea in glass
    imageUrl: U('1542990253-a7b5f14e0b42'),
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['herbal', 'caffeine-free', 'Đà Lạt'],
  },
  {
    id: 'tra-tac',
    category: 'tea',
    name: 'Trà Tắc',
    nameVi: 'Trà Tắc',
    description: 'Black tea with fresh kumquat juice, honey, and rock salt. Tangy, sweet-sour, and uniquely Vietnamese.',
    price: 2.50,
    // citrus kumquat iced tea, small orange fruits
    imageUrl: U('1491795029600-b32e1e36ec8a'),
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['citrus', 'iced', 'street-style'],
  },
  {
    id: 'tra-dao-cam-sa',
    category: 'tea',
    name: 'Trà Đào Cam Sả',
    nameVi: 'Trà Đào Cam Sả',
    description: 'Peach green tea with fresh orange slices and fragrant lemongrass. Bright, aromatic, and refreshingly complex.',
    price: 3.00,
    popular: true,
    // orange lemongrass iced tea
    imageUrl: U('1517701550927-30cf4ba1deba'),
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['fruity', 'lemongrass', 'popular'],
  },
  {
    id: 'tra-gung',
    category: 'tea',
    name: 'Trà Gừng Mật Ong',
    nameVi: 'Trà Gừng Mật Ong',
    description: 'Spiced ginger tea sweetened with wildflower honey. Warming, soothing, perfect for cool rainy mornings.',
    price: 2.00,
    // honey ginger tea, warm amber color
    imageUrl: U('1571934811081-6e0f7b64f9df'),
    tags: ['hot', 'caffeine-free', 'warming'],
  },
  {
    id: 'tra-hong-tra-dao',
    category: 'tea',
    name: 'Hồng Trà Đào',
    nameVi: 'Hồng Trà Đào',
    description: 'Strong red tea poured over fresh peach purée and topped with sparkling water. Fruity, bubbly, and effervescent.',
    price: 3.00,
    // sparkling fruity red tea drink
    imageUrl: U('1563379926345-cf82a4c35a72'),
    sugarLevels: SUGAR_LEVELS,
    iceLevels: ICE_LEVELS,
    tags: ['sparkling', 'peach', 'refreshing'],
  },

  // ─────────────────────────────────────────────────────────────────────────
  // PASTRIES & CAKES (Bánh)
  // ─────────────────────────────────────────────────────────────────────────
  {
    id: 'banh-flan',
    category: 'pastries',
    name: 'Bánh Flan',
    nameVi: 'Bánh Flan',
    description: 'Silky Vietnamese caramel custard flan — amber caramel pooling around a wobbly, soft custard. A classic.',
    price: 2.50,
    popular: true,
    // flan custard with amber caramel
    imageUrl: U('1565958011703-44f9829ba187'),
    tags: ['sweet', 'bestseller', 'custard'],
  },
  {
    id: 'banh-mi-bo',
    category: 'pastries',
    name: 'Bánh Mì Bơ',
    nameVi: 'Bánh Mì Bơ',
    description: 'Crispy Vietnamese baguette split and slathered with salted butter and cane sugar. Simple street-food joy.',
    price: 2.00,
    // baguette with butter
    imageUrl: U('1555507036-ab6b57dddef0'),
    tags: ['breakfast', 'savory-sweet'],
  },
  {
    id: 'croissant',
    category: 'pastries',
    name: 'Croissant',
    description: 'Flaky, golden, buttery croissant baked fresh every morning. Perfect with any phin coffee.',
    price: 2.50,
    // golden flaky croissant overhead
    imageUrl: U('1509722747041-616f39b57edd'),
    tags: ['breakfast', 'buttery', 'French'],
  },
  {
    id: 'cheesecake',
    category: 'pastries',
    name: 'Basque Cheesecake',
    description: 'Burnt Basque cheesecake with a caramelized crust and silky, creamy interior. Rich and unforgettable.',
    price: 3.50,
    popular: true,
    // burnt basque cheesecake slice
    imageUrl: U('1571114486747-6dc8a0e8c617'),
    tags: ['sweet', 'popular', 'cheesecake'],
  },
  {
    id: 'tiramisu',
    category: 'pastries',
    name: 'Tiramisu',
    description: 'Classic tiramisu made with Vietnamese robusta espresso, mascarpone, and a generous dusting of dark cocoa.',
    price: 3.50,
    // tiramisu in glass cup with cocoa dusting
    imageUrl: U('1571877227200-a0d6a6041562'),
    tags: ['sweet', 'coffee', 'Italian'],
  },
  {
    id: 'banh-chuoi',
    category: 'pastries',
    name: 'Bánh Chuối Nướng',
    nameVi: 'Bánh Chuối Nướng',
    description: 'Baked Vietnamese banana sticky cake with coconut cream glaze. Moist, fragrant with pandan, and deeply satisfying.',
    price: 2.50,
    // banana cake slice golden brown
    imageUrl: U('1588195538326-c5b1e9f80a1b'),
    tags: ['sweet', 'banana', 'Vietnamese'],
  },
  {
    id: 'banh-su',
    category: 'pastries',
    name: 'Bánh Su Kem',
    nameVi: 'Bánh Su Kem',
    description: 'Choux pastry puffs filled with silky vanilla custard cream. Light, airy, and melts in the mouth.',
    price: 2.50,
    // cream puffs, choux pastry
    imageUrl: U('1550617931-e17a7b70dce2'),
    tags: ['sweet', 'creamy', 'French'],
  },
  {
    id: 'banh-tart',
    category: 'pastries',
    name: 'Bánh Tart Trứng',
    nameVi: 'Bánh Tart Trứng',
    description: 'Portuguese-style egg tarts with a flaky buttery shell and silky, slightly caramelized custard filling.',
    price: 2.50,
    popular: true,
    // egg tart portuguese custard tart
    imageUrl: U('1558961363-fa8fdf82db35'),
    tags: ['sweet', 'egg tart', 'popular'],
  },
  {
    id: 'banh-bong-lan',
    category: 'pastries',
    name: 'Bánh Bông Lan',
    nameVi: 'Bánh Bông Lan',
    description: 'Soft, pillowy Vietnamese sponge cake with a golden crust. Light as a cloud and subtly sweet.',
    price: 2.00,
    // soft sponge cake slice pale yellow
    imageUrl: U('1586788680434-f748888d9f83'),
    tags: ['sweet', 'light', 'Vietnamese'],
  },
  {
    id: 'pain-au-chocolat',
    category: 'pastries',
    name: 'Pain au Chocolat',
    description: 'Flaky French puff pastry folded around dark chocolate batons. Crisp outside, melty inside.',
    price: 3.00,
    // pain au chocolat closeup
    imageUrl: U('1483695028939-5bb13f8648b0'),
    tags: ['chocolate', 'French', 'breakfast'],
  },
  {
    id: 'banh-da-lon',
    category: 'pastries',
    name: 'Bánh Da Lợn',
    nameVi: 'Bánh Da Lợn',
    description: 'Layered steamed pandan and coconut rice cake — translucent, chewy, fragrant, and beautiful in cross-section.',
    price: 2.50,
    // green layered Vietnamese steamed cake
    imageUrl: U('1563379091339-b30cb3c38a2e'),
    tags: ['Vietnamese', 'pandan', 'traditional'],
  },

  // ─────────────────────────────────────────────────────────────────────────
  // SANDWICHES (Bánh Mì)
  // ─────────────────────────────────────────────────────────────────────────
  {
    id: 'banh-mi-classic',
    category: 'sandwiches',
    name: 'Classic Bánh Mì',
    nameVi: 'Bánh Mì Đặc Biệt',
    description: 'Crispy baguette with pork pâté, Vietnamese ham, head cheese, pickled daikon & carrot, cucumber, jalapeño, and fresh herbs.',
    price: 3.50,
    popular: true,
    // banh mi sandwich closeup with fillings
    imageUrl: U('1509440159596-0249088772ff'),
    tags: ['savory', 'bestseller', 'signature'],
  },
  {
    id: 'banh-mi-veggie',
    category: 'sandwiches',
    name: 'Veggie Bánh Mì',
    nameVi: 'Bánh Mì Chay',
    description: 'Lemongrass tofu, avocado, pickled daikon & carrot, jalapeño, and house hoisin-sesame mayo on a crispy baguette.',
    price: 3.00,
    // vegetarian sandwich with colorful veggies
    imageUrl: U('1485963631004-f2f00b1d6606'),
    tags: ['vegetarian', 'savory', 'healthy'],
  },
  {
    id: 'banh-mi-thit-nuong',
    category: 'sandwiches',
    name: 'Bánh Mì Thịt Nướng',
    nameVi: 'Bánh Mì Thịt Nướng',
    description: 'Grilled lemongrass pork belly, caramelized onions, pickled vegetables, cucumber, and sriracha mayo.',
    price: 3.50,
    popular: true,
    // grilled pork Vietnamese baguette
    imageUrl: U('1467003909585-2f8a72700288'),
    tags: ['savory', 'grilled', 'pork'],
  },
  {
    id: 'banh-mi-ga',
    category: 'sandwiches',
    name: 'Bánh Mì Gà',
    nameVi: 'Bánh Mì Gà Nướng',
    description: 'Chargrilled turmeric chicken with house mayo, pickled vegetables, cucumber, and fresh coriander.',
    price: 3.50,
    // grilled chicken sandwich / baguette
    imageUrl: U('1550547660-37406909e2b4'),
    tags: ['savory', 'chicken', 'grilled'],
  },
  {
    id: 'banh-mi-cha-lua',
    category: 'sandwiches',
    name: 'Bánh Mì Chả Lụa',
    nameVi: 'Bánh Mì Chả Lụa',
    description: 'Vietnamese silken pork roll (chả lụa), butter, Maggi sauce, pickled veg, and herbs. A Saigon street-food staple.',
    price: 3.00,
    // Vietnamese banh mi cut in half showing fillings
    imageUrl: U('1528735602780-2552fd46c7af'),
    tags: ['savory', 'traditional', 'Saigon'],
  },
  {
    id: 'banh-mi-pate',
    category: 'sandwiches',
    name: 'Bánh Mì Pate',
    nameVi: 'Bánh Mì Pate Bơ',
    description: 'Crispy baguette with rich French pork pâté, salted butter, Maggi, and pickled vegetables. Simple perfection.',
    price: 3.00,
    popular: true,
    // rustic French baguette with pate spread
    imageUrl: U('1601050690597-df0568f70950'),
    tags: ['savory', 'pate', 'classic'],
  },
  {
    id: 'banh-mi-xiu-mai',
    category: 'sandwiches',
    name: 'Bánh Mì Xíu Mại',
    nameVi: 'Bánh Mì Xíu Mại',
    description: 'Soft braised Vietnamese meatballs in a tomato-lemongrass broth, stuffed into a crusty baguette. Hot and hearty.',
    price: 3.50,
    // meatball sandwich with sauce
    imageUrl: U('1565299624596-722f3a971738'),
    tags: ['savory', 'meatball', 'warm'],
  },
  {
    id: 'banh-mi-trung',
    category: 'sandwiches',
    name: 'Bánh Mì Trứng',
    nameVi: 'Bánh Mì Trứng Ốp La',
    description: 'Fried egg, pâté, cucumber, and pickled veg in a warm crispy baguette. The perfect breakfast sandwich.',
    price: 2.50,
    // fried egg baguette sandwich
    imageUrl: U('1525351484163-7529414344d8'),
    tags: ['breakfast', 'egg', 'savory'],
  },

  // ─────────────────────────────────────────────────────────────────────────
  // DESSERTS (Tráng Miệng)
  // ─────────────────────────────────────────────────────────────────────────
  {
    id: 'che-ba-mau',
    category: 'desserts',
    name: 'Chè Ba Màu',
    nameVi: 'Chè Ba Màu',
    description: 'Three-color sweet bean dessert — red beans, pandan jelly, mung bean paste — with coconut milk and shaved ice.',
    price: 3.00,
    popular: true,
    // colorful layered Vietnamese dessert drink
    imageUrl: U('1612198188060-c5e4396f898a'),
    iceLevels: ICE_LEVELS,
    tags: ['sweet', 'Vietnamese', 'traditional'],
  },
  {
    id: 'che-dau-do',
    category: 'desserts',
    name: 'Chè Đậu Đỏ',
    nameVi: 'Chè Đậu Đỏ',
    description: 'Red bean sweet soup simmered with rock sugar and served warm or iced with coconut cream. Comforting and nourishing.',
    price: 2.50,
    // red bean sweet soup warm bowl
    imageUrl: U('1604908173716-08ae1caf9f85'),
    iceLevels: ICE_LEVELS,
    tags: ['sweet', 'warm', 'red bean'],
  },
  {
    id: 'che-thai',
    category: 'desserts',
    name: 'Chè Thái',
    nameVi: 'Chè Thái',
    description: 'Tropical fruit medley in coconut milk with jackfruit, palm seeds, grass jelly, and shaved ice.',
    price: 3.00,
    // thai mixed fruit dessert colorful
    imageUrl: U('1547592180-85f173990554'),
    iceLevels: ICE_LEVELS,
    tags: ['sweet', 'tropical', 'fruity'],
  },
  {
    id: 'kem-dua',
    category: 'desserts',
    name: 'Kem Dừa',
    nameVi: 'Kem Dừa',
    description: 'Homemade coconut ice cream in a half coconut shell, topped with toasted coconut flakes and pandan jelly.',
    price: 3.50,
    popular: true,
    // coconut ice cream in coconut shell
    imageUrl: U('1538489753-f0fc4dce17f7'),
    tags: ['ice cream', 'coconut', 'bestseller'],
  },
  {
    id: 'pudding-pandan',
    category: 'desserts',
    name: 'Pandan Coconut Pudding',
    nameVi: 'Bánh Pudding Pandan Dừa',
    description: 'Double-layer pudding: fragrant pandan custard beneath thick coconut cream. Wobbly, silky, perfection.',
    price: 2.50,
    // cream dessert cup with coconut swirl
    imageUrl: U('1621929469462-fe3ab76e2b0e'),
    tags: ['sweet', 'pandan', 'creamy'],
  },
  {
    id: 'yaourt',
    category: 'desserts',
    name: 'Yaourt Dẻo',
    nameVi: 'Yaourt Dẻo',
    description: 'Vietnamese set yogurt — thicker and creamier than Greek yogurt, slightly tangy, drizzled with honey.',
    price: 2.50,
    // creamy white yogurt in small jar with honey
    imageUrl: U('1488477181946-6428a0291777'),
    tags: ['yogurt', 'tangy', 'Vietnamese'],
  },
  {
    id: 'trai-cay-dam',
    category: 'desserts',
    name: 'Sinh Tố Trái Cây',
    nameVi: 'Sinh Tố Trái Cây',
    description: 'Fresh seasonal Vietnamese fruit smoothie blended with sweetened condensed milk. Thick, creamy, and vibrant.',
    price: 3.00,
    popular: true,
    // colorful tropical fruit smoothie
    imageUrl: U('1590301157890-4810ed352733'),
    iceLevels: ICE_LEVELS,
    tags: ['smoothie', 'fruit', 'fresh'],
  },
  {
    id: 'kem-chien',
    category: 'desserts',
    name: 'Kem Chiên',
    nameVi: 'Kem Chiên',
    description: 'Deep-fried ice cream coated in a crispy golden batter — cold inside, crunchy outside. A fun Vietnamese dessert.',
    price: 3.50,
    // fried ice cream golden batter
    imageUrl: U('1560717789-0ac2ffeb9f54'),
    tags: ['fried', 'ice cream', 'fun'],
  },
  {
    id: 'nuoc-mia',
    category: 'desserts',
    name: 'Nước Mía',
    nameVi: 'Nước Mía Tắc',
    description: 'Freshly pressed sugarcane juice with kumquat and a pinch of salt. Vietnam\'s most refreshing street drink.',
    price: 2.50,
    // fresh sugarcane juice green
    imageUrl: U('1534030347209-467a04a07df0'),
    iceLevels: ICE_LEVELS,
    tags: ['sugarcane', 'fresh', 'Vietnamese'],
  },
  {
    id: 'banh-da-xanh',
    category: 'desserts',
    name: 'Bánh Da Xanh',
    nameVi: 'Bánh Da Xanh',
    description: 'Chewy pandan glutinous rice balls in sweet ginger syrup, topped with toasted sesame and shredded coconut.',
    price: 2.50,
    // sticky rice balls topped with sesame seeds
    imageUrl: U('1568901346375-9be3f37b3b7f'),
    tags: ['pandan', 'chewy', 'traditional'],
  },
];

export const CATEGORY_LABELS: Record<Category, string> = {
  vietnamese: 'Vietnamese Coffee',
  milktea: 'Milk Tea',
  tea: 'Tea',
  pastries: 'Pastries & Cakes',
  sandwiches: 'Sandwiches',
  desserts: 'Desserts',
};

export const CATEGORY_LABELS_VI: Record<Category, string> = {
  vietnamese: 'Cà Phê',
  milktea: 'Trà Sữa',
  tea: 'Trà',
  pastries: 'Bánh',
  sandwiches: 'Bánh Mì',
  desserts: 'Tráng Miệng',
};

export const CATEGORY_ORDER: Category[] = [
  'vietnamese',
  'milktea',
  'tea',
  'pastries',
  'sandwiches',
  'desserts',
];

export const FEATURED_IDS = [
  'ca-phe-sua-da',
  'egg-coffee',
  'coconut-coffee',
  'brown-sugar-milk-tea',
  'tra-dao',
  'banh-mi-classic',
  'che-ba-mau',
  'kem-dua',
];
