/**
 * VietPhin contract config — v2 (escrow with rejectOrder / completeOrder).
 * Address is set in VITE_VIETPHIN_ADDRESS (.env).
 */
import { getUsdc } from '@/onchain-facts';
import { parseAmount } from '@/onchain-money';

export const ARC_TESTNET_CHAIN_ID = 5042002;
export const ARC_MAINNET_CHAIN_ID = 5042;

/** Both Arc Mainnet and Arc Testnet are supported chain IDs */
export const SUPPORTED_CHAIN_IDS = [ARC_MAINNET_CHAIN_ID, ARC_TESTNET_CHAIN_ID] as const;
export type SupportedChainId = typeof SUPPORTED_CHAIN_IDS[number];

export const USDC_FACT = getUsdc(ARC_TESTNET_CHAIN_ID);
if (!USDC_FACT) {
  throw new Error('USDC not found on Arc Testnet — check onchain-facts');
}

// Both Arc Mainnet and Arc Testnet use the same USDC address
export const USDC_ADDRESS = USDC_FACT.address as `0x${string}`;

/** USDC address is the same on both Arc Mainnet and Arc Testnet */
export function getUsdcAddress(_chainId?: number): `0x${string}` {
  return USDC_ADDRESS;
}

export const VIETPHIN_ABI = [
  // ── Constructor ────────────────────────────────────────────────────────────
  {
    type: 'constructor',
    inputs: [
      { name: 'usdcToken_', type: 'address' },
      { name: 'initialOwner', type: 'address' },
    ],
    stateMutability: 'nonpayable',
  },

  // ── Customer functions ─────────────────────────────────────────────────────
  {
    type: 'function',
    name: 'placeOrder',
    inputs: [
      { name: 'totalAmountUsdc', type: 'uint256' },
      { name: 'pickupTime', type: 'uint256' },
      { name: 'itemsHash', type: 'bytes32' },
    ],
    outputs: [{ name: '', type: 'uint256' }],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'customerCancel',
    inputs: [{ name: 'orderId', type: 'uint256' }],
    outputs: [],
    stateMutability: 'nonpayable',
  },

  // ── Owner (staff) functions ────────────────────────────────────────────────
  {
    type: 'function',
    name: 'updateOrderStatus',
    inputs: [
      { name: 'orderId', type: 'uint256' },
      { name: 'newStatus', type: 'uint8' },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'rejectOrder',
    inputs: [{ name: 'orderId', type: 'uint256' }],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'completeOrder',
    inputs: [{ name: 'orderId', type: 'uint256' }],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'proposeTreasury',
    inputs: [{ name: 'newTreasury', type: 'address' }],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'acceptTreasury',
    inputs: [],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'redeemLoyaltyPoints',
    inputs: [
      { name: 'customer', type: 'address' },
      { name: 'points', type: 'uint256' },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'withdrawUSDC',
    inputs: [
      { name: 'to', type: 'address' },
      { name: 'amount', type: 'uint256' },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'updateOrderTxHash',
    inputs: [
      { name: 'orderId', type: 'uint256' },
      { name: 'txHash', type: 'bytes32' },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'withdrawAll',
    inputs: [{ name: 'to', type: 'address' }],
    outputs: [],
    stateMutability: 'nonpayable',
  },

  // ── Product management (owner-only mutations) ──────────────────────────────
  {
    type: 'function',
    name: 'seedProducts',
    inputs: [
      {
        name: 'items',
        type: 'tuple[]',
        components: [
          { name: 'name', type: 'string' },
          { name: 'nameVi', type: 'string' },
          { name: 'description', type: 'string' },
          { name: 'priceUsdc', type: 'uint256' },
          { name: 'category', type: 'string' },
          { name: 'imageUrl', type: 'string' },
          { name: 'isFeatured', type: 'bool' },
          { name: 'isHidden', type: 'bool' },
          { name: 'isPaused', type: 'bool' },
        ],
      },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'addProduct',
    inputs: [
      {
        name: 'item',
        type: 'tuple',
        components: [
          { name: 'name', type: 'string' },
          { name: 'nameVi', type: 'string' },
          { name: 'description', type: 'string' },
          { name: 'priceUsdc', type: 'uint256' },
          { name: 'category', type: 'string' },
          { name: 'imageUrl', type: 'string' },
          { name: 'isFeatured', type: 'bool' },
          { name: 'isHidden', type: 'bool' },
          { name: 'isPaused', type: 'bool' },
        ],
      },
    ],
    outputs: [{ name: 'id', type: 'uint256' }],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'updateProduct',
    inputs: [
      { name: 'id', type: 'uint256' },
      {
        name: 'item',
        type: 'tuple',
        components: [
          { name: 'name', type: 'string' },
          { name: 'nameVi', type: 'string' },
          { name: 'description', type: 'string' },
          { name: 'priceUsdc', type: 'uint256' },
          { name: 'category', type: 'string' },
          { name: 'imageUrl', type: 'string' },
          { name: 'isFeatured', type: 'bool' },
          { name: 'isHidden', type: 'bool' },
          { name: 'isPaused', type: 'bool' },
        ],
      },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'deleteProduct',
    inputs: [{ name: 'id', type: 'uint256' }],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'setProductHidden',
    inputs: [
      { name: 'id', type: 'uint256' },
      { name: 'hidden', type: 'bool' },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'setProductPaused',
    inputs: [
      { name: 'id', type: 'uint256' },
      { name: 'paused', type: 'bool' },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'setProductFeatured',
    inputs: [
      { name: 'id', type: 'uint256' },
      { name: 'featured', type: 'bool' },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },

  // ── Product view functions ─────────────────────────────────────────────────
  {
    type: 'function',
    name: 'productCount',
    inputs: [],
    outputs: [{ name: '', type: 'uint256' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getProduct',
    inputs: [{ name: 'id', type: 'uint256' }],
    outputs: [
      {
        name: '',
        type: 'tuple',
        components: [
          { name: 'id', type: 'uint256' },
          { name: 'name', type: 'string' },
          { name: 'nameVi', type: 'string' },
          { name: 'description', type: 'string' },
          { name: 'priceUsdc', type: 'uint256' },
          { name: 'category', type: 'string' },
          { name: 'imageUrl', type: 'string' },
          { name: 'isFeatured', type: 'bool' },
          { name: 'isHidden', type: 'bool' },
          { name: 'isPaused', type: 'bool' },
          { name: 'exists', type: 'bool' },
        ],
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getProducts',
    inputs: [
      { name: 'offset', type: 'uint256' },
      { name: 'limit', type: 'uint256' },
    ],
    outputs: [
      {
        name: '',
        type: 'tuple[]',
        components: [
          { name: 'id', type: 'uint256' },
          { name: 'name', type: 'string' },
          { name: 'nameVi', type: 'string' },
          { name: 'description', type: 'string' },
          { name: 'priceUsdc', type: 'uint256' },
          { name: 'category', type: 'string' },
          { name: 'imageUrl', type: 'string' },
          { name: 'isFeatured', type: 'bool' },
          { name: 'isHidden', type: 'bool' },
          { name: 'isPaused', type: 'bool' },
          { name: 'exists', type: 'bool' },
        ],
      },
    ],
    stateMutability: 'view',
  },

  // ── Product events ─────────────────────────────────────────────────────────
  {
    type: 'event',
    name: 'ProductAdded',
    inputs: [
      { name: 'id', type: 'uint256', indexed: true },
      { name: 'name', type: 'string', indexed: false },
    ],
  },
  {
    type: 'event',
    name: 'ProductUpdated',
    inputs: [{ name: 'id', type: 'uint256', indexed: true }],
  },
  {
    type: 'event',
    name: 'ProductDeleted',
    inputs: [{ name: 'id', type: 'uint256', indexed: true }],
  },
  {
    type: 'event',
    name: 'WithdrawnAll',
    inputs: [
      { name: 'to', type: 'address', indexed: true },
      { name: 'amount', type: 'uint256', indexed: false },
    ],
  },

  // ── View functions ─────────────────────────────────────────────────────────
  {
    type: 'function',
    name: 'getOrder',
    inputs: [{ name: 'orderId', type: 'uint256' }],
    outputs: [
      {
        name: '',
        type: 'tuple',
        components: [
          { name: 'orderId', type: 'uint256' },
          { name: 'customer', type: 'address' },
          { name: 'totalAmountUsdc', type: 'uint256' },
          { name: 'pickupTime', type: 'uint256' },
          { name: 'status', type: 'uint8' },
          { name: 'itemsHash', type: 'bytes32' },
          { name: 'createdAt', type: 'uint256' },
          { name: 'txHash', type: 'bytes32' },
        ],
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getLoyaltyPoints',
    inputs: [{ name: 'customer', type: 'address' }],
    outputs: [{ name: '', type: 'uint256' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getOrdersByCustomer',
    inputs: [
      { name: 'customer', type: 'address' },
      { name: 'offset', type: 'uint256' },
      { name: 'limit', type: 'uint256' },
    ],
    outputs: [{ name: '', type: 'uint256[]' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'orderCount',
    inputs: [],
    outputs: [{ name: '', type: 'uint256' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'usdcToken',
    inputs: [],
    outputs: [{ name: '', type: 'address' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'treasury',
    inputs: [],
    outputs: [{ name: '', type: 'address' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'pendingTreasury',
    inputs: [],
    outputs: [{ name: '', type: 'address' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'totalEscrowed',
    inputs: [],
    outputs: [{ name: '', type: 'uint256' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'owner',
    inputs: [],
    outputs: [{ name: '', type: 'address' }],
    stateMutability: 'view',
  },

  // ── Events ─────────────────────────────────────────────────────────────────
  {
    type: 'event',
    name: 'OrderPlaced',
    inputs: [
      { name: 'orderId', type: 'uint256', indexed: true },
      { name: 'customer', type: 'address', indexed: true },
      { name: 'totalAmountUsdc', type: 'uint256', indexed: false },
      { name: 'pickupTime', type: 'uint256', indexed: false },
      { name: 'itemsHash', type: 'bytes32', indexed: false },
    ],
  },
  {
    type: 'event',
    name: 'OrderStatusUpdated',
    inputs: [
      { name: 'orderId', type: 'uint256', indexed: true },
      { name: 'newStatus', type: 'uint8', indexed: false },
      { name: 'updatedBy', type: 'address', indexed: false },
    ],
  },
  {
    type: 'event',
    name: 'OrderRejected',
    inputs: [
      { name: 'orderId', type: 'uint256', indexed: true },
      { name: 'customer', type: 'address', indexed: true },
      { name: 'refundAmount', type: 'uint256', indexed: false },
    ],
  },
  {
    type: 'event',
    name: 'OrderCompleted',
    inputs: [
      { name: 'orderId', type: 'uint256', indexed: true },
      { name: 'treasury', type: 'address', indexed: true },
      { name: 'amount', type: 'uint256', indexed: false },
    ],
  },
  {
    type: 'event',
    name: 'Refunded',
    inputs: [
      { name: 'orderId', type: 'uint256', indexed: true },
      { name: 'customer', type: 'address', indexed: true },
      { name: 'amount', type: 'uint256', indexed: false },
    ],
  },
  {
    type: 'event',
    name: 'LoyaltyPointsEarned',
    inputs: [
      { name: 'customer', type: 'address', indexed: true },
      { name: 'points', type: 'uint256', indexed: false },
      { name: 'orderId', type: 'uint256', indexed: false },
    ],
  },
  {
    type: 'event',
    name: 'LoyaltyPointsRedeemed',
    inputs: [
      { name: 'customer', type: 'address', indexed: true },
      { name: 'points', type: 'uint256', indexed: false },
    ],
  },
  {
    type: 'event',
    name: 'TreasuryUpdated',
    inputs: [
      { name: 'oldTreasury', type: 'address', indexed: true },
      { name: 'newTreasury', type: 'address', indexed: true },
    ],
  },
  {
    type: 'event',
    name: 'TreasuryUpdateProposed',
    inputs: [{ name: 'proposed', type: 'address', indexed: true }],
  },
] as const;

/**
 * Get the VietPhin contract address for the given chain.
 * - Arc Mainnet (5042):   VITE_VIETPHIN_MAINNET_ADDRESS
 * - Arc Testnet (5042002): VITE_VIETPHIN_ADDRESS
 * Returns null if the env var is not set for that chain.
 */
export function getVietPhinAddress(chainId?: number): `0x${string}` | null {
  if (chainId === ARC_MAINNET_CHAIN_ID) {
    const addr = import.meta.env.VITE_VIETPHIN_MAINNET_ADDRESS as string | undefined;
    if (!addr || addr === '' || addr === '0x') return null;
    return addr as `0x${string}`;
  }
  // Default: testnet (also used when chainId is undefined)
  const addr = import.meta.env.VITE_VIETPHIN_ADDRESS as string | undefined;
  if (!addr || addr === '' || addr === '0x') return null;
  return addr as `0x${string}`;
}

/** Returns true if the chainId is one of the supported Arc networks */
export function isSupportedChain(chainId?: number): chainId is SupportedChainId {
  return chainId === ARC_MAINNET_CHAIN_ID || chainId === ARC_TESTNET_CHAIN_ID;
}

/** Parse a USDC dollar amount to raw 6-decimal bigint */
export function usdcDollarsToRaw(dollars: number): bigint {
  return parseAmount(ARC_TESTNET_CHAIN_ID, dollars.toFixed(6)).raw;
}

/** Format raw USDC bigint to dollar string */
export function formatUsdcRaw(raw: bigint): string {
  return (Number(raw) / 1_000_000).toFixed(2);
}

export function parseOnchainError(error: unknown): string {
  const msg = (error as { message?: string })?.message?.toLowerCase() ?? '';
  if (msg.includes('user rejected') || msg.includes('user denied')) return 'Transaction cancelled.';
  if (msg.includes('insufficient funds') || msg.includes('exceeds balance')) {
    return 'Insufficient USDC balance. Please add funds first.';
  }
  if (msg.includes('invalidpickuptime')) return 'Please select a valid pickup time (must be in the future).';
  if (msg.includes('invalidamount')) return 'Order total must be greater than zero.';
  if (msg.includes('allowance') || msg.includes('erc20: insufficient allowance')) {
    return 'Please approve USDC spending first.';
  }
  if (msg.includes('ordernotrefundable')) return 'This order cannot be refunded (already completed or cancelled).';
  if (msg.includes('ordernotcompletable')) return 'Order must be Ready for Pickup before completing.';
  if (msg.includes('orderalreadyfinalized')) return 'This order has already been finalised.';
  if (msg.includes('terminalstatusforbidden')) return 'Use Reject or Complete to finalise an order.';
  if (msg.includes('insufficientsurplus')) return 'Cannot withdraw escrowed funds — only surplus is withdrawable.';
  if (msg.includes('ownableunauthorizedaccount') || msg.includes('onlyowner')) {
    return 'Only the owner wallet can perform this action.';
  }
  if (msg.includes('reverted')) return 'Transaction failed. Please check your inputs and try again.';
  if (msg.includes('network') || msg.includes('timeout')) {
    return 'Network error. Please check your connection and retry.';
  }
  return 'Something went wrong. Please try again.';
}
