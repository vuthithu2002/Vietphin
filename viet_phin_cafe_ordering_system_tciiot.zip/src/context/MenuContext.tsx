/**
 * MenuContext — menu state backed by the VietPhin contract on-chain.
 *
 * On mount: read all products from the deployed contract via a viem public
 * client (getProducts(0, 0) — limit=0 means "return all").
 * Mutations call writeContractAsync via wagmi and re-read after the tx
 * confirms so local state always matches chain state.
 * Falls back to the static MENU_ITEMS seed when the contract address is not
 * configured or the RPC call fails.
 *
 * On-chain product ids are uint256 numbers; ManagedMenuItem.id is that
 * number as a string (e.g. "3") to stay compatible with the rest of the app.
 */

import React, {
  createContext,
  useContext,
  useReducer,
  useCallback,
  useEffect,
  useRef,
  useState,
} from 'react';
import { createPublicClient, http } from 'viem';
import { useWriteContract, useWaitForTransactionReceipt, useChainId } from 'wagmi';
import { toast } from 'sonner';
import { parseOnchainError } from '../lib/contract';
import { MENU_ITEMS } from '../data/menuData';
import type { MenuItem } from '../data/menuData';
import {
  VIETPHIN_ABI,
  getVietPhinAddress,
  ARC_MAINNET_CHAIN_ID,
  ARC_TESTNET_CHAIN_ID,
} from '../lib/contract';
import { requireChain } from '@/onchain-facts';

export interface ManagedMenuItem extends MenuItem {
  hidden?: boolean;
  /** Temporarily sold out — shown as Unavailable on customer menu; re-enable anytime */
  paused?: boolean;
}

// ── On-chain product struct returned by getProducts ──────────────────────────

interface OnChainProduct {
  id: bigint;
  name: string;
  nameVi: string;
  description: string;
  priceUsdc: bigint;
  category: string;
  imageUrl: string;
  isFeatured: boolean;
  isHidden: boolean;
  isPaused: boolean;
  exists: boolean;
}

/** Map an on-chain product to the ManagedMenuItem shape the UI expects. */
function fromOnChain(p: OnChainProduct): ManagedMenuItem {
  return {
    id: p.id.toString(),
    name: p.name,
    nameVi: p.nameVi || undefined,
    description: p.description,
    price: Number(p.priceUsdc) / 1_000_000,
    category: p.category as ManagedMenuItem['category'],
    imageUrl: p.imageUrl,
    popular: p.isFeatured,
    hidden: p.isHidden,
    paused: p.isPaused,
  };
}

/** Build a ProductInput tuple for addProduct / updateProduct. */
function toProductInput(item: Omit<ManagedMenuItem, 'id'>) {
  // Convert dollar price to raw USDC units using string arithmetic to avoid
  // floating-point drift (e.g. 2.5 * 1_000_000 = 2499999.9999... in JS).
  const priceUsdc = BigInt(Math.round(Number((item.price ?? 0).toFixed(6)) * 1_000_000));

  // Never send base64 data URLs onchain — they are ~50 KB and exceed block gas.
  // If the imageUrl starts with "data:", preserve the existing on-chain value by
  // sending "". The caller (updateItem) uses the *merged* object, so the existing
  // on-chain URL is in `current.imageUrl`; if that was also a data URL it was
  // already bad. We simply clear it rather than risk an OOG revert.
  const rawUrl = (item.imageUrl ?? '').trim();
  const imageUrl = rawUrl.startsWith('data:') ? '' : rawUrl;

  return {
    name: item.name.trim(),
    nameVi: (item.nameVi ?? '').trim(),
    description: item.description.trim(),
    priceUsdc,
    category: item.category,
    imageUrl,
    isFeatured: item.popular ?? false,
    isHidden: item.hidden ?? false,
    isPaused: item.paused ?? false,
  } as const;
}

/** Return true when a product id is a valid on-chain numeric id (not a legacy slug). */
function isOnchainId(id: string): boolean {
  return /^\d+$/.test(id) && id !== '0';
}

// ── Actions ───────────────────────────────────────────────────────────────────

type MenuAction =
  | { type: 'SET_ALL'; items: ManagedMenuItem[] }
  | { type: 'ADD_ITEM'; item: ManagedMenuItem }
  | { type: 'UPDATE_ITEM'; id: string; patch: Partial<ManagedMenuItem> }
  | { type: 'DELETE_ITEM'; id: string }
  | { type: 'TOGGLE_HIDDEN'; id: string }
  | { type: 'TOGGLE_POPULAR'; id: string }
  | { type: 'TOGGLE_PAUSED'; id: string };

function menuReducer(
  state: ManagedMenuItem[],
  action: MenuAction,
): ManagedMenuItem[] {
  switch (action.type) {
    case 'SET_ALL':
      return action.items;
    case 'ADD_ITEM':
      return [...state, action.item];
    case 'UPDATE_ITEM':
      return state.map((it) =>
        it.id === action.id ? { ...it, ...action.patch } : it,
      );
    case 'DELETE_ITEM':
      return state.filter((it) => it.id !== action.id);
    case 'TOGGLE_HIDDEN':
      return state.map((it) =>
        it.id === action.id ? { ...it, hidden: !it.hidden } : it,
      );
    case 'TOGGLE_POPULAR':
      return state.map((it) =>
        it.id === action.id ? { ...it, popular: !it.popular } : it,
      );
    case 'TOGGLE_PAUSED':
      return state.map((it) =>
        it.id === action.id ? { ...it, paused: !it.paused } : it,
      );
    default:
      return state;
  }
}

// ── Context ───────────────────────────────────────────────────────────────────

export interface MenuContextValue {
  allItems: ManagedMenuItem[];
  visibleItems: ManagedMenuItem[];
  loading: boolean;
  /** True when an on-chain write is pending confirmation */
  writing: boolean;
  /** True when products were loaded from the contract (have numeric IDs). False = static fallback. */
  isContractSource: boolean;
  addItem: (item: Omit<ManagedMenuItem, 'id'>) => Promise<void>;
  updateItem: (id: string, patch: Partial<ManagedMenuItem>) => Promise<void>;
  deleteItem: (id: string) => Promise<void>;
  toggleHidden: (id: string) => Promise<void>;
  togglePopular: (id: string) => Promise<void>;
  togglePaused: (id: string) => Promise<void>;
  refresh: () => Promise<void>;
}

const MenuContext = createContext<MenuContextValue | null>(null);

// ── Public client helper ──────────────────────────────────────────────────────

function makePublicClient(chainId: number) {
  const chain = requireChain(chainId);
  const rpcUrl = chain.rpcUrls[0];
  return createPublicClient({ transport: http(rpcUrl) });
}

// ── Provider ──────────────────────────────────────────────────────────────────

export function MenuProvider({ children }: { children: React.ReactNode }) {
  const [items, dispatch] = useReducer(menuReducer, MENU_ITEMS as ManagedMenuItem[]);
  const [loading, setLoading] = useState(true);
  const [writing, setWriting] = useState(false);
  const [isContractSource, setIsContractSource] = useState(false);

  // pendingHash stored in a ref to avoid the set-state-in-effect lint error
  const pendingHashRef = useRef<`0x${string}` | undefined>(undefined);
  const [watchHash, setWatchHash] = useState<`0x${string}` | undefined>(undefined);

  const wagmiChainId = useChainId();
  const chainId =
    wagmiChainId === ARC_MAINNET_CHAIN_ID || wagmiChainId === ARC_TESTNET_CHAIN_ID
      ? wagmiChainId
      : ARC_MAINNET_CHAIN_ID;

  const contractAddress = getVietPhinAddress(chainId);

  const { writeContractAsync } = useWriteContract();

  const { isSuccess: txConfirmed } = useWaitForTransactionReceipt({
    hash: watchHash,
    query: { enabled: !!watchHash },
  });

  const loadAll = useCallback(async () => {
    if (!contractAddress) {
      // No contract configured — show static fallback for display only.
      // Mutations will be blocked because isOnchainId() will return false.
      dispatch({ type: 'SET_ALL', items: MENU_ITEMS });
      setLoading(false);
      return;
    }
    try {
      const client = makePublicClient(chainId);
      const products = await client.readContract({
        address: contractAddress,
        abi: VIETPHIN_ABI,
        functionName: 'getProducts',
        args: [0n, 0n],
      }) as OnChainProduct[];
      // Use on-chain data even if the array is empty (unseeded contract).
      // Never fall back to MENU_ITEMS here — that would produce non-numeric
      // string IDs (e.g. "ca-phe-phin") which break BigInt() in mutations.
      dispatch({ type: 'SET_ALL', items: products.map(fromOnChain) });
      setIsContractSource(true);
    } catch (err) {
      console.warn('[menu] Contract read failed, using seed data:', err);
      // RPC failure only — still show static data for browsing but mutations
      // won't work (no numeric IDs).
      dispatch({ type: 'SET_ALL', items: MENU_ITEMS });
      setIsContractSource(false);
    } finally {
      setLoading(false);
    }
  }, [contractAddress, chainId]);

  // Initial load
  useEffect(() => { void loadAll(); }, [loadAll]);

  // Reload after tx confirms — use ref to avoid set-state-in-effect warning
  const writingRef = useRef(writing);
  writingRef.current = writing;

  const handleTxConfirmed = useCallback(() => {
    setWatchHash(undefined);
    setWriting(false);
    pendingHashRef.current = undefined;
    void loadAll();
  }, [loadAll]);

  useEffect(() => {
    if (txConfirmed && watchHash) {
      handleTxConfirmed();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [txConfirmed]);

  // ── Write helper ──────────────────────────────────────────────────────────

  const sendWrite = useCallback(
    async (optimistic: () => void, writeFn: () => Promise<`0x${string}`>) => {
      optimistic();
      setWriting(true);
      try {
        const hash = await writeFn();
        pendingHashRef.current = hash;
        setWatchHash(hash);
      } catch (err) {
        setWriting(false);
        void loadAll(); // revert optimistic state
        const msg = parseOnchainError(err);
        toast.error(msg);
        throw err;
      }
    },
    [loadAll],
  );

  // ── Mutations ──────────────────────────────────────────────────────────────

  const addItem = useCallback(
    async (item: Omit<ManagedMenuItem, 'id'>) => {
      if (!contractAddress) throw new Error('Contract address not configured');
      const tempId = 'temp-' + Date.now().toString(36);
      await sendWrite(
        () => dispatch({ type: 'ADD_ITEM', item: { ...item, id: tempId } }),
        () => writeContractAsync({
          address: contractAddress,
          abi: VIETPHIN_ABI,
          functionName: 'addProduct',
          args: [toProductInput(item)],
          chainId,
        }),
      );
    },
    [contractAddress, chainId, sendWrite, writeContractAsync],
  );

  const updateItem = useCallback(
    async (id: string, patch: Partial<ManagedMenuItem>) => {
      if (!contractAddress) throw new Error('Contract address not configured');
      if (!isOnchainId(id)) throw new Error(`Product id "${id}" is not an on-chain id. Please seed products from the contract first.`);
      const current = items.find((i) => i.id === id);
      if (!current) return;
      // If the patch contains a base64 data URL (uploaded locally), keep the
      // existing on-chain URL — data URLs are too large to store on-chain.
      const safePatch = { ...patch };
      if (safePatch.imageUrl?.startsWith('data:')) {
        safePatch.imageUrl = current.imageUrl;
      }
      const merged: Omit<ManagedMenuItem, 'id'> = { ...current, ...safePatch };
      const productInput = toProductInput(merged);
      await sendWrite(
        () => dispatch({ type: 'UPDATE_ITEM', id, patch }),
        () => writeContractAsync({
          address: contractAddress,
          abi: VIETPHIN_ABI,
          functionName: 'updateProduct',
          args: [BigInt(id), productInput],
          chainId,
        }),
      );
    },
    [contractAddress, chainId, items, sendWrite, writeContractAsync],
  );

  const deleteItem = useCallback(
    async (id: string) => {
      if (!contractAddress) throw new Error('Contract address not configured');
      if (!isOnchainId(id)) throw new Error(`Product id "${id}" is not an on-chain id. Please seed products from the contract first.`);
      await sendWrite(
        () => dispatch({ type: 'DELETE_ITEM', id }),
        () => writeContractAsync({
          address: contractAddress,
          abi: VIETPHIN_ABI,
          functionName: 'deleteProduct',
          args: [BigInt(id)],
          chainId,
        }),
      );
    },
    [contractAddress, chainId, sendWrite, writeContractAsync],
  );

  const toggleHidden = useCallback(
    async (id: string) => {
      if (!contractAddress) throw new Error('Contract address not configured');
      if (!isOnchainId(id)) throw new Error(`Product id "${id}" is not an on-chain id. Please seed products from the contract first.`);
      const newHidden = !items.find((i) => i.id === id)?.hidden;
      await sendWrite(
        () => dispatch({ type: 'TOGGLE_HIDDEN', id }),
        () => writeContractAsync({
          address: contractAddress,
          abi: VIETPHIN_ABI,
          functionName: 'setProductHidden',
          args: [BigInt(id), newHidden],
          chainId,
        }),
      );
    },
    [contractAddress, chainId, items, sendWrite, writeContractAsync],
  );

  const togglePopular = useCallback(
    async (id: string) => {
      if (!contractAddress) throw new Error('Contract address not configured');
      if (!isOnchainId(id)) throw new Error(`Product id "${id}" is not an on-chain id. Please seed products from the contract first.`);
      const newFeatured = !items.find((i) => i.id === id)?.popular;
      await sendWrite(
        () => dispatch({ type: 'TOGGLE_POPULAR', id }),
        () => writeContractAsync({
          address: contractAddress,
          abi: VIETPHIN_ABI,
          functionName: 'setProductFeatured',
          args: [BigInt(id), newFeatured],
          chainId,
        }),
      );
    },
    [contractAddress, chainId, items, sendWrite, writeContractAsync],
  );

  const togglePaused = useCallback(
    async (id: string) => {
      if (!contractAddress) throw new Error('Contract address not configured');
      if (!isOnchainId(id)) throw new Error(`Product id "${id}" is not an on-chain id. Please seed products from the contract first.`);
      const newPaused = !items.find((i) => i.id === id)?.paused;
      await sendWrite(
        () => dispatch({ type: 'TOGGLE_PAUSED', id }),
        () => writeContractAsync({
          address: contractAddress,
          abi: VIETPHIN_ABI,
          functionName: 'setProductPaused',
          args: [BigInt(id), newPaused],
          chainId,
        }),
      );
    },
    [contractAddress, chainId, items, sendWrite, writeContractAsync],
  );

  const visibleItems = items.filter((it) => !it.hidden);

  return (
    <MenuContext.Provider
      value={{
        allItems: items,
        visibleItems,
        loading,
        writing,
        isContractSource,
        addItem,
        updateItem,
        deleteItem,
        toggleHidden,
        togglePopular,
        togglePaused,
        refresh: loadAll,
      }}
    >
      {children}
    </MenuContext.Provider>
  );
}

export function useMenu(): MenuContextValue {
  const ctx = useContext(MenuContext);
  if (!ctx) throw new Error('useMenu must be used within a MenuProvider');
  return ctx;
}
