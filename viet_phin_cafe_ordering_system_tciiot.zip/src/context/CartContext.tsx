/**
 * CartContext — in-session cart + persistent orders via /api/orders.
 *
 * Cart items are ephemeral (cleared on page close — intentional for a
 * pre-order kiosk; the customer rebuilds the cart each visit).
 *
 * Placed orders are persisted to Postgres via the API and loaded back
 * on mount so customers see their full history across sessions and devices.
 */

import React, {
  createContext,
  useContext,
  useReducer,
  useCallback,
  useEffect,
} from 'react';
import type { CartItem, PlacedOrder, OrderStatus } from '../types/order';

// ── State & Actions ───────────────────────────────────────────────────────────

interface CartState {
  items: CartItem[];
  pickupTime: string;
  notes: string;
  placedOrders: PlacedOrder[];
}

type CartAction =
  | { type: 'ADD_ITEM'; item: CartItem }
  | { type: 'REMOVE_ITEM'; menuItemId: string; size?: string; milk?: string; sugar?: string; ice?: string }
  | { type: 'UPDATE_QTY'; menuItemId: string; size?: string; milk?: string; sugar?: string; ice?: string; qty: number }
  | { type: 'CLEAR_CART' }
  | { type: 'SET_PICKUP_TIME'; time: string }
  | { type: 'SET_NOTES'; notes: string }
  | { type: 'SET_PLACED_ORDERS'; orders: PlacedOrder[] }
  | { type: 'ADD_PLACED_ORDER'; order: PlacedOrder }
  | { type: 'UPDATE_ORDER_STATUS'; orderId: string; status: OrderStatus; cancelReason?: string; refundTxHash?: string; completeTxHash?: string }
  | { type: 'SET_ORDER_CODE'; orderId: string; orderCode: string };

function itemKey(item: Pick<CartItem, 'menuItemId' | 'size' | 'milk' | 'sugar' | 'ice'>): string {
  return `${item.menuItemId}|${item.size ?? ''}|${item.milk ?? ''}|${item.sugar ?? ''}|${item.ice ?? ''}`;
}

function cartReducer(state: CartState, action: CartAction): CartState {
  switch (action.type) {
    case 'ADD_ITEM': {
      const key = itemKey(action.item);
      const existing = state.items.findIndex((i) => itemKey(i) === key);
      if (existing >= 0) {
        const items = [...state.items];
        items[existing] = { ...items[existing], quantity: items[existing].quantity + action.item.quantity };
        return { ...state, items };
      }
      return { ...state, items: [...state.items, action.item] };
    }
    case 'REMOVE_ITEM': {
      const key = itemKey(action);
      return { ...state, items: state.items.filter((i) => itemKey(i) !== key) };
    }
    case 'UPDATE_QTY': {
      const key = itemKey(action);
      if (action.qty <= 0) {
        return { ...state, items: state.items.filter((i) => itemKey(i) !== key) };
      }
      return {
        ...state,
        items: state.items.map((i) => (itemKey(i) === key ? { ...i, quantity: action.qty } : i)),
      };
    }
    case 'CLEAR_CART':
      return { ...state, items: [], pickupTime: '', notes: '' };
    case 'SET_PICKUP_TIME':
      return { ...state, pickupTime: action.time };
    case 'SET_NOTES':
      return { ...state, notes: action.notes };
    case 'SET_PLACED_ORDERS':
      return { ...state, placedOrders: action.orders };
    case 'ADD_PLACED_ORDER':
      return { ...state, placedOrders: [action.order, ...state.placedOrders] };
    case 'UPDATE_ORDER_STATUS':
      return {
        ...state,
        placedOrders: state.placedOrders.map((o) =>
          o.orderId === action.orderId
            ? {
                ...o,
                status: action.status,
                ...(action.cancelReason   !== undefined ? { cancelReason:   action.cancelReason   } : {}),
                ...(action.refundTxHash   !== undefined ? { refundTxHash:   action.refundTxHash   } : {}),
                ...(action.completeTxHash !== undefined ? { completeTxHash: action.completeTxHash } : {}),
              }
            : o,
        ),
      };
    case 'SET_ORDER_CODE':
      return {
        ...state,
        placedOrders: state.placedOrders.map((o) =>
          o.orderId === action.orderId ? { ...o, orderCode: action.orderCode } : o,
        ),
      };
    default:
      return state;
  }
}

// ── API helpers ───────────────────────────────────────────────────────────────

async function apiFetch(path: string, opts?: RequestInit): Promise<unknown> {
  const res = await fetch(`/api${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...opts,
  });
  if (!res.ok) throw new Error(`API ${path} → ${res.status}`);
  return res.json();
}

// ── Context ───────────────────────────────────────────────────────────────────

interface CartContextValue {
  items: CartItem[];
  pickupTime: string;
  notes: string;
  placedOrders: PlacedOrder[];
  itemCount: number;
  subtotal: number;
  ordersLoading: boolean;
  addItem: (item: CartItem) => void;
  removeItem: (menuItemId: string, size?: string, milk?: string, sugar?: string, ice?: string) => void;
  updateQty: (menuItemId: string, size?: string, milk?: string, sugar?: string, ice?: string, qty?: number) => void;
  clearCart: () => void;
  setPickupTime: (time: string) => void;
  setNotes: (notes: string) => void;
  addPlacedOrder: (order: PlacedOrder) => Promise<void>;
  updateOrderStatus: (orderId: string, status: OrderStatus, cancelReason?: string, txHash?: string) => Promise<void>;
  refreshOrders: (customerAddress?: string) => Promise<void>;
}

const CartContext = createContext<CartContextValue | null>(null);

// ── Provider ──────────────────────────────────────────────────────────────────

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(cartReducer, {
    items: [],
    pickupTime: '',
    notes: '',
    placedOrders: [],
  });
  const [ordersLoading, setOrdersLoadingInner] = React.useState(false);

  // Load all orders on mount (staff can see everything; customer filters by address later)
  useEffect(() => {
    void (async () => {
      try {
        const data = await apiFetch('/orders');
        dispatch({ type: 'SET_PLACED_ORDERS', orders: data as PlacedOrder[] });
      } catch {
        // API not ready yet — orders stay empty until refresh
      }
    })();
  }, []);

  // ── Cart mutations (in-memory only) ──────────────────────────────────────

  const addItem = useCallback((item: CartItem) => dispatch({ type: 'ADD_ITEM', item }), []);
  const removeItem = useCallback(
    (menuItemId: string, size?: string, milk?: string, sugar?: string, ice?: string) =>
      dispatch({ type: 'REMOVE_ITEM', menuItemId, size, milk, sugar, ice }),
    [],
  );
  const updateQty = useCallback(
    (menuItemId: string, size?: string, milk?: string, sugar?: string, ice?: string, qty = 1) =>
      dispatch({ type: 'UPDATE_QTY', menuItemId, size, milk, sugar, ice, qty }),
    [],
  );
  const clearCart = useCallback(() => dispatch({ type: 'CLEAR_CART' }), []);
  const setPickupTime = useCallback((time: string) => dispatch({ type: 'SET_PICKUP_TIME', time }), []);
  const setNotes = useCallback((notes: string) => dispatch({ type: 'SET_NOTES', notes }), []);

  // ── Order mutations (API-backed + optimistic) ────────────────────────────

  const addPlacedOrder = useCallback(async (order: PlacedOrder) => {
    dispatch({ type: 'ADD_PLACED_ORDER', order }); // optimistic (no code yet)
    try {
      // Server assigns the real orderCode; merge it back so the UI shows the code
      const saved = await apiFetch('/orders', { method: 'POST', body: JSON.stringify(order) }) as PlacedOrder;
      if (saved.orderCode && saved.orderCode !== order.orderCode) {
        dispatch({ type: 'SET_ORDER_CODE', orderId: order.orderId, orderCode: saved.orderCode });
      }
    } catch {
      // API unavailable (static deploy) — generate a local order code so the UI
      // never shows "assigning…" indefinitely
      const now = new Date();
      const yy = String(now.getFullYear()).slice(2);
      const mm = String(now.getMonth() + 1).padStart(2, '0');
      const dd = String(now.getDate()).padStart(2, '0');
      const rand = Math.floor(Math.random() * 9000) + 1000;
      const localCode = `VP-${yy}${mm}${dd}-${rand}`;
      dispatch({ type: 'SET_ORDER_CODE', orderId: order.orderId, orderCode: localCode });
    }
  }, []);

  const updateOrderStatus = useCallback(async (
    orderId: string,
    status: OrderStatus,
    cancelReason?: string,
    txHash?: string,
  ) => {
    // Determine which tx hash field to set based on status
    const refundTxHash   = (status === 'Rejected'  || status === 'Cancelled') && txHash ? txHash : undefined;
    const completeTxHash = status === 'Completed' && txHash ? txHash : undefined;

    dispatch({ type: 'UPDATE_ORDER_STATUS', orderId, status, cancelReason, refundTxHash, completeTxHash }); // optimistic
    try {
      await apiFetch(`/orders/${encodeURIComponent(orderId)}`, {
        method: 'PATCH',
        body: JSON.stringify({
          status,
          ...(cancelReason   !== undefined ? { cancelReason }   : {}),
          ...(refundTxHash   !== undefined ? { refundTxHash }   : {}),
          ...(completeTxHash !== undefined ? { completeTxHash } : {}),
        }),
      });
    } catch (e) {
      console.error('[orders] failed to update status', e);
    }
  }, []);

  const refreshOrders = useCallback(async (customerAddress?: string) => {
    const qs = customerAddress ? `?customer=${encodeURIComponent(customerAddress)}` : '';
    setOrdersLoadingInner(true);
    try {
      const data = await apiFetch(`/orders${qs}`);
      dispatch({ type: 'SET_PLACED_ORDERS', orders: data as PlacedOrder[] });
    } catch (e) {
      console.error('[orders] refresh failed', e);
    } finally {
      setOrdersLoadingInner(false);
    }
  }, [setOrdersLoadingInner]);

  const itemCount = state.items.reduce((s, i) => s + i.quantity, 0);
  const subtotal = state.items.reduce((s, i) => s + i.price * i.quantity, 0);

  return (
    <CartContext.Provider
      value={{
        ...state,
        itemCount,
        subtotal,
        ordersLoading,
        addItem,
        removeItem,
        updateQty,
        clearCart,
        setPickupTime,
        setNotes,
        addPlacedOrder,
        updateOrderStatus,
        refreshOrders,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used inside CartProvider');
  return ctx;
}
