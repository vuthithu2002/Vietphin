# Agent Notes — Viet Phin

## Contract Deployments

| Contract | Network | Address | Deployer |
|---|---|---|---|
| VietPhin v4 (current) | Arc Mainnet | `0x61A8D9756c710f51e76520848bfb5F7C803b5425` | owner: `0x078c32a9788cf2368ae57d2de3e180d8f81caa3e` |
| VietPhin v3 (superseded) | Arc Mainnet | `0x4B7D1C33a264C38cC7cec973EDd5c15bA530ac75` | owner: `0x078c32a9788cf2368ae57d2de3e180d8f81caa3e` |
| VietPhin v3 | Arc Testnet | `0xc2200431c4058be1cbed73b85222c1ac52e02c5e` | `0x078c32a9788cf2368ae57d2de3e180d8f81caa3e` (owner/staff admin) |
| VietPhin v2 | Arc Testnet | `0x9338a42018bf33585e2aebeb344e7cea0285e8b5` (superseded) | `0x5B12Ce46C7194aD57d143bC22847224047b1Ef42` |
| VietPhin v1 | Arc Testnet | `0x1fb8929079ddb97b6d31a8737048021a689a5025` (superseded) | `0x5B12Ce46C7194aD57d143bC22847224047b1Ef42` |

Update this table after deploying. Also set `VITE_VIETPHIN_ADDRESS` in `.env`.

## Architecture Decisions

- Single VietPhin.sol contract handles orders + loyalty (no separate token — points are a mapping).
- Frontend keeps orders in React context (in-memory). On-chain events can be indexed post-deploy to hydrate state across sessions.
- Staff dashboard: password-protected (demo password: `vietphin2026`). On-chain status updates require the owner wallet.
- USDC address: `0x3600000000000000000000000000000000000000` (Arc Testnet). Read from `@/onchain-facts` — never hardcoded in application code.
- The `placeOrder` function requires a future `pickupTime`. Frontend enforces ≥15 min minimum.
- Menu categories: Vietnamese Coffee, Milk Tea (Trà Sữa), Tea (Trà), Pastries & Cakes (Bánh), Sandwiches (Bánh Mì), Desserts. Prices 2.00–3.50 USDC.
- Customization options: Size, Milk type, Sweetness level, Ice level — all stored on CartItem and passed in checkout summary.

## Key Files

| File | Purpose |
|---|---|
| `contracts/VietPhin.sol` | Main contract |
| `src/lib/contract.ts` | ABI + address helpers |
| `src/data/menuData.ts` | Full menu catalog |
| `src/context/CartContext.tsx` | Cart + order state |
| `src/components/CheckoutFlow.tsx` | USDC approve + placeOrder flow |
| `src/components/StaffDashboard.tsx` | Order management UI |

## Post-Deploy Checklist

1. Add `VietPhin` address to `AGENTS.md` contracts table
2. Set `VITE_VIETPHIN_ADDRESS=0x...` (testnet) and/or `VITE_VIETPHIN_MAINNET_ADDRESS=0x...` (mainnet) in `.env`
3. Restart dev server: `bun run dev`
4. Test happy path: connect wallet → menu → cart → checkout → orders page
5. Test staff: connect owner wallet → Staff tab → mark order Preparing → Ready
